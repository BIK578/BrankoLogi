import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://preprod.iqos.ro/backend.php?dispatch=auth.login_form&return_url=backend.php')

WebUI.setText(findTestObject('Object Repository/Page_Administration panel/input_Your e-mail_user_login'), 'callcenter_ro@test.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_Administration panel/input_Your password_password'), '4K3yWn4foBcnQYCEeZboeveIsNZ7mT9o')

WebUI.click(findTestObject('Object Repository/Page_Administration panel/input_Your password_dispatchauth.login'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/a_Create case'))

WebUI.setText(findTestObject('Object Repository/Page_Call center website/input_First name_firstname'), 'ivan')

WebUI.click(findTestObject('Object Repository/Page_Call center website/input_Source_dispatchcase_management.search_cded93'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/input_Membru iQOS_user_id'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/input_Total items17_dispatchcase_management_abf177'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/a_Profile check'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/a_Inquiry'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/b_None_caret'))

WebUI.setText(findTestObject('Object Repository/Page_Call center website/input_None_span3 input-text cm-ajax-content_c23f8b'), 
    'MIS')

WebUI.click(findTestObject('Object Repository/Page_Call center website/a_Miscellaneous RRP - MISCRRP'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Call center website/select_Not Selected                        _e9a496'), 
    'group_1', true)

WebUI.click(findTestObject('Object Repository/Page_Call center website/b_None_caret'))

WebUI.setText(findTestObject('Object Repository/Page_Call center website/input_None_span3 input-text cm-ajax-content_c23f8b'), 
    'R027')

WebUI.click(findTestObject('Object Repository/Page_Call center website/a_R0270.6 - Data erasure'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Call center website/select_--                                  _cd6ce3'), 
    'EM', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Call center website/select_--                                  _3ae841'), 
    '2', true)

WebUI.setText(findTestObject('Object Repository/Page_Call center website/textarea_Verbatim_issue_dataverbatim'), 'customer request/number of opened ticket/ ')

WebUI.click(findTestObject('Object Repository/Page_Call center website/input_Set_dispatchcase_management.create_is_db876c'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/input_Remove task_dispatchcase_management.f_1774c4'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/input_Do you have other issue_dispatchcase__f77378'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/input_More_dispatchcase_management.without__32ed75'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/a_Go to dashboard'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/span_Customers'))

WebUI.setText(findTestObject('Object Repository/Page_Customers  Customers - Call center website/input_Ecom ID_ecom_id'), 
    '5589')

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/input_Source_dispatchprofiles.manage'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_Active'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_Disabled'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_test22yopmail.com'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/span_Editing profile Ivan Peric_caret'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_Edit'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_Save changes'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_Dashboard'))

WebUI.click(findTestObject('Object Repository/Page_Call center website/span_Customers'))

WebUI.setText(findTestObject('Object Repository/Page_Customers  Customers - Call center website/input_User ID_consumer'), 
    'test22@yopmail.com')

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/input_Source_dispatchprofiles.manage'))

WebUI.setText(findTestObject('Object Repository/Page_Customers  Customers - Call center website/input_Ecom ID_ecom_id'), 
    '5589')

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/input_Source_dispatchprofiles.manage'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_test22yopmail.com'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_User groups'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/td_AN_CODR0270.6'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_Available'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_Active_1'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_Cases'))

WebUI.click(findTestObject('Object Repository/Page_Customers  Customers - Call center website/a_Save changes'))

