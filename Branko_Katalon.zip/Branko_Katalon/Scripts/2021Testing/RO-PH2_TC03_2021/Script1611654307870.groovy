import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://preprod.iqos.ro/')

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/button_ACCEPT TOATE'))

WebUI.selectOptionByValue(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/select_IanuarieFebruarieMartieAprilieMaiIun_95f2eb'), 
    '5', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/select_202120202019201820172016201520142013_8ec04f'), 
    '1989', true)

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/a_CONFIRM'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/svg'))

WebUI.setText(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/input_E-mail_user_login'), 
    'james.bond-007@yopmail.com')

WebUI.setEncryptedText(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/input_Parola ta_password'), 
    'zorLBLN21vw/lPomnRSIYA==')

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/img'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/a_NREGISTREAZ-TE'))

WebUI.closeBrowser()

