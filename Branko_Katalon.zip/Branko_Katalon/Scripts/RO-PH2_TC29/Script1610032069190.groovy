import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://preprod.iqos.ro/')

WebUI.selectOptionByValue(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/select_--                     IanuarieFebru_6c1619'), 
    '8', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/select_--                     2021202020192_796e36'), 
    '1988', true)

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/a_Verificare'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/button_ACCEPT TOATE'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/svg'))

WebUI.setEncryptedText(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/input_Parola ta_password'), 
    'Jypr6fxyrX5KTG73+NHFUA==')

WebUI.setText(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/input_E-mail_user_login'), 
    'zirealdcs@yopmail.com')

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/button_Login'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/svg'))

WebUI.selectOptionByValue(findTestObject('Object Repository/fran2020/Page_Profilul meu/select_PROFILUL TU                         _e2fe02'), 
    'https://preprod.iqos.ro/index.php?dispatch=mydevices.list', true)

WebUI.setText(findTestObject('Object Repository/fran2020/Page_Dispozitivele mele/input_Numr de serie_codentifyId'), 'L5XLQ1S55J1D')

WebUI.click(findTestObject('Object Repository/fran2020/Page_Dispozitivele mele/input_Data achiziiei_purchaseDate'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_Dispozitivele mele/a_12'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_Dispozitivele mele/a_Adaug'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_Dispozitivele mele/h6_nregistreaz un nou dispozitiv IQOS'))

WebUI.setText(findTestObject('Object Repository/fran2020/Page_Dispozitivele mele/input_Numr de serie_codentifyId'), 'L5XLQ1S55J1D')

WebUI.click(findTestObject('Object Repository/fran2020/Page_Dispozitivele mele/input_Data achiziiei_purchaseDate'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_Dispozitivele mele/a_4'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_Dispozitivele mele/a_Adaug'))

