import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.thoughtworks.selenium.Selenium as Selenium
import org.openqa.selenium.firefox.FirefoxDriver as FirefoxDriver
import org.openqa.selenium.WebDriver as WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium as WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern as Pattern
import static org.apache.commons.lang3.StringUtils.join
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import org.openqa.selenium.Keys as Keys
import java.text.SimpleDateFormat as SimpleDateFormat
import java.util.Calendar as Calendar

SimpleDateFormat simpleDateFormat = new SimpleDateFormat('DDhhmmss')

String date = simpleDateFormat.format(new Date())

String email = ('Branko' + date) + '@yopmail.com'

println('email is: ' + email)

GlobalVariable.BrankoEmail = email

println('email is: ' + GlobalVariable.BrankoEmail)

WebUI.openBrowser('')

WebUI.navigateToUrl('https://preprod.iqos.ro/')

WebUI.click(findTestObject('Object Repository/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/button_ACCEPT TOATE'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/select_--                     IanuarieFebru_6c1619'), 
    '11', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/select_--                     2021202020192_796e36'), 
    '1944', true)

WebUI.click(findTestObject('Object Repository/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/a_Verificare'))

WebUI.click(findTestObject('Object Repository/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/svg'))

WebUI.click(findTestObject('Object Repository/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/a_NREGISTREAZ-TE'))

WebUI.setViewPortSize(1400, 1400)

WebUI.setText(findTestObject('Object Repository/oka/Page_/input_E-MAIL _user_dataemail'), GlobalVariable.BrankoEmail)

WebUI.setEncryptedText(findTestObject('Object Repository/oka/Page_/input_PAROLA TA _user_datapassword1'), 'zorLBLN21vw/lPomnRSIYA==')

WebUI.setEncryptedText(findTestObject('Object Repository/oka/Page_/input_REINTRODUCERE PAROL _user_datapassword2'), 'zorLBLN21vw/lPomnRSIYA==')

WebUI.clickOffset(findTestObject('Object Repository/oka/Page_/label_ Am citit i neles  Notificarea de pro_676150'), 100, 
    0)

WebUI.click(findTestObject('Object Repository/oka/Page_/span_Continuare'))

WebUI.delay(5)

WebUI.click(findTestObject('Object Repository/oka/Page_/span_Confirm'))

WebUI.delay(5)

WebUI.takeScreenshot()

WebUI.closeBrowser()


