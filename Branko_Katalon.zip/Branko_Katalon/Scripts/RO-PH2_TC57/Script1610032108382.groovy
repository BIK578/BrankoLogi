import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://preprod.iqos.ro/')

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/button_ACCEPT TOATE'))

WebUI.selectOptionByValue(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/select_--                     IanuarieFebru_6c1619'), 
    '5', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/select_--                     2021202020192_796e36'), 
    '1970', true)

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/a_Verificare'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/path_GSETE UN MAGAZIN_path path-light'))

WebUI.setText(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/input_E-mail_user_login'), 
    'zirealdcs@yopmail.com')

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/label_Parola ta'))

WebUI.setEncryptedText(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/input_Parola ta_password'), 
    'Jypr6fxyrX5KTG73+NHFUA==')

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/img'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/button_Login'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS - Noul dispozitiv electronic fr f_e4e511/a_SHOP'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS 3 DUO/button_Comand acum'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS 3 DUO/button_Comand acum_1'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS 3 DUO/button_Comand acum_1_2'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_IQOS 3 DUO/svg'))

WebUI.setText(findTestObject('Object Repository/fran2020/Page_/input_Aipuncte (echivalentul aRON)_points'), '780')

WebUI.click(findTestObject('Object Repository/fran2020/Page_/div_Puncte de loialitate                   _9f4ba8'))

WebUI.click(findTestObject('Object Repository/fran2020/Page_/div_Aplicare'))

WebUI.closeBrowser()

