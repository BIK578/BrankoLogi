package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object BrankoVarijabla
     
    /**
     * <p></p>
     */
    public static Object BrankoEmail
     
    /**
     * <p>Profile default : ROExportFiles_toExcel</p>
     */
    public static Object BrankosBIK
     
    /**
     * <p></p>
     */
    public static Object Bananko
     
    /**
     * <p></p>
     */
    public static Object brankosamja
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            BrankoVarijabla = selectedVariables['BrankoVarijabla']
            BrankoEmail = selectedVariables['BrankoEmail']
            BrankosBIK = selectedVariables['BrankosBIK']
            Bananko = selectedVariables['Bananko']
            brankosamja = selectedVariables['brankosamja']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
