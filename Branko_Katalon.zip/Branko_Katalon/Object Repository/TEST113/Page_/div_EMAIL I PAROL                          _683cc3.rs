<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_EMAIL I PAROL                          _683cc3</name>
   <tag></tag>
   <elementGuidId>393c72ca-f291-4ab0-b83f-ceecd977a24f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.step-inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='step-01']/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>step-inner</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                        
                                
                                    EMAIL ȘI PAROLĂ

                                    Enter your email address and agree to the Terms &amp; Conditions to begin the process of setting up your IQOS account.
                                

                            

                                                                                        
                            
                                                                




    
                                    
                    E-MAIL *
                                            
                    
                                            
                                                        
                        
	
        //&lt;![CDATA[
            Tygh.tr(&quot;email_providers_ajax.waiting_text&quot;, &quot;În așteptarea ca serverul să valideze mesajele e-mail, așteptați&quot;);
            Tygh.tr(&quot;email_providers_ajax.blacklisted_email_error&quot;, &quot;Nu îți poți crea un cont cu această adresă de e-mail. Te rugăm să introduci alta.&quot;);
            Tygh.tr(&quot;email_providers_ajax.url&quot;, &quot;https://preprod.iqos.ro/index.php?dispatch=email_providers_ajax.validate_email&quot;);
        //]]>
	
    


			
	    

                                            
                    PAROLA TA *
                    
                                            
                        
 



    $(document).ready(function () {
        $('#show-hide-btn-3').on('click', function () {
            var password = $('#password1');
            if (password.attr('type') === 'password') {
                password.attr('type', 'text');
                $(this).html('&lt;div class=\&quot;hide-password\&quot;>\r\n&lt;img src=\&quot;https://d3hvodq7wnhe8p.cloudfront.net/images/email_templates/password/hide_(1)-svg.svg\&quot;/ style=\&quot;width: 27px; height: 21px;\&quot;> \r\n&lt;\/div>\r\n');
            } else {
                password.attr('type', 'password');
                $(this).html('&lt;div class=\&quot;show-password\&quot;>\r\n&lt;img src=\&quot;https://d3hvodq7wnhe8p.cloudfront.net/images/email_templates/password/eye-svg.svg\&quot;/ style=\&quot;width: 27px; height: 21px;\&quot;>\r\n&lt;\/div>');
            }
            password.focus();
        });
    });



    $(document).ready(function () {
        $('#password1').focus(function() {
            $('#pass_info').show();
        }).blur(function() {
            $('#pass_info').hide();
        });
    });


                                                                                            
                                Parola dumneavoastra trebuie sa contina minim 8 caractere.
            Deasemenea trebuie sa includa minim 2 din urmatoarele caracteristici:
            
                o litera mare
                o litera mica
                un numar
                un caracter special (e.g. % $ € *)
            
        
                            
                                                            

                
                    REINTRODUCERE PAROLĂ *
                    
                                            
                        



    $(document).ready(function () {
        $('#show-hide-btn-4').on('click', function () {
            var password = $('#password2');
            if (password.attr('type') === 'password') {
                password.attr('type', 'text');
                $(this).html('&lt;div class=\&quot;hide-password\&quot;>\r\n&lt;img src=\&quot;https://d3hvodq7wnhe8p.cloudfront.net/images/email_templates/password/hide_(1)-svg.svg\&quot;/ style=\&quot;width: 27px; height: 21px;\&quot;> \r\n&lt;\/div>\r\n');
            } else {
                password.attr('type', 'password');
                $(this).html('&lt;div class=\&quot;show-password\&quot;>\r\n&lt;img src=\&quot;https://d3hvodq7wnhe8p.cloudfront.net/images/email_templates/password/eye-svg.svg\&quot;/ style=\&quot;width: 27px; height: 21px;\&quot;>\r\n&lt;\/div>');
            }
            password.focus();
        });
    });



    $(document).ready(function () {
        $('#password1').focus(function() {
            $('#pass_info').show();
        }).blur(function() {
            $('#pass_info').hide();
        });
    });


                                                                
                                    
                        
    


    



                            

                                                            
                                                                                                                                                    




                
        
                                                                            
                                            
                            
                            
                            * Am citit și înțeles  Notificarea de protecție a datelor cu caracter personal.                         
                                    
                
                        
                                
            
                            
                    
                    
                    
                    Nu vreau să ratez ofertele (reduceri, ediții limitate, noutăți despre produse ș.a.) Philip Morris Trading S.R.L. și sunt de acord să primesc prin email sau SMS informații comerciale despre IQOS, HEETS sau alte produse/servicii conexe oferite de Philip Morris Trading S.R.L. sau de partenerii săi.
                
            
            
            
Please note, by unticking the marketing opt-in, you will lose your care plus membership and all related advantages.
        
    
            
        
    




                                                                    
                                                    
                                                    

                


                				
                    
                        
                            
                                Continuare
                                
                                        
        
    

                                
                            
                        
                    

                
                            
                        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;step-01&quot;)/div[@class=&quot;step-inner&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='step-01']/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ÎNREGISTREAZĂ-TE'])[1]/following::div[7]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CREEAZĂ UN CONT'])[1]/following::div[7]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div</value>
   </webElementXpaths>
</WebElementEntity>
