<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_.title h3 font-size40pxsection.page nav_5b56be</name>
   <tag></tag>
   <elementGuidId>2c137526-409d-44d1-958d-0ee43c4adc33</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.span12.header-inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='header']/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>span12 header-inner</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
.title h3 {
font-size:40px;
}

section.page nav ul {
    left: 0;
}
.page.choice .left header ul li {
  display: list-item;
  position: static;
  float: none;
  font-size: 16px;
  line-height: 1rem;
}
.page.choice p {
  font-size: 16px;
}
.page.choice .bottom {
  clear: both;
}

section.page ul li {
    display: list-item;
    float: inherit;
}

section.page nav ul li {
    display: inline;
    float: left;
}

.faulttree-container .step {
    list-style-type: inherit;
    display: inherit;
    margin-left: 0;
}

.left header .markdown-able {
    font-size: 22px;
    letter-spacing: 0px;
    margin-top:30px;
    text-align: inherit;
}

.left header .markdown-able ol {
    line-height: 16px;
    font-size: 16px;
}

.left header .markdown-able p {
   margin-bottom: 0;
}

.left header .markdown-able p + p {
   margin-top: 1.5rem;
}

.bottom footer {
    text-align: left;
    padding: 0 30px;
}

.goto + .goto button:not([data-page^=&quot;page-c24_other_issue&quot;]) {
    border: 2px solid red;
    color: red;
}

.faulttree-container .step .step {
  margin-left: 0;
}


 /* fix pentru mobile-view burger menu dublu */
    #main-nav > ul > li.show-md > div {
        display: none !important;
    }
    
    /*burger menu telefon */
    .flickity-prev-next-button {
        background-color: black !important;
        bottom: 4px !important;
        width: 2.5rem !important;
    }
    .flickity-prev-next-button.previous {
        box-shadow: 11px -13px 15px 0px rgba(0,0,0,0.75);
    }
    .flickity-prev-next-button.next {
        box-shadow: 11px 13px 15px 0px rgba(0,0,0,0.75)
    }
    
    @media (max-width: 960px) {
    #header #main-nav ul {
         width: 60%;
    }
    }
    
#onetrust-pc-sdk .category-host-list-handler {
text-decoration: underline;
}

#onetrust-pc-sdk #ot-pc-desc a {
margin-left: 0;
}
    

/* center images for mobile menu */
#sticky-filters {
    text-align: initial;
}
/* enable prev/next arrows */
.flickity-prev-next-button.previous {
    display: block !important;
    box-shadow: none;
}
.flickity-prev-next-button.next {
    display: block !important;
    box-shadow: none;
}
/* transparent background for arrows */
.flickity-prev-next-button {
    margin-right: -6px;
    margin-left: -6px;
    background-color: transparent !important; 
}

/* desktop menu fix */
#header #main-nav ul {
    font-size: .68rem;
    padding: 0.15rem .2rem;
    font-weight: 500;
}

#header #main-nav ul li {
    margin: 0;
}
@media (max-width: 1130px){
#header #main-nav ul li a {
    padding: 1.625rem .2rem;
    }
}

@media (min-width: 1280px){
#header #main-nav ul {
    font-size: .85rem;
    padding: 0.15rem .2rem;
    font-weight: normal;
    }
}

@media (max-width: 960px){
#header #main-nav ul {
    width: 60%;
    flex-direction: column;
    font-size: .9rem;
    margin: 0;
    padding: 0;
    list-style: none;
    height: 100%;
    display: flex;
    justify-content: center;
}
}

@media (max-width: 960px){
#header #main-nav ul li {
    padding: .5rem .5rem;
    margin: 0.40rem 0 0 0.20rem;
    margin-top: 0;
}
}

@media (max-width: 960px){
#header #main-nav ul li a {
    margin: 0;
    padding: .1rem 0;
    display: block;
    width: 80%;
    position: relative;
    letter-spacing: 0;
}
}

/* Checkout second step - Buttons */
.btn-back-icon {
    display: none;
}

.btn-consumer-info {
box-sizing: inherit !important;
font-family: inherit !important;
margin: 0 !important;
border: 0.05rem solid #111 !important;
border-radius: 0 !important;
cursor: pointer !important;
display: inline-block !important;
font-size: .6rem !important;
padding: 0.35rem 1.2rem !important;
text-transform: uppercase !important;
letter-spacing: .12rem !important;
font-weight: 700 !important;
height: 1.80rem !important;
line-height: 1rem !important;
outline: none !important;
text-align: center !important;
text-decoration: none !important;
user-select: none !important;
vertical-align: middle !important;
white-space: nowrap !important;
background: #111 !important;
border-color: #090909 !important;
color: #fff !important;
background-color: #333 !important;  
}

.btn-consumer-info:hover {
    background-color: #000 !important;
}




        
        
        
        DESPRE IQOS
        


                                
        
        
        
        DESPRE HEETS
        


                                
        
        
        
        ÎNCEARCĂ
        


                    
                        
        
        
        
        SHOP
        


                                
        
        
        
        ȘTIINȚĂ
        


                                
        
        
        
        PĂRERI
        


                                
        
        
        
        SHOP
        


                    
.flickity-prev-next-button {
        display: none !important;
    }
    ._flickity-container {
        display: none !important;
    }


$(function(){
var allClosed = false;
$(&quot;#main-nav > ul > li&quot;).each(function(){
if($(this).hasClass(&quot;tapped&quot;)){ allClosed = true; }
});
if (!allClosed ){ $(&quot;#main-nav > ul > li&quot;).first().addClass(&quot;tapped&quot;);}
});

                            


    
        
        
        
        
    
        IQOS 3 DUO
    
        IQOS 3 MULTI
    
        IQOS 2.4+
    
        HEETS
    



            
            IQOS 3 DUO
        
            
            IQOS 3 MULTI
        
            
            IQOS 2.4+
        
            
            HEETS
        
    

                        
        
        
        
        ASISTENȚĂ
        


                                
        
        
        
        ASISTENȚĂ
        


                    
.flickity-prev-next-button {
        display: none !important;
    }
    ._flickity-container {
        display: none !important;
    }


$(function(){
var allClosed = false;
$(&quot;#main-nav > ul > li&quot;).each(function(){
if($(this).hasClass(&quot;tapped&quot;)){ allClosed = true; }
});
if (!allClosed ){ $(&quot;#main-nav > ul > li&quot;).first().addClass(&quot;tapped&quot;);}
});

                            


    
        
        
        
        
        
        
    
        IQOS 3 DUO
    
        IQOS 3
    
        IQOS 3 Multi
    
        IQOS 2.4+
    
        IQOS 2.4
    
        INLOCUIRE
    



            
            IQOS 3 DUO
        
            
            IQOS 3
        
            
            IQOS 3 Multi
        
            
            IQOS 2.4+
        
            
            IQOS 2.4
        
            
            INLOCUIRE
        
    

                        
        
        
        
        IQOS CONNECT
        


                    
                        
        
        
        
        PROMISIUNEA
        


                    
                        
        
        
        
        CLUB
        


                    
                        
        
        
        
        Contact
        


                    0800030333
                        
        
        
        
        GĂSEȘTE UN MAGAZIN
        


                    
                        
    



    
        
            
        
    
    


        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;header&quot;)/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;row-fluid&quot;]/div[@class=&quot;span12 header-inner&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='header']/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
