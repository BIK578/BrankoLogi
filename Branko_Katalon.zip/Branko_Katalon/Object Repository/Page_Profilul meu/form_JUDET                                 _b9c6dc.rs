<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_JUDET                                 _b9c6dc</name>
   <tag></tag>
   <elementGuidId>bdae1f9f-c085-4bac-a718-0e34dc8c0d9a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='profile_form']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>form[name=&quot;profile_form&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>profile_form</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>action</name>
      <type>Main</type>
      <value>https://preprod.iqos.ro/my-iqos</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>autocomplete</name>
      <type>Main</type>
      <value>off</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>cm-processed-form</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                
                
                                    
                                                                                                                                                                                                                                                


        


            



                                        
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            JUDET
                     *
                                    
                

                                                                                                                                                
              
                
                                        
                                                                    
                            - Selectare stat -
                                                                                                
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                                    ALBAARADARGESBACAUBIHORBISTRITA-NASAUDBOTOSANIBRAILABRASOVBUCURESTIBUZAUCALARASICARAS-SEVERINCLUJCONSTANTACOVASNADAMBOVITADOLJGALATIGIURGIUGORJHARGHITAHUNEDOARAIALOMITAIASIILFOVMARAMURESMEHEDINTIMURESNEAMTOLTPRAHOVASALAJSATU MARESIBIUSUCEAVATELEORMANTIMISTULCEAVALCEAVASLUIVRANCEA
                        
                        
                                    


            
                                

            

                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            LOCALITATE
                     *
                                    
                

                                                                                                                                                                                    
              
                        
    
            
                                

            

                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            SECTOR
                    
                                     *
                

                                    
              
                
                                    
                    
                                            

                                

            
                                

            

                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            NUMĂR DE TELEFON
                     *
                                    
                

                                    
                                            
                            
                                

            

                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            COUNTRY
                    
                                    
                

                                    
              
                
                                    
                        
                        - Selectate țară -
                                                Afghanistan
                                                Aland Islands
                                                Albania
                                                Algeria
                                                American Samoa
                                                Andorra
                                                Angola
                                                Anguilla
                                                Antarctica
                                                Antigua and Barbuda
                                                Argentina
                                                Armenia
                                                Aruba
                                                Asia-Pacific
                                                Australia
                                                Austria
                                                Azerbaijan
                                                Bahamas
                                                Bahrain
                                                Bangladesh
                                                Barbados
                                                Belarus
                                                Belgium
                                                Belize
                                                Benin
                                                Bermuda
                                                Bhutan
                                                Bolivia
                                                Bosnia and Herzegowina
                                                Botswana
                                                Bouvet Island
                                                Brazil
                                                British Indian Ocean Territory
                                                British Virgin Islands
                                                Brunei Darussalam
                                                Bulgaria
                                                Burkina Faso
                                                Burundi
                                                Cambodia
                                                Cameroon
                                                Canada
                                                Cape Verde
                                                Cayman Islands
                                                Central African Republic
                                                Chad
                                                Chile
                                                China
                                                Christmas Island
                                                Cocos (Keeling) Islands
                                                Colombia
                                                Comoros
                                                Congo
                                                Cook Islands
                                                Costa Rica
                                                Cote D'ivoire
                                                Croatia
                                                Cuba
                                                Curaçao
                                                Cyprus
                                                Czech Republic
                                                Denmark
                                                Djibouti
                                                Dominica
                                                Dominican Republic
                                                East Timor
                                                Ecuador
                                                Egypt
                                                El Salvador
                                                Equatorial Guinea
                                                Eritrea
                                                Estonia
                                                Ethiopia
                                                Europe
                                                Falkland Islands (Malvinas)
                                                Faroe Islands
                                                Fiji
                                                Finland
                                                France
                                                France, Metropolitan
                                                French Guiana
                                                French Polynesia
                                                French Southern Territories
                                                Gabon
                                                Gambia
                                                Georgia
                                                Germany
                                                Ghana
                                                Gibraltar
                                                Greece
                                                Greenland
                                                Grenada
                                                Guadeloupe
                                                Guam
                                                Guatemala
                                                Guernsey
                                                Guinea
                                                Guinea-Bissau
                                                Guyana
                                                Haiti
                                                Heard and McDonald Islands
                                                Honduras
                                                Hong Kong
                                                Hungary
                                                Iceland
                                                India
                                                Indonesia
                                                Iraq
                                                Ireland
                                                Islamic Republic of Iran
                                                Isle of Man
                                                Israel
                                                Italy
                                                Jamaica
                                                Japan
                                                Jersey
                                                Jordan
                                                Kazakhstan
                                                Kenya
                                                Kiribati
                                                Korea
                                                Korea, Republic of
                                                Kuwait
                                                Kyrgyzstan
                                                Laos
                                                Latvia
                                                Lebanon
                                                Lesotho
                                                Liberia
                                                Libyan Arab Jamahiriya
                                                Liechtenstein
                                                Lithuania
                                                Luxembourg
                                                Macau
                                                Macedonia
                                                Madagascar
                                                Malawi
                                                Malaysia
                                                Maldives
                                                Mali
                                                Malta
                                                Marshall Islands
                                                Martinique
                                                Mauritania
                                                Mauritius
                                                Mayotte
                                                Mexico
                                                Micronesia
                                                Moldova, Republic of
                                                Monaco
                                                Mongolia
                                                Montenegro
                                                Montserrat
                                                Morocco
                                                Mozambique
                                                Myanmar
                                                Namibia
                                                Nauru
                                                Nepal
                                                Netherlands
                                                New Caledonia
                                                New Zealand
                                                Nicaragua
                                                Niger
                                                Nigeria
                                                Niue
                                                Norfolk Island
                                                Northern Mariana Islands
                                                Norway
                                                Oman
                                                Pakistan
                                                Palau
                                                Palestine Authority
                                                Panama
                                                Papua New Guinea
                                                Paraguay
                                                Peru
                                                Philippines
                                                Pitcairn
                                                Poland
                                                Portugal
                                                Puerto Rico
                                                Qatar
                                                Republic of Serbia
                                                Reunion
                                                Romania
                                                Russian Federation
                                                Rwanda
                                                Saint Lucia
                                                Samoa
                                                San Marino
                                                Sao Tome and Principe
                                                Saudi Arabia
                                                Senegal
                                                Serbia
                                                Seychelles
                                                Sierra Leone
                                                Singapore
                                                Sint Maarten
                                                Slovakia
                                                Slovenia
                                                Solomon Islands
                                                Somalia
                                                South Africa
                                                Spain
                                                Sri Lanka
                                                St. Helena
                                                St. Kitts and Nevis
                                                St. Pierre and Miquelon
                                                St. Vincent and the Grenadines
                                                Sudan
                                                Suriname
                                                Svalbard and Jan Mayen Islands
                                                Swaziland
                                                Sweden
                                                Switzerland
                                                Syrian Arab Republic
                                                Taiwan
                                                Tajikistan
                                                Tanzania, United Republic of
                                                Thailand
                                                Togo
                                                Tokelau
                                                Tonga
                                                Trinidad and Tobago
                                                Tunisia
                                                Turkey
                                                Turkmenistan
                                                Turks and Caicos Islands
                                                Tuvalu
                                                Uganda
                                                Ukraine
                                                United Arab Emirates
                                                United Kingdom (Great Britain)
                                                United States
                                                United States Virgin Islands
                                                Uruguay
                                                Uzbekistan
                                                Vanuatu
                                                Vatican City State
                                                Venezuela
                                                Viet Nam
                                                Wallis And Futuna Islands
                                                Western Sahara
                                                Yemen
                                                Zaire
                                                Zambia
                                                Zimbabwe
                                                

                    
                
            
                                

            

    








    /* Prefix phone number */
    .shipping-phone.-focus.input-container:before,
    .shipping-phone.-filled.input-container:before {
        content: &quot;07&quot;;
        height: 40px;
        position: absolute;
        display: block;
        line-height: 41px;
        padding-left: 12px;
    }
    .shipping-phone.-focus.-expanded.input-container:before,
    .shipping-phone.-filled.-expanded.input-container:before {
        height: 56px;
        line-height: 57px;
    }
    .shipping-phone.-focus.input-container input,
    .shipping-phone.-filled.input-container input {
        padding-left: 38px;
    }
    .user-info .s_phone:before, .user-info .b_phone:before {
        content: &quot;07&quot;;
    }






                    



                    

                
                
            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;address&quot;)/form[@class=&quot;cm-processed-form&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@name='profile_form']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='address']/form</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Salvare'])[3]/following::form[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Anulare'])[3]/following::form[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/form</value>
   </webElementXpaths>
</WebElementEntity>
