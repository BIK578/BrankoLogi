<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>html_Profilul meu                .tippy-box_a198af</name>
   <tag></tag>
   <elementGuidId>f2af2c11-c809-43ac-99fc-29edac7928e0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='']/parent::*</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>html.profiles-update.cap_cookies.cap_flexbox.cap_flexwrap.age-gate-hidden.not_IE</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>html</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>profiles-update cap_cookies cap_flexbox cap_flexwrap age-gate-hidden not_IE</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>lang</name>
      <type>Main</type>
      <value>ro-RO</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-theme</name>
      <type>Main</type>
      <value>royal</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-transition</name>
      <type>Main</type>
      <value>transition</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-home-animation</name>
      <type>Main</type>
      <value>no-animation</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-age-gate-fade-in</name>
      <type>Main</type>
      <value>yes</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-useragent</name>
      <type>Main</type>
      <value>Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
Profilul meu














    
            .tippy-box[data-animation=fade][data-state=hidden]{opacity:0}[data-tippy-root]{max-width:calc(100vw - 10px)}.tippy-box{position:relative;background-color:#333;color:#fff;border-radius:4px;font-size:14px;line-height:1.4;outline:0;transition-property:transform,visibility,opacity}.tippy-box[data-placement^=top]>.tippy-arrow{bottom:0}.tippy-box[data-placement^=top]>.tippy-arrow:before{bottom:-7px;left:0;border-width:8px 8px 0;border-top-color:initial;transform-origin:center top}.tippy-box[data-placement^=bottom]>.tippy-arrow{top:0}.tippy-box[data-placement^=bottom]>.tippy-arrow:before{top:-7px;left:0;border-width:0 8px 8px;border-bottom-color:initial;transform-origin:center bottom}.tippy-box[data-placement^=left]>.tippy-arrow{right:0}.tippy-box[data-placement^=left]>.tippy-arrow:before{border-width:8px 0 8px 8px;border-left-color:initial;right:-7px;transform-origin:center left}.tippy-box[data-placement^=right]>.tippy-arrow{left:0}.tippy-box[data-placement^=right]>.tippy-arrow:before{left:-7px;border-width:8px 8px 8px 0;border-right-color:initial;transform-origin:center right}.tippy-box[data-inertia][data-state=visible]{transition-timing-function:cubic-bezier(.54,1.5,.38,1.11)}.tippy-arrow{width:16px;height:16px;color:#333}.tippy-arrow:before{content:&quot;&quot;;position:absolute;border-color:transparent;border-style:solid}.tippy-content{position:relative;padding:5px 9px;z-index:1}
        


    
    
                                                


















    



    //&lt;![CDATA[

    (function(_, $) {

        _.tr({
            block_popup_title: 'Block content',
            block_popup_content: 'Block content',
            cannot_buy: 'Nu puteti cumpara produsul cu aceste optiuni de variante',
            no_products_selected: 'Nici un produs selectat',
            error_no_items_selected: 'Niciun produs selectat! Cel putin o casuta trebuie bifata pentru a efectua o actiune.',
            delete_confirmation: 'Sunteti sigur ca doriti sa stergeti articolele selectate?',
            text_out_of_stock: 'Stoc momentan indisponibil. Accesează pagina produsului și abonează-te pentru notificări.',
            items: 'Articol(e)',
            text_required_group_product: 'Va rugam sa selectati un produs pentru grupul necesar [nume_grup]',
            save: 'Salvare',
            close: 'închidere',
            notice: 'Notificare',
            warning: 'Notificare',
            error: 'Eroare',
            text_are_you_sure_to_proceed: 'Sunteți sigur că doriți să continuați?',
            text_invalid_url: 'Ati introdus un URL invalid',
            error_validator_email: 'Adresa de e-mail din câmpul &lt;b>[field]&lt;\/b> este invalidă.',
            error_validator_phone: 'Formatul numarului de telefon din campul &lt;b>[field]&lt;\/b> este invalid. Formatul corect este 07xxxxxxxx',
            error_validator_integer: 'Valoarea campului &lt;b>[field]&lt;\/b> este invalida. Ar trebui sa fie o valoare intreaga.',
            error_validator_multiple: 'Campul &lt;b>[field]&lt;\/b> nu conține opțiunile selectate.',
            error_validator_password: 'Parolele din campul &lt;b>[field2]&lt;\/b> si &lt;b>[field]&lt;\/b> nu se potrivesc.',
            error_validator_required: 'Câmpul &lt;b>[field]&lt;\/b> este obligatoriu.',
            error_validator_zipcode: 'Codul postal din campul &lt;b>[field]&lt;\/b> este incorect. Formatul corect este [extra].',
            error_validator_message: 'Valoarea câmpului &lt;b>[field]&lt;\/b> este invalidă.',
            text_page_loading: 'in curs de procesare... Cererea dvs. este in curs de procesare, va rugam asteptati.',
            error_ajax: 'Ups, ceva nu a mers bine ([error]). Te rugăm să încerci din nou.',
            text_changes_not_saved: 'Modificarile dvs.nu au fost salvate.',
            text_data_changed: 'Setarile nu au fost schimbate. Apasati OK pentru a continua sau ANULARE pentru a ramane pe aceeasi pagina.',
            error_card_number_not_valid: 'Numărul de card nu este valid în câmpul &lt;b>[field]&lt;\/b>',
            more: 'Mai mult',
            cookie_is_disabled: 'For a complete shopping experience, please &lt;a href=\&quot;http://www.wikihow.com/Enable-Cookies-in-Your-Internet-Web-Browser\&quot; target=\&quot;_blank\&quot;>set your browser to accept cookies&lt;\/a>',
            strikeiron_checking_email: '_strikeiron_checking_email',
            strikeiron_checking_phone: '_strikeiron_checking_phone',
            complete_the_necessary_fields: '_complete_the_necessary_fields'
        });

        $.extend(_, {
            ngp_project: 'core',  // [norton]
            index_script: 'index.php',
            changes_warning: /*'Y'*/'N',
            currencies: {
                'primary': {
                    'decimals_separator': ',',
                    'thousands_separator': '.',
                    'decimals': '0'
                },
                'secondary': {
                    'decimals_separator': ',',
                    'thousands_separator': '.',
                    'decimals': '0',
                    'coefficient': '1.00000'
                }
            },
            default_editor: 'ace_editor',

            frontend_css: 'https://d3hvodq7wnhe8p.cloudfront.net/statics/design/themes/royal/css/standalone.af3a287f91705ee07a1ca1bc10c9adec1608122982.css',

            default_previewer: 'prettyphoto',
            current_path: '',
            current_location: 'https://preprod.iqos.ro',
            images_dir: 'https://preprod.iqos.ro/design/themes/royal/media/images',
            notice_displaying_time: 45,
            cart_language: 'ro',
            default_language: 'en',
            cart_prices_w_taxes: false,
            translate_mode: false,
            theme_name: 'royal',
            regexp: [],
            current_url: 'index.php?dispatch=profiles.update&amp;selected_section=general',
            current_host: 'preprod.iqos.ro',
            init_context: '',
            modal_login: false,
            show_login_popup : false,
            bi_zip_codes_city_autocomplete_attr: 'nope'
        });

        
        $(document).ready(function(){
            $.runCart('C');
        });

        
            }(Tygh, Tygh.$));
    //]]>


    //&lt;![CDATA[
    
    var defaultMaskRules = {
        numeric: 'N',
        alphabetical: 'L',
        alphanumeric: '*'
    }

    var defaultRulesInUse = null;
    var phoneRulesInUse = null;
    var zipcodeRulesInUse = null;

    function setMaskRules(newRules) {
        var newRules = newRules || {};
        var rulesInUse = $.extend({}, defaultMaskRules, newRules);

        $.mask.definitions = {};

        $.each(rulesInUse, function(key, value){
            switch(key) {
                case 'numeric':
                    $.mask.definitions[value] = '[0-9]';
                    break;
                case 'alphabetical':
                    $.mask.definitions[value] = '[A-Za-z]';
                    break;
                case 'alphanumeric':
                    $.mask.definitions[value] = '[A-Za-z0-9]';
                    break;
            }
        });

        return rulesInUse;
    }
    

    var clearExtraClasses = function() {
        if (!$(this).val()) {
            $(this).parent().removeClass('-filled -success');
        }
    }

    setMaskRules();

            $(document).ready(function() {
            $('#checkout_steps').on('click', '.cm-checkout-place-order', function(e){
                var button_id = $('.cm-checkout-place-order').prop('id');
                var is_click = $('#' + button_id).hasClass('one-click-is-done');
                var form = $('form[name=payments_form_' + button_id.str_replace('place_order_', '') + ']');

                var requirements = fn_bi_core_get_fill_requirements(form);
                var result = fn_bi_core_check_fields(form, requirements);

                if (result) {
                    $('#' + button_id).addClass('one-click-is-done');
                }

                if (result &amp;&amp; is_click) {
                    $('#' + button_id).prop('disabled', true);
                }
            });
        });
    
            var phoneMask = 'NNNNNNNNNN';

        
        var handleMasks = function () {
            var fields = $(&quot;.cm-phone-mask, #elm_phone, .phone, input[name*='phone']&quot;);
            var placeholder = ' ';
            var autoclear  = true;

                        fields.filter(':text').mask(phoneMask, { placeholder: placeholder, autoclear: autoclear });

                            fields.on('blur', clearExtraClasses)
            
            fields.filter(':text').each(function () {
                $(this).data('caOldValue', $(this).val());
            });

            
                    };

        $(document).ready(function(){
            handleMasks();
        });

        $(document).on('phone-mask', function(){
            handleMasks();
        }).trigger('phone-mask');
    
    setMaskRules();

    
    

    // phone checking override
    $.is.phone = function(val) {

        if(!val){
            return false;
        }

        var phoneMinLength = '10';
        var phoneMaxLength = '10';

        if (phoneMinLength) {
            if (val.length &lt; phoneMinLength) {
                return false;
            }
        }

        if (phoneMaxLength) {
            if (val.length > phoneMaxLength) {
                return false;
            }
        }

                    var regEx = /07\d{8}/i;
            if (!regEx.test(val)) {
                return false;
            }
        
        return true;
    };
    //]]>

    $.ceFormValidator('registerValidator', {
        class_name: 'cm-sd-validate-by-rule',
        message: &quot;&quot;,
        func: function(id) {

            var rule = new RegExp($(&quot;label[for='&quot; + id +&quot;']&quot;).attr(&quot;data-regex-rule&quot;));
            var value  = $('#' + id).val();

            if ($('#' + id).hasClass(&quot;cm-required&quot;) || value.length > 0) {
                if (value.search(rule) == -1) {
                    this.message = $(&quot;label[for='&quot; + id + &quot;']&quot;).attr(&quot;data-regex-error&quot;);
                    return false;
                }
            }
            return true;
        }
    });

    

    //&lt;![CDATA[
        (function() {
            function verifySession (a) {
                setTimeout(function () {
                    $.ceAjax(&quot;request&quot;, fn_url('auth.verify_session'), {
                        method: 'get',
                        cache: false,
                        callback: function(data) {
                            if (data.session_expires > 0) {
	                            verifySession(data.session_expires);
                            } else {
	                            location.href = fn_url('auth.logout');
                            }
                        }
                    })
                }, a * 1000);
            };
            
            verifySession(1800);
        })();
    //]]>
    

    Tygh.tr('buy_together_fill_the_mandatory_fields', 'Vă rugăm să specificați opțiunile produsului înainte de a adăuga combinația în coș.');
    Tygh.tr('buy_together_qty_warning', 'This quantity is not allowed for the product. Product quantity must be between [min_qty] and [max_qty] units.');


//&lt;![CDATA[
var revamp2020zipCode = false;

function init_zipcode_form(_, $) {
    let ajax_zip_code = $('.select-vendor .ajax_zip_code');
    if (ajax_zip_code.hasClass(&quot;ready&quot;)) return;
    ajax_zip_code.addClass(&quot;ready&quot;);
    let target_id = ajax_zip_code.data('to');
    let target_wrapper = $('#' + target_id);

    if (_.disable_province_selection) {
        $('select[name=&quot;user_data[s_state]&quot;]').attr('disabled', 'disabled');
    }

    $('.ty-calendar__input').on('click', function (e) {
        $('.ui-datepicker-month').focus();
    });



    if (revamp2020zipCode) {
        $(&quot;#&quot;+target_id).find(&quot;.ajax-popup-tools&quot;).mCustomScrollbar({
            axis: 'y',
            scrollInertia: 200,
            documentTouchScroll: true,
            theme: 'iqos-revamp',
            autoHideScrollbar: false
        });
    }

    var isBindedInputEvent = false;
    ajax_zip_code.on('focus', function (e) {

        var id = this.dataset.to;

        if ($('#' + id + ' .search-shop input').length > 0) {
                        $('#' + id).show();
            
            if (revamp2020zipCode) {

                if(!isBindedInputEvent){

                    isBindedInputEvent = true;
                    ajax_zip_code.on( 'change' , function (e) {
                        if(ajax_zip_code.val() != &quot;&quot; ){
                            var sValue = ajax_zip_code.val();
                            var aValue = sValue.split(&quot; &quot;);
                            ajax_zip_code.val(aValue[0])
                            ajax_zip_code.parents(&quot;.input-container&quot;).addClass(&quot;-filled&quot;);
                        }
                    });

                    ajax_zip_code.on( 'input' , function (e) {
                                                $('#' + id).show();
                                            });

                    var $inputAutocomplete = $('#' + this.dataset.to + ' .search-shop input');
                    ajax_zip_code.on( 'input', function (e) {
                        $inputAutocomplete.val(ajax_zip_code.val());
                        $inputAutocomplete.trigger(&quot;keyup&quot;);
                    });
                }

            } else {
                setTimeout(function () {
                    $('#' + id + ' .search-shop input').focus();
                }, 10);
            }

        }
    });

    $(document).on('mousedown', function (e) {
        if ($('.form-autocomplete-wrapper').length) {
            $('.form-autocomplete-wrapper').each(function() {
                if ($(this).is(':visible') &amp;&amp; !$(this).is(e.target) &amp;&amp; $(this).has(e.target).length === 0) {
                    $(this).hide();
                }
            });
        }
    });

    
    }

(function(_, $) {
    $.extend(_, {
        default_country: 'RO',
        sector_cities: [&quot;BUCURESTI&quot;],
	    use_autocomplete_city_on_zip_code: '',
	    check_zipcode: 'N',
        check_city_value: 'Y'
    });

    
        $(document).ready(function() {
        !!window['init_zipcode_form'] &amp;&amp; init_zipcode_form(_, $);
    });
}(Tygh, Tygh.$));
//]]>


//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
                                    $.ceFormValidator('registerValidator', {
                    class_name: 'cm-sd-check-non-latin-symbol',
                    message: '_error_password_policy_char_only',
                    func: function(id) {
                        var value  = $('#' + id).val();

                        // matched rules: [uppercase, digit, special char, lowercase]
                        var matches = [new RegExp('^(?=.*[A-Z]).+$'), new RegExp('\\d+'), new RegExp('^(?=.*[^\\da-zA-Z]).+$'), new RegExp('^(?=.*[a-z]).+$')];
                        var res = 0;

                        for (var i = 0; i &lt; matches.length; i++) {
                            if (matches[i].test(value)) {
                                res++;
                            }
                        }

                        return res >= 3;
                    }
                });
                        });
}(Tygh, Tygh.$));
//]]>


//&lt;![CDATA[
    Tygh.tr('bring_me_there', 'Afișare rută');
    Tygh.tr('store_locator.info_forcelocation', 'Please, insert a city to show the stores around.');
    Tygh.tr('store_locator_no_geolocation_data', 'Din păcate, nu am găsit locația dvs. Vă rugăm să modificați criteriul de căutare și să încercați din nou');
    Tygh.tr('store_locator.user_geolocation_denied', 'Please, enable your Geolocation for our website.');
    Tygh.tr('sl_opening_hours', 'Program de lucru');
    Tygh.tr('store_locator_no_result_found', 'Nu au fost găsite rezultate, te rugăm să încerci din nou pe o rază de căutare mai extinsă.');
    Tygh.tr('bi_store_locator.error_support_geolocation', 'Your browser doesn\'t support the geolocation.');
    Tygh.tr('bi_store_locator.error_invalid_address', 'Invalid address');
    Tygh.tr('bi_store_locator.geolocation_error_denied', 'You denied geolocation for this website, please check your settings.');
    Tygh.tr('bi_store_locator.geolocation_error_unavailable', 'Location information is unavailable.');
    Tygh.tr('bi_store_locator.geolocation_error_timeout', 'The request to get location timed out.');
    Tygh.tr('bi_store_locator.geolocation_error_occured', 'An unknown error occurred.');
    Tygh.tr('bi_store_locator.phone', 'Phone:');
//]]>


    (function(_, $) {
        _.tr({
            onboardingstep_age_verification_verify: '',
            onboardingstep_contact_information:     'full name, email, account password, address line 1, address line 2, city, state, zip, country, mobile number, language preference',
            gatm_brand:                             'iQOS',
            gatm_in_stock:                          'In Stock',
            gatm_out_stock:                         'Out of Stock',
            gatm_product_version:                   ''
        });
        $.extend(_, {
            add_additional_third_step_tracking: false        });
    }(Tygh, Tygh.$));

dataLayer = [{
    &quot;pageInstanceID&quot;: &quot;&quot;,
    &quot;environment&quot;: &quot;staging&quot;,
    &quot;environmentVersion&quot;: &quot;ecom_2.20-RC-8490&quot;,
    &quot;page&quot;: {
        &quot;pageInfo&quot;: {
            &quot;pageID&quot;: &quot;page-edcd9&quot;,
            &quot;pageName&quot;: &quot;my account&quot;,
            &quot;pageBrand&quot;: &quot;p1&quot;
        },
        &quot;category&quot;: {
            &quot;primaryCategory&quot;: &quot;my account&quot;,
            &quot;subCategory1&quot;: &quot;&quot;,
            &quot;subCategory2&quot;: &quot;&quot;,
            &quot;pageType&quot;: &quot;&quot;
        },
        &quot;attributes&quot;: {
            &quot;country&quot;: &quot;RO&quot;,
            &quot;language&quot;: &quot;ro-RO&quot;,
            &quot;currency&quot;: &quot;RON&quot;
        }
    },
    &quot;user&quot;: {
        &quot;affiliation&quot;: &quot;Registered&quot;,
        &quot;spiceID&quot;: &quot;&quot;,
        &quot;dcsID&quot;: &quot;23848&quot;,
        &quot;ecomID&quot;: &quot;4782&quot;,
        &quot;campaignSpiceID&quot;: &quot;&quot;,
        &quot;birthYear&quot;: &quot;1997&quot;
    }
}];
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&amp;l='+l:'';j.async=true;j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-PLBRD26');

        var gaeec_currency_code = 'RON';
    

if (document.cookie.indexOf(&quot;iqos-age-verified=&quot;) >= 0) {
    document.documentElement.className = document.documentElement.className + ' age-gate-hidden';
}


    $(document).ready(function(){

        $('.loyaltyAccess').on('click',function(){
            loyaltyLogin();
        });

        function loyaltyLogin() {
            Tygh.$.ceAjax('request', fn_url('profiles.loyalty_access'), {
                method: 'POST',
                callback: function(data) {
                    if ( typeof data.openlogin != 'undefined') {
                        $(data.openlogin).click();
                        $('.royal-login-form input[name=&quot;redirect_url&quot;]').val(fn_url(&quot;profiles.loyalty_access&quot;));
                    }

                    if ( typeof data.loyaltyLoginData != 'undefined') {
                        window.location.href = data.loyaltyLoginData;
                    }
                }
            });
        };

        $(function(){
            $(&quot;#success_modal .modal-overlay, #success_modal .close&quot;).bind('click', function(){
                $(&quot;#success_modal&quot;).removeClass('active');
            })
        })
    })

    function copyToClipBoard(elementID) {
        var input = $(elementID),
            success = true,
            textArea = document.createElement('textarea');

        textArea.value = input.val().replace(/&lt;br\s*[\/]?>/gi, &quot;\r\n&quot;).trim();
        document.body.appendChild(textArea);

        if (navigator.userAgent.match(/ipad|iphone/i)) {
            var range = document.createRange(),
                selection = window.getSelection();
            range.selectNodeContents(textArea);
            selection.removeAllRanges();
            selection.addRange(range);
            textArea.setSelectionRange(0, 999999);
        } else {
            textArea.select();
        }

        try {
            success = document.execCommand('copy', false, null); // copy
        } catch (e) {

        }

        document.body.removeChild(textArea);

        if (success) {
            if (input.attr('data-ca-modal-text')) {
                new_text = input.attr('data-ca-modal-text');
                $(&quot;#modal_text&quot;).html(new_text);
            }
            $(&quot;#success_modal&quot;).addClass('active');
        }
    }


    $(document).ready(function() {
        if ($(&quot;#bank_country&quot;).length > 0) {
            $(&quot;#bank_country&quot;).on('change', function () {
                let Value = $(this).val(),
                    errorMsgElm = $('.bank_country-error-message'),
                    profileHintElm = $('.bank_country-profile-hint'),
                    isCorrect = /^[a-zA-Z]{2}$/.test(Value) ? true : false;

                if (!isCorrect) {
                    errorMsgElm.css('color', '#FF0000').show();
                    profileHintElm.hide();
                } else {
                    errorMsgElm.hide();
                    profileHintElm.show();
                }
            });
        }

        if ($(&quot;#bank_key&quot;).length > 0) {
            $(&quot;#bank_key&quot;).on('change', function () {
                let Value = $(this).val(),
                    errorMsgElm = $('.bank_key-error-message'),
                    profileHintElm = $('.bank_key-profile-hint'),
                    isCorrect = /^[0-9 a-z A-Z]{3,6}$|^[0-9]{3,4}-?[0-9]{1}$/.test(Value) ? true : false;

                if (!isCorrect) {
                    errorMsgElm.css('color', '#FF0000').show();
                    profileHintElm.hide();
                } else {
                    errorMsgElm.hide();
                    profileHintElm.show();
                }
            });
        }

        if ($(&quot;#bank_account&quot;).length > 0) {
            $(&quot;#bank_account&quot;).on('change', function () {
                let minAccountNumberDigits = 11;
                let maxAccountNumberDigits = 17;
                let Value = $(this).val(),
                    errorMsgElm = $('.bank_account-error-message'),
                    profileHintElm = $('.bank_account-profile-hint'),
                    isCorrect = new RegExp(`^[0-9]{${minAccountNumberDigits},${maxAccountNumberDigits}}$`).test(Value);

                if (!isCorrect) {
                    errorMsgElm.css('color', '#FF0000').show();
                    profileHintElm.hide();
                } else {
                    errorMsgElm.hide();
                    profileHintElm.show();
                    if (Value.length &lt; maxAccountNumberDigits) {
                        let nbMissingDigits = maxAccountNumberDigits - Value.length, missingDigits = '';
                        for (var i = 0; i &lt; nbMissingDigits; i++) {
                            missingDigits += '0';
                        }
                        $(this).val(missingDigits + $(this).val());
                    }
                }
            });
        }

        $(&quot;#iban&quot;).on('change', function () {
            errorMsgElm = $('.iban-error-message');
            profileHintElm = $('.gdpr-iban .form-input-hint');

            if (!validateIban()) {
                errorMsgElm.css('color', '#FF0000').show();
                profileHintElm.hide();
            } else {
                errorMsgElm.hide();
                profileHintElm.show();
            }
        });

        $(&quot;form[name ='profile_gdpr_edit']&quot;).submit(function (e) {
            if ($(&quot;#iban&quot;).length > 0 &amp;&amp; !validateIban()) {
                $(&quot;#update_gdpr .loading&quot;).hide();
                return false;
            }
        });

        $(&quot;#update_gdpr a.save-btn&quot;).click(function (e) {
            if ($(&quot;#iban&quot;).length > 0 &amp;&amp; !validateIban()) {
                return false;
            }
        }).prop(&quot;onclick&quot;, null);

        function validateIban() {
            if ($(&quot;#iban&quot;).length > 0) {
                let minAccountNumberDigits = 11;
                let maxAccountNumberDigits = 17;
                let Value = $(&quot;#iban&quot;).val(),
                        isCorrect = new RegExp(`^[a-zA-Z]{2}[0-9]{${minAccountNumberDigits},${maxAccountNumberDigits}}$`).test(Value);

                return isCorrect;
            }
            return false;
        }
    });


(function(_, $) {
    $.ceEvent('on', 'ce.commoninit', function(context) {
        context.find('.sd-slide-flickity').each(function(){
            var id = $(this).attr('id'),
                main = $(this).find('.product-slider-main-block'),
                isMobile = Tygh.$(&quot;body&quot;).hasClass(&quot;isMobile&quot;),
                showDotsInMobile = false,
                navDots = isMobile &amp;&amp; showDotsInMobile;

            if (id &amp;&amp; main.length > 0) {
                var slide = main.find('.slider-cell');

                var product_slider = main.flickity({
                    pageDots        : navDots &amp;&amp; slide.length > 1
                    ,wrapAround     : true
                    ,prevNextButtons: false
                    ,setGallerySize : false
                    ,bgLazyLoad     : true
                    ,draggable      :slide.length > 1
                });

                if (slide.length > 1) {
                    if (!navDots) {
                        $(this).find('.product-slider-nav').flickity({
                            asNavFor        : '#' + id + ' .product-slider-main-block'
                            ,pageDots       : false
                            ,prevNextButtons: false
                            ,groupCells     : 3
                            ,cellAlign      : 'left'
                            ,bgLazyLoad     : true
                            ,setGallerySize : false
                            ,wrapAround     : false
                            ,draggable      : slide.length > 1
                        });
                    }

                    main.append('\
                        &lt;div class=&quot;slider-controls product-slider-controls light-controls&quot;>\
                            &lt;div class=&quot;slider-controls-arrow arrow-left&quot;>\
                                &lt;svg class=&quot;path&quot; width=&quot;17&quot; height=&quot;31&quot; viewBox=&quot;0 0 17 31&quot;>\
                                    &lt;polygon points=&quot;16.8,0.7 16.2,0 0.2,15 0.2,15 0.2,15 15.2,31 15.9,30.3 1.6,15&quot;>&lt;/polygon>\
                                &lt;/svg>\
                            &lt;/div>\
                            &lt;div class=&quot;slider-controls-arrow arrow-right&quot;>\
                                &lt;svg class=&quot;path&quot; width=&quot;17&quot; height=&quot;31&quot; viewBox=&quot;0 0 17 31&quot;>\
                                    &lt;polygon points=&quot;0.2,30.3 0.8,31 16.8,16 16.8,16 16.8,16 1.8,0 1.1,0.7 15.4,16&quot;>&lt;/polygon>\
                                &lt;/svg>\
                            &lt;/div>\
                        &lt;/div>\
                    ');

                    main.find('.arrow-left').click(function(event) {
                        product_slider.flickity('previous');
                    });

                    main.find('.arrow-right').click(function(event) {
                        product_slider.flickity('next');
                    });

                } else {
                    $(this).find('.product-slider-nav').remove();
                }
            }
        });
    });

    $(document).ready(function() {

        $(document).on('click', '.colors-wrapper:not(.color_filter-container) li', function(){
            $(this).parent('ul').find('li').removeClass('active');
            $(this).addClass('active');
        });

        
        $.fn.change_color_variant_image = function(product_id, option_id, variant_id) {
            var image = $('#det_img_' + product_id);

            if (image.length) {
                var color_image = $('#det_img_variant_image_' + product_id + '_' + option_id + '_' + variant_id);

                if (color_image.length) {
                    image.attr('src', color_image.attr('src'));
                } else {
                    var main_image_src = $('#det_img_main_image_'  + product_id).attr('src');
                    if (image.attr('src') != main_image_src) {
                        image.attr('src', main_image_src);
                    }
                }
            }
        };

        $.fn.change_color_variant_slide = function(product_id, option_id, variant_id, value) {
            $('#option_description_' + product_id + '_' + option_id + '_' + variant_id).closest('.colors-wrapper').find('.color-display').data('caVariantId', variant_id).html(value);
            var slide = $('#color_slide_' + product_id + '_' + variant_id), variant = '';
            if (slide.length) {
                $('.sd-slide-flickity').hide();
                slide.show();
                slide.find('.product-slider-main-block').flickity('resize');
                slide.find('.product-slider-nav').flickity('resize');
            }
            var claim_link = $('#button_claim_prize_');
                        var new_link = fn_url('redeem_store.claim_prize&amp;product_id=&amp;campaignUrl=&amp;color=' + value + variant);
            claim_link.attr('href', new_link);
        };

    });
}(Tygh, Tygh.$));


        var initTips = function() {
            var createTips = function() {
                $(&quot;.tips:not([data-init])&quot;).each(function() {
                    // Create scaffolding
                    var container = document.createElement(&quot;div&quot;);
                    var btnClose = document.createElement(&quot;button&quot;);
                    var tipText = document.createElement(&quot;span&quot;);

                    container.classList.add(&quot;tooltip-container&quot;);
                    btnClose.classList.add(&quot;btn-close&quot;);
                    tipText.innerHTML = $(this).html();

                    $(this).empty();
                    container.append(btnClose);
                    container.append(tipText);
                    $(this).append(container);

                    // Set original position
                    $(this).attr(&quot;data-position&quot;, $(this).attr(&quot;data-position&quot;) || &quot;top&quot;);
                    $(this).attr(&quot;data-orig-position&quot;, $(this).attr(&quot;data-position&quot;));

                    $(this).focus(function() {
                        checkTipBounds(this);
                    });

                    // Set Init Lock
                    $(this).attr(&quot;data-init&quot;, &quot;true&quot;);
                });
            };
            var checkTipBounds = function(tooltip) {
                // Define vars and clear previous adjustment
                var container = $(tooltip).find(&quot;.tooltip-container&quot;)[0];
                $(container).css(&quot;left&quot;, &quot;&quot;);
                var tBounds = container.getBoundingClientRect();

                // Adjust horizontal position
                var adjustLeft = function(tBounds) {
                    if (tBounds.right > window.innerWidth) {
                        $(container).css(&quot;left&quot;, &quot;calc(50% - &quot; + (tBounds.right + 10) + &quot;px)&quot;);
                    } else if (tBounds.left &lt; 0) {
                        $(container).css(&quot;left&quot;, &quot;calc(50% + &quot; + (tBounds.left * -1 + 10) + &quot;px)&quot;);
                    }
                }

                switch(true) {
                    case $(tooltip).attr(&quot;data-position&quot;) === &quot;right&quot;:
                        if (tBounds.right > window.innerWidth) {
                            $(tooltip).attr(&quot;data-position&quot;, &quot;left&quot;);

                            // Check if new position fits inside viewport
                            if (container.getBoundingClientRect().left &lt; 0) {
                                $(tooltip).attr(&quot;data-position&quot;, &quot;top&quot;);
                                adjustLeft(container.getBoundingClientRect());
                            }
                        }
                        break;
                    case $(tooltip).attr(&quot;data-position&quot;) === &quot;left&quot;:
                        if (tBounds.left &lt; 0) {
                            $(tooltip).attr(&quot;data-position&quot;, &quot;right&quot;);

                            // Check if new position fits inside viewport
                            if (container.getBoundingClientRect().right > window.innerWidth) {
                                $(tooltip).attr(&quot;data-position&quot;, &quot;top&quot;);
                                adjustLeft(container.getBoundingClientRect());
                            }
                        }
                        break;
                    default:
                        adjustLeft(tBounds);
                        break;
                }
            }

            createTips();
            $(document).ajaxStop(createTips);

            // Ensure that original position is attempted after resize
            var resizeTimeout;
            $(window).resize(function() {
                if (resizeTimeout) window.cancelAnimationFrame(resizeTimeout);
                resizeTimeout = window.requestAnimationFrame(function() {
                    $(&quot;.tips[data-init]&quot;).each(function() {
                        $(this).attr(&quot;data-position&quot;, $(this).attr(&quot;data-orig-position&quot;));
                    });
                });
            });
        }

        $(document).ready(function() {
            tippy('[data-tippy-content]');
            initTips();
        });
    

    (function(_, $) {
        if(bowser.name == 'Internet Explorer') {
            var _ie = 'is_IE';
        }else {
            var _ie = 'not_IE';
        }
        document.documentElement.className = document.documentElement.className + ' ' + _ie;
    }(Tygh, Tygh.$));


//&lt;![CDATA[


var supportMenuBlock;
var supportMenuLink;
var supportMenuLinkParent;
var supportMenuCloseIcon;

/**
This hides the support menu if already open.
Useful, for instance, when scrolling the home page.
*/


function openSupportMenu() {
    if (!supportMenuBlock.is(':visible')) {
        supportMenuBlock.fadeIn({duration: 200});
        supportMenuLinkParent.addClass('open')
    }
}

function toggleSupportMenu() {
    if (supportMenuBlock.hasClass('hidden')) {
        supportMenuBlock.hide();
        supportMenuBlock.removeClass('hidden');
    }
    if (!supportMenuBlock.is(':visible')) {
        openSupportMenu();
    }

}



function changeLanguage(val) {
    window.location=val;
}




(function(_, $) {


    _.tr({
        select: 'Selectare',
        selected: 'Selectat',
        error_max_verification: 'Valoarea din câmpul &lt;b>[field]&lt;\/b> este invalidă. Lungimea maximă pentru acest câmp este  &lt;b>[final]&lt;\/b>.',
        error_min_verification: 'Valoarea din câmpul &lt;b>[field]&lt;\/b> este invalidă. Lungimea minimă pentru acest câmp este &lt;b>[start]&lt;\/b>.',
        error_validator_dont_match_email: 'Adresele de e-mail din  &lt;b>[field2]&lt;\/b> si &lt;b>[field]&lt;\/b> nu se potrivesc',
        choose_option: 'Please choose one of the options below',
        none: 'Niciunul',
        checking_email_ajax: 'Checking email ...'
    });

    
    $(document).ready(function() {



        
        
            
            
            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-strong-password',
                message: 'The &lt;b>password&lt;\/b> must contain 8-12 characters and at least three of the following four criteria included (uppercase letters, lowercase letters, numbers and special characters).',
                func: function(id) {
                    var value = $('#' + id).val();
                    if ( value.length == 0 ) {
                        return false;
                    }
                                        return isStrongPassword( value, 3 );
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-age-verification',
                message: 'Valoarea din câmpul Data nașterii este invalidă. Pentru a te putea înregistra trebuie să fii adult.',
                func: function(id) {
                    var age;
                    var min     = parseInt('18');
                    var max     = parseInt('118');
                    var value   = $('#' + id).val() || $('#' + id).text();

                    age = fn_calculate_age(value);

                    return age &amp;&amp; ((age &lt; max &amp;&amp; age > min) || value.trim() == '' || (isNaN(min) &amp;&amp; isNaN(max)));
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-check-minmax-length',
                message: 'Valoarea din câmpul &lt;b>[field]&lt;\/b> este invalidă. Câmpul trebuie să conțină între &lt;b>[start]&lt;\/b> și &lt;b>[end]&lt;\/b> de caractere, dintre care cel puțin o cifră.',
                func: function(id) {
                    var min     = parseInt($('#' + id).data('min-length'));
                    var max     = parseInt($('#' + id).data('max-length'));
                    var val     = $('#' + id).val();
                    return minMaxLength(val, min, max);
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-check-fix-length',
                message: 'Valoarea din câmpul &lt;b>[field]&lt;\/b> este invalidă. Lungimea acestui câmp trebuie să fie &lt;b>[număr]&lt;\/b>.',
                func: function(id) {
                    var fix_val = parseInt($('#' + id).data('fix-length'));
                    var value   = parseInt($('#' + id).val().length);

                    if (
                        (value == fix_val &amp;&amp; !isNaN(fix_val))
                        || value == 0
                        || isNaN(fix_val)
                    ) {
                        return true;
                    }

                    return false;
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-check-nomatch-with-login',
                message: 'Câmpurile parolă și ID utilizator nu trebuie să fie aceleași',
                func: function(id) {
                    if (!$('#consumer_id').length) {
                        return true;
                    }

                    var password    = $('#' + id).val();
                    var login       = $('#consumer_id').val();

                    if (
                        (login != password &amp;&amp; password.trim() != '' &amp;&amp; login.trim() != '')
                        || login.trim() == ''
                        || password.trim() == ''
                        || id == 'password2'
                    ) {
                        return true;
                    }

                    return false;
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-login-must-contain',
                message: 'Câmpul &lt;b>ID utilizator&lt;\/b> trebuie să conțină litere.',
                func: function(id) {
                    var login = $('#consumer_id').val();
                    var result = (login.trim() == '') ? true : false;

                    for (var i = 0; i &lt; login.length; i ++) {
                        if (login[i].search(/^[1-9]\d*\.?\d{0,2}$/) == -1) {
                            result = true;
                        }
                    }

                    return result;
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-char-mixture',
                message: 'Valoarea din acest câmp trebuie să fie o combinație între cifre și litere.',
                func: function(id) {
                    var value  = $('#' + id).val();
                    var result = false;
                    var has_letters = false;
                    var has_digits = false;

                    for (var i = 0; i &lt; value.length; i++) {
                         if (value[i].search(/[0-9]/g) == 0) {
                            has_digits = true;
                        }

                        if (value[i].search(/[a-zA-Z]/g) == 0) {
                            has_letters = true;
                        }
                    }

                    if (has_digits &amp;&amp; has_letters) {
                        result = true;
                    }

                    return result;
                }
            });

            $.ceFormValidator('registerValidator', { // http://en.wikipedia.org/wiki/Japanese_typographic_symbols
                class_name: 'cm-sd-prohibit-japanese-punctuation',
                message: 'Valoarea din acest câmp nu trebuie să conțină punct sau virgulă în stil japonez.',
                func: function(id) {
                    var value  = $('#' + id).val();
                    var result = (value.match(/[\u3001-\u3002]/)) ? false : true;

                    return result;
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-check-hiragana-symbol',
                message: '&lt;b>[field]&lt;\/b> trebuie să fie în hirogana',
                func: function(id) {
                    var value  = $('#' + id).val();
                    var result = (!!value.match(/^[\u3040-\u3096]+$/) || value.trim() == '') ? true : false; // ひらがな - isHiragana

                    return result;
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-check-zipcode-it',
                message: 'Valoarea din câmpul Cod poștal nu este valabilă. Câmpul trebuie să conțină 5 cifre',
                func: function(id) {
                    var value = $('#' + id).val().trim();
                    var result = false;

                    if (value.length == 0) {
                        result = true;
                    } else {
                        if (value.replace(/[0-9]/g, '').length == 0) {
                            if (value.length == 5) {
                                result = true;
                            }
                        }
                    }

                    return result;
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-check-phone-it',
                message: 'Valoarea din câmpul Telefon este invalidă. Câmpul trebuie să conțină 9-12 cifre și să înceapă cu „+”',
                // 061234567
                // 3461234567
                // +39061234567
                // +393461234567
                // +39 061234567
                // +39 3461234567
                func: function(id) {
                    var value = $('#' + id).val().trim();
                    var phone;
                    var result = false;

                    if (value.length == 0) {
                        result = true;
                    } else {
                        if (value[0] == '+') {
                            value = value.substr(1);
                        }

                        if (value.replace(/[0-9 ]/g, '').length == 0) {
                            phone = value.replace(/[ ]/g, '');
                            if (phone.length > 8 &amp;&amp; phone.length &lt; 16) {
                                result = true;
                            }
                        }
                    }

                    return result;
                }
            });

            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-check-phone',
                message: 'Valoarea din câmpul Telefon este invalidă. Câmpul trebuie să conțină 9-11 cifre și să înceapă cu 0',
                func: function(id) {
                    var value   = $('#' + id).val().trim();
                    var section = '';
                    var name    = $('#' + id).prop('name');
                    var prefix, sufix;

                    name = name.str_replace('user_data[', '');
                    name = name.str_replace('phone]', '');

                    if (name == 's_') {
                        section = 'shipping';
                    } else if (name == 'b_') {
                        section = 'billing';
                    }

                    var country = $('.cm-country' + ( (section != '') ? '.cm-location-' + section : '' ) ).val();

                    if (country == 'JP') {
                        prefix = 0;
                        sufix = 0;
                    }

                    var min     = parseInt($('#' + id).data('min-length'));
                    var max     = parseInt($('#' + id).data('max-length'));
                    var count   = 0;

                    if (typeof(punycode) != 'undefined') {
                        count   = punycode.ucs2.decode(value).length;
                    } else {
                        count   = value.length;
                    }
                    count = parseInt(count);

                    // 1 rule
                    if ( !isNaN(sufix) &amp;&amp; parseInt(value[1]) == sufix ) {
                        return false;
                    }

                    // 2 rule
                    if (
                        (
                            (!isNaN(prefix) &amp;&amp; parseInt(value[0]) == prefix
                            || value == ''
                            || isNaN(prefix)
                            )
                          &amp;&amp;
                            (!isNaN(sufix) &amp;&amp; parseInt(value[2]) == sufix
                            || value == ''
                            || isNaN(sufix))
                        ) &amp;&amp; (
                            (count == max &amp;&amp; !isNaN(max))
                        )
                    ) {
                        return true;
                    }

                    // 3 rule
                    if (
                        (
                            (!isNaN(prefix) &amp;&amp; parseInt(value[0]) == prefix
                            || value == ''
                            || isNaN(prefix)
                            )
                          &amp;&amp;
                            (!isNaN(sufix) &amp;&amp; parseInt(value[2]) != sufix
                            || value == ''
                            || isNaN(sufix)
                            )
                        ) &amp;&amp; (
                            (count == max &amp;&amp; !isNaN(max))
                        )
                    ) {
                        return false;
                    }

                    if (
                        (
                            !isNaN(prefix) &amp;&amp; parseInt(value[0]) == prefix
                            || value == ''
                            || isNaN(prefix)
                        ) &amp;&amp; (
                            (count &lt;= max &amp;&amp; count >= min &amp;&amp; !isNaN(min) &amp;&amp; !isNaN(max))
                            || count == 0
                            || (isNaN(min) &amp;&amp; isNaN(max))
                            || (count &lt;= max &amp;&amp; isNaN(min) &amp;&amp; !isNaN(max))
                            || (count >= min &amp;&amp; isNaN(max) &amp;&amp; !isNaN(min))
                        )
                    ) {
                        return true;
                    }

                    return false;
                }
            });


            $.ceFormValidator('registerValidator', {
                class_name: 'cm-sd-check-cyrillic-symbol',
                message: '_error_cyrillic_symbol',
                func: function(id) {
                    var value  = $('#' + id).val();
                    var result = true;
                    
                    for (var i = 0; i &lt; value.length; i ++) {
                         if (value[i].search(/[а-яА-ЯёЁ/-]/g) == -1) {
                            result = false;
                            break;
                        }
                        if (value[0].search(/[А-ЯЁ]/g) == -1) {
                            result = false;
                            break;
                        }
                    }

                    if (value.length > 30) {
                        result = false;
                    }

                    
                    return result;
                }
            });

        
        
        
        
            });

    function fn_calculate_age(date)
    {
        var today = new Date();
                    var date_format   = 'day_first';
            var parse_date    = date.split('/');            var selected_date = {
                year: parse_date[2]
            };

            if (date_format == 'month_first') {
                selected_date['month'] = parse_date[0];
                selected_date['day']   = parse_date[1];
            } else {
                selected_date['month'] = parse_date[1];
                selected_date['day']   = parse_date[0];
            }

            //Check if provided day and month are valid dates
            if (parseInt(selected_date['month']) > 12 || new Date(selected_date['year'], parseInt(selected_date['month']) - 1, selected_date['day']).getMonth() != parseInt(selected_date['month'])-1) {
                return false;
            } else {
                var year = today.getFullYear() - selected_date.year + 1;
            }
                if (
            !(parseInt(selected_date.month) &lt; parseInt(today.getMonth() + 1)
            || ( parseInt(selected_date.month) == parseInt(today.getMonth() + 1)
            &amp;&amp; parseInt(selected_date.day) &lt;= parseInt(today.getDate()) ))
        ) {
            year --;
        }

        return year;
    }

            $(function() {
            $('.ty-accordion').accordion( &quot;option&quot;, &quot;active&quot;, $('.ui-accordion-header').index($('#general')));
        });
    }(Tygh, Tygh.$));
//]]>







.cm-noscript {display:none}#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}@import url(https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,700);#survicate-box{
  /*! normalize.css v8.0.0 | MIT License | github.com/necolas/normalize.css */}#survicate-box html{line-height:1.15;-webkit-text-size-adjust:100%}#survicate-box body{margin:0}#survicate-box h1{font-size:2em;margin:.67em 0}#survicate-box hr{-webkit-box-sizing:content-box;box-sizing:content-box;height:0;overflow:visible}#survicate-box pre{font-family:monospace,monospace;font-size:1em}#survicate-box a{background-color:rgba(0,0,0,0)}#survicate-box abbr[title]{border-bottom:none;text-decoration:underline;-webkit-text-decoration:underline dotted;text-decoration:underline dotted}#survicate-box b,#survicate-box strong{font-weight:bolder}#survicate-box code,#survicate-box kbd,#survicate-box samp{font-family:monospace,monospace;font-size:1em}#survicate-box small{font-size:80%}#survicate-box sub,#survicate-box sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}#survicate-box sub{bottom:-.25em}#survicate-box sup{top:-.5em}#survicate-box img{border-style:none}#survicate-box button,#survicate-box input,#survicate-box optgroup,#survicate-box select,#survicate-box textarea{font-family:inherit;font-size:100%;line-height:1.15;margin:0}#survicate-box button,#survicate-box input{overflow:visible}#survicate-box button,#survicate-box select{text-transform:none}#survicate-box [type=button],#survicate-box [type=reset],#survicate-box [type=submit],#survicate-box button{-webkit-appearance:button}#survicate-box [type=button]::-moz-focus-inner,#survicate-box [type=reset]::-moz-focus-inner,#survicate-box [type=submit]::-moz-focus-inner,#survicate-box button::-moz-focus-inner{border-style:none;padding:0}#survicate-box [type=button]:-moz-focusring,#survicate-box [type=reset]:-moz-focusring,#survicate-box [type=submit]:-moz-focusring,#survicate-box button:-moz-focusring{outline:1px dotted ButtonText}#survicate-box fieldset{padding:.35em .75em .625em}#survicate-box legend{-webkit-box-sizing:border-box;box-sizing:border-box;color:inherit;display:table;max-width:100%;padding:0;white-space:normal}#survicate-box progress{vertical-align:baseline}#survicate-box textarea{overflow:auto}#survicate-box [type=checkbox],#survicate-box [type=radio]{-webkit-box-sizing:border-box;box-sizing:border-box;padding:0}#survicate-box [type=number]::-webkit-inner-spin-button,#survicate-box [type=number]::-webkit-outer-spin-button{height:auto}#survicate-box [type=search]{-webkit-appearance:textfield;outline-offset:-2px}#survicate-box [type=search]::-webkit-search-decoration{-webkit-appearance:none}#survicate-box ::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}#survicate-box details{display:block}#survicate-box summary{display:list-item}#survicate-box [hidden],#survicate-box template{display:none}#survicate-box h1,#survicate-box h2,#survicate-box h3,#survicate-box h4{color:#29292a;font-weight:400;margin:0 0 16px;padding:0}#survicate-box .h1,#survicate-box h1{font-size:24px}#survicate-box .h2,#survicate-box h2{font-size:18px}#survicate-box .h3,#survicate-box h3{font-size:16px}#survicate-box .h4,#survicate-box h4{font-size:14px}#survicate-box .g-row{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-box-sizing:border-box;box-sizing:border-box;margin-right:-16px;margin-left:-16px;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap}#survicate-box div[class*=g-col]{-webkit-box-sizing:border-box;box-sizing:border-box;padding-right:16px;padding-left:16px}#survicate-box .g-col{-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;-webkit-flex-basis:0;-ms-flex-preferred-size:0;flex-basis:0}#survicate-box .g-col-4{max-width:33.33333%;-webkit-flex-basis:33.33333%;-ms-flex-preferred-size:33.33333%;flex-basis:33.33333%}#survicate-box *{font-family:Open sans,sans-serif;font-size:14px;line-height:normal;-webkit-box-sizing:border-box;box-sizing:border-box;outline:none}#survicate-box .sv__outline :focus{outline:1px solid #87cefa}#survicate-box button{padding:3px;display:inline-block;margin:0;border:none;cursor:pointer}#survicate-box p{margin:0}#survicate-box a{text-decoration:none}#survicate-box .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}#survicate-box .sv-invalid.sv-invalid.sv-invalid{border:1px solid #c00}#survicate-box .sv__choice-button{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;padding:10px;width:100%;text-align:left;font-weight:500;margin:5px 0;cursor:pointer;-webkit-transition:background-color .3s;-o-transition:background-color .3s;transition:background-color .3s;border-radius:4px}#survicate-box .sv__choice-button>div:last-child{width:100%}#survicate-box .sv__choice-button textarea{margin-top:5px;border-left:none;border-right:none;border-bottom:none;resize:none;border-radius:4px;padding:5px;height:44px;max-height:72px;width:100%}#survicate-box .sv__choice-button.sv__chat{padding:0;margin:0 0 10px}#survicate-box .sv__choice-button.sv__chat textarea{margin-top:0;padding:4px 0;border-top:none;border-radius:0;border-bottom:1px solid #eff3f5}#survicate-box .sv__choice-button.sv__chat .sv__selected{font-weight:700}#survicate-box .sv__choice-button .sv__checkbox{-webkit-box-flex:1;-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto}#survicate-box .sv__multiple-choice .sv__submit-button-wrapper{margin-top:15px}#survicate-box .sv__rating{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;-webkit-box-orient:horizontal;-webkit-box-direction:reverse;-webkit-flex-direction:row-reverse;-ms-flex-direction:row-reverse;flex-direction:row-reverse}#survicate-box .sv__rating svg{height:25px;width:25px;fill:#fff}#survicate-box .sv__rating button{background:none;padding:0;max-width:10%}#survicate-box .sv__rating span{font-size:12px;font-weight:200}#survicate-box .sv__rating.sv__chat svg{fill:#eff3f5}#survicate-box .sv__date{border-radius:4px;-webkit-box-sizing:border-box;box-sizing:border-box;padding:10px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;text-align:center;margin-bottom:15px}#survicate-box .sv__date input{width:30%;background:inherit;border:none;text-align:center}#survicate-box .sv__date div,#survicate-box .sv__date input{padding:5px;display:inline-block}#survicate-box .sv__date.sv__chat{border-radius:0;border-bottom:1px solid #eff3f5}#survicate-box .sv__date.sv__invalid{border:1px solid #c00}#survicate-box .sv__date.sv__invalid.sv__chat{border-style:none none solid}#survicate-box .sv__smiley-scale{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}#survicate-box .sv__smiley-scale button{background-color:rgba(0,0,0,0)}#survicate-box .sv__smiley-scale button:not(:last-child){margin-right:10px}#survicate-box .sv__smiley-scale svg{border-radius:50%;height:40px;width:40px;-webkit-transition:background-color .3s;-o-transition:background-color .3s;transition:background-color .3s}#survicate-box .sv__smiley-scale.sv__three-smileys svg{height:60px;width:60px}#survicate-box .sv__smiley-scale .sv__very-sad{background-color:#be3f32;border-bottom:1px solid #451712}#survicate-box .sv__smiley-scale .sv__very-sad:hover{background-color:#d15d52}#survicate-box .sv__smiley-scale .sv__very-sad path{fill:#963227}#survicate-box .sv__smiley-scale .sv__sad{background-color:#e74c3c;border-bottom:1px solid #7b190f}#survicate-box .sv__smiley-scale .sv__sad:hover{background-color:#ed7669}#survicate-box .sv__smiley-scale .sv__sad path{fill:#d62c1a}#survicate-box .sv__smiley-scale .sv__neutral{background-color:#ff9800;border-bottom:1px solid #663d00}#survicate-box .sv__smiley-scale .sv__neutral:hover{background-color:#ffad33}#survicate-box .sv__smiley-scale .sv__neutral path{fill:#cc7a00}#survicate-box .sv__smiley-scale .sv__happy{background-color:#5cb45e;border-bottom:1px solid #265227}#survicate-box .sv__smiley-scale .sv__happy:hover{background-color:#7fc481}#survicate-box .sv__smiley-scale .sv__happy path{fill:#469748}#survicate-box .sv__smiley-scale .sv__very-happy{background-color:#438345;border-bottom:1px solid #0f1e10}#survicate-box .sv__smiley-scale .sv__very-happy:hover{background-color:#54a557}#survicate-box .sv__smiley-scale .sv__very-happy path{fill:#326133}#survicate-box .sv__ie .sv__smiley-scale button{background:rgba(0,0,0,0)}#survicate-box .sv__text-question{min-height:80px;border:none;resize:none;border-radius:4px;padding:10px;max-height:200px;width:100%}#survicate-box .sv__chat-theme .sv__text-question{border:1px solid #eff3f5;border-radius:0}#survicate-box .sv__social-button{display:block;position:relative;color:#fff;border-radius:4px;margin-bottom:10px;padding:10px;font-weight:900;text-align:center;-webkit-transition:background-color .3s;-o-transition:background-color .3s;transition:background-color .3s}#survicate-box .sv__social-button.sv__chat{border-radius:40px}#survicate-box .sv__social-button.sv__fb{background-color:#3579ea;border-bottom:1px solid #11192b}#survicate-box .sv__social-button.sv__fb:hover{background-color:#165ed6}#survicate-box .sv__social-button.sv__twitter{background-color:#4aa1ec;border-bottom:1px solid #0f5f9b}#survicate-box .sv__social-button.sv__twitter:hover{background-color:#1c89e7}#survicate-box .sv__social-button.sv__twitter svg{left:17px;top:12px}#survicate-box .sv__social-button.sv__linkedin{background-color:#2a66bc;border-bottom:1px solid #0f5f9b}#survicate-box .sv__social-button.sv__linkedin:hover{background-color:#4480d5}#survicate-box .sv__social-button.sv__linkedin svg{left:17px}#survicate-box .sv__social-button svg{position:absolute;fill:#fff;left:20px}#survicate-box .sv__nps{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}#survicate-box .sv__nps button{text-align:center;padding:initial;height:28px;width:20px;border-radius:4px}#survicate-box .sv__nps.sv__chat button{background-color:#eff3f5;border-color:#eff3f5}#survicate-box .sv__nps.sv__chat button:hover{-webkit-box-shadow:0 0 5px rgba(0,0,0,.2);box-shadow:0 0 5px rgba(0,0,0,.2)}#survicate-box .sv__nps-labels{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;margin-top:5px}#survicate-box .sv__nps-labels div{font-size:11px}#survicate-box .sv__position-center .sv__nps button{width:100%;margin:0 2px;height:45px}#survicate-box .sv__contact-form-confirmation{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;width:100%}#survicate-box .sv__contact-form-confirmation *{-webkit-box-flex:0;-webkit-flex:none;-ms-flex:none;flex:none}#survicate-box .sv__contact-form-confirmation>div:last-child{cursor:pointer;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1}#survicate-box .sv__contact-form-security{font-size:12px;margin-bottom:5px}#survicate-box .sv__contact-form-field{position:relative;margin-top:10px;width:100%;border-radius:4px;margin-bottom:10px}#survicate-box .sv__contact-form-field.sv__light span{color:#fff}#survicate-box .sv__contact-form-field.sv__light input:focus{border-color:#fff}#survicate-box .sv__contact-form-field.sv__dark input:focus{border-color:#000}#survicate-box .sv__contact-form-field.sv__chat{padding:5px 0}#survicate-box .sv__contact-form-field.sv__chat input{padding:0;border-color:#eff3f5;border-radius:0;border-style:none none solid}#survicate-box .sv__contact-form-field.sv__chat input:focus{border-color:#5cb45e}#survicate-box .sv__contact-form-field.sv__chat span{color:#5cb45e;left:0;top:-3px}#survicate-box .sv__contact-form-field.sv__invalid input,#survicate-box .sv__contact-form-field.sv__invalid input:focus{border-color:#c00}#survicate-box .sv__contact-form-field input{-webkit-box-sizing:border-box;box-sizing:border-box;border-radius:4px;border-top-width:1px;width:100%;padding:12px 5px;height:40px;border-top-style:solid;border-left:1px solid rgba(0,0,0,0);border-right:1px solid rgba(0,0,0,0);border-bottom:1px solid rgba(0,0,0,0);-webkit-transition:border .5s;-o-transition:border .5s;transition:border .5s;outline-offset:3px}#survicate-box .sv__contact-form-field input:focus+.sv__contact-form-field-label{opacity:1}#survicate-box .sv__contact-form-field .sv__contact-form-field-label{position:absolute;left:10px;top:-9px;z-index:1;font-size:11px;-webkit-transition:opacity .5s;-o-transition:opacity .5s;transition:opacity .5s;opacity:0}#survicate-box .sv__contact-form-field .sv__contact-form-field-label:before{content:&quot;&quot;;position:absolute;z-index:-1;top:9px;left:0;display:block;width:100%;height:1px}#survicate-box .sv__checkbox{display:inline-block;position:relative;margin-right:10px;height:16px;width:16px;cursor:pointer}#survicate-box .sv__checkbox svg{fill:currentColor}#survicate-box .sv__checkbox.sv__circle{border-radius:50%}#survicate-box .sv__checkbox.sv__circle .sv__tick{top:4px;left:6px;height:5px;width:5px;border-radius:100%}#survicate-box .sv__checkbox.sv__square{border-radius:2px}#survicate-box .sv__checkbox.sv__square .sv__tick{top:1px;left:5px;height:10px;width:6px;border-width:0 3px 3px 0;border-style:solid;background-color:rgba(0,0,0,0);-webkit-transform:rotate(45deg);-ms-transform:rotate(45deg);transform:rotate(45deg)}#survicate-box .sv__checkbox.sv__chat{background-color:#eff3f5;border:1px solid #d0dbe1}#survicate-box .sv__checkbox.sv__chat .sv__tick{left:5px}#survicate-box .sv__checkbox.sv__chat.sv__square .sv__tick{left:4px}#survicate-box .sv__checkbox .sv__tick{position:absolute;display:block}#survicate-box .sv__submit-button-wrapper{margin-top:10px}#survicate-box .sv__submit-button{padding:10px;width:100%;border-style:none none solid;border-radius:4px;font-weight:700;outline-offset:3px}#survicate-box .sv__submit-button.sv__chat{border-style:none;border-radius:30px}#survicate-box .sv__select{position:relative}#survicate-box .sv__select input{border-style:solid none none;border-radius:4px;width:100%;padding:15px 10px;cursor:pointer}#survicate-box .sv__select.sv__chat input{background:none;border-style:none none solid;border-bottom:1px solid #eff3f5}#survicate-box .sv__select .sv__caret{border-left:6px solid rgba(0,0,0,0);border-right:6px solid rgba(0,0,0,0);border-top:7px solid;position:absolute;top:20px;right:15px}#survicate-box .sv__select.sv__dropdown-open .sv__caret{border-top:none;border-bottom:7px solid}#survicate-box .sv__select.sv__light .sv__caret{border-top-color:#000;border-bottom-color:#000}#survicate-box .sv__select.sv__dark .sv__caret{border-top-color:#fff;border-bottom-color:#fff}#survicate-box .sv__select ul{position:absolute;list-style:none;padding:0;margin:0;width:100%;max-height:200px;overflow:auto;bottom:calc(100% + 2px);border-radius:4px 4px 0 0}#survicate-box .sv__select ul li button{border:none;padding:10px;border-radius:0;width:100%;font-size:inherit;-webkit-transition:none;-o-transition:none;transition:none;text-align:left;font-weight:400}#survicate-box .sv__select.sv__survey-up ul{bottom:auto;top:calc(100% + 2px);border-radius:0 0 4px 4px}#survicate-box .sv__survey{z-index:2147483646;position:fixed;padding:10px 15px;background:#fff;width:300px}#survicate-box .sv__survey.sv__position-right{right:30px;bottom:0}#survicate-box .sv__survey.sv__position-left{left:30px;bottom:0}#survicate-box .sv__survey.sv__position-top-right{right:30px;top:0}#survicate-box .sv__survey.sv__position-top-left{left:30px;top:0}#survicate-box .sv__survey.sv__position-center{bottom:50%;right:50%;-webkit-transform:translate(50%,50%);-ms-transform:translate(50%,50%);transform:translate(50%,50%);width:450px}#survicate-box .sv__survey.sv__position-top-left,#survicate-box .sv__survey.sv__position-top-right{border-radius:0 0 4px 4px}#survicate-box .sv__survey.sv__position-left,#survicate-box .sv__survey.sv__position-right{border-radius:4px 4px 0 0}#survicate-box .sv__survey.sv__position-center{border-radius:4px}#survicate-box .sv__survey.sv__classic-theme{-webkit-box-shadow:0 0 25px rgba(0,0,0,.5);box-shadow:0 0 25px rgba(0,0,0,.5)}#survicate-box .sv__survey.sv__chat-theme{-webkit-box-shadow:0 3px 32px rgba(0,0,0,.14);box-shadow:0 3px 32px rgba(0,0,0,.14)}#survicate-box .sv__survey.sv__minimized{cursor:pointer;-webkit-box-shadow:0 0 9px #000;box-shadow:0 0 9px #000;min-width:70px;min-height:39px;padding-right:35px;width:auto}#survicate-box .sv__survey.sv__minimized.sv__position-center{right:30px;-webkit-transform:none;-ms-transform:none;transform:none;width:auto;bottom:0}@media only screen and (max-width:568px){#survicate-box .sv__survey.sv__survey{-webkit-transform:none;-ms-transform:none;transform:none;width:calc(100% - 40px);margin:20px auto;left:20px;right:20px;border-radius:4px}#survicate-box .sv__survey.sv__survey.sv__position-top-left,#survicate-box .sv__survey.sv__survey.sv__position-top-right{top:0}#survicate-box .sv__survey.sv__survey.sv__position-center,#survicate-box .sv__survey.sv__survey.sv__position-left,#survicate-box .sv__survey.sv__survey.sv__position-right{bottom:0}#survicate-box .sv__survey.sv__survey.sv__minimized{width:100%;right:0;left:0;margin:0}#survicate-box .sv__survey.sv__survey.sv__minimized.sv__position-center{width:100%;right:0}}#survicate-box .sv__survey-bottom-placeholder{height:12px}#survicate-box .sv__point{padding:0 5px}#survicate-box .sv__point .sv__point-text{margin:5px 0}#survicate-box .sv__point .sv__point-question{margin-bottom:15px;font-weight:700}#survicate-box .sv__progress-bar{border-radius:4px 4px 0 0}#survicate-box .sv__progress-bar>div{border-radius:4px 0 0 0}@media only screen and (min-width:768px) and (-webkit-max-device-pixel-ratio:2),only screen and (min-width:813px){#survicate-box .sv__position-top-left .sv__progress-bar,#survicate-box .sv__position-top-left .sv__progress-bar>div,#survicate-box .sv__position-top-right .sv__progress-bar,#survicate-box .sv__position-top-right .sv__progress-bar>div{border-radius:0}}#survicate-box input::-webkit-input-placeholder{line-height:normal!important}#survicate-box .survicate_plus-button_3rBOx{position:absolute;right:15px;bottom:10px;background-color:rgba(0,0,0,0)}#survicate-box .survicate_overlay_3en50{position:fixed;height:100vh;width:100vw;z-index:999995;top:0;left:0}#survicate-box .survicate_overlay_3en50.survicate_dark_3dVQC{opacity:.35;background-color:#000}#survicate-box .survicate_overlay_3en50.survicate_light_2LfbL{opacity:.5;background-color:#fff}#survicate-box .survicate_progress-bar_tv6VS{position:absolute;top:0;left:0;width:100%;height:4px}#survicate-box .survicate_progress-bar_tv6VS>div{height:100%}#survicate-box .survicate_chat-theme_jN-vh{height:3px}#survicate-box .survicate_footer_1Byg6,#survicate-box .survicate_footer-wrapper_2yP5r{display:inline-block}#survicate-box .survicate_footer_1Byg6{font-size:11px;padding:0 5px}#survicate-box .survicate_footer_1Byg6.survicate_chat-theme_3CzC8{text-align:center}#survicate-box .survicate_survey-buttons_3ws-x{color:#b3b3b3;float:right;padding:0}#survicate-box .survicate_survey-buttons_3ws-x button{display:inline-block;background:none;border:none;color:inherit;font-family:Open sans,sans-serif;padding:6px;font-weight:700;-webkit-transition:color .3s;-o-transition:color .3s;transition:color .3s}#survicate-box .survicate_survey-buttons_3ws-x button:focus{outline-offset:3px}#survicate-box .survicate_small_uC5dD{font-size:11px}#survicate-box .survicate_avatar_3rSdl{padding:15px 10px 15px 0;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center}#survicate-box .survicate_avatar_3rSdl img{width:45px;min-width:45px;height:45px;border-radius:50%;vertical-align:sub}#survicate-box .survicate_avatar_3rSdl div{display:inline-block;margin-left:10px}#survicate-box .survicate_avatar_3rSdl div .survicate_avatar-description_1mzqL{font-size:11px}#survicate-box .survicate_avatar_3rSdl p{color:#808e9b}#survicate-box .survicate_footer-wrapper_3LNls{margin-top:10px}#onetrust-banner-sdk{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}#onetrust-banner-sdk .onetrust-vendors-list-handler{cursor:pointer;color:#1f96db;font-size:inherit;font-weight:bold;text-decoration:none;margin-left:5px}#onetrust-banner-sdk .onetrust-vendors-list-handler:hover{color:#1f96db}#onetrust-banner-sdk .ot-close-icon,#onetrust-pc-sdk .ot-close-icon,#ot-sync-ntfy .ot-close-icon{background-image:url(&quot;data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB3aWR0aD0iMzQ4LjMzM3B4IiBoZWlnaHQ9IjM0OC4zMzNweCIgdmlld0JveD0iMCAwIDM0OC4zMzMgMzQ4LjMzNCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzQ4LjMzMyAzNDguMzM0OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PGc+PHBhdGggZmlsbD0iIzU2NTY1NiIgZD0iTTMzNi41NTksNjguNjExTDIzMS4wMTYsMTc0LjE2NWwxMDUuNTQzLDEwNS41NDljMTUuNjk5LDE1LjcwNSwxNS42OTksNDEuMTQ1LDAsNTYuODVjLTcuODQ0LDcuODQ0LTE4LjEyOCwxMS43NjktMjguNDA3LDExLjc2OWMtMTAuMjk2LDAtMjAuNTgxLTMuOTE5LTI4LjQxOS0xMS43NjlMMTc0LjE2NywyMzEuMDAzTDY4LjYwOSwzMzYuNTYzYy03Ljg0Myw3Ljg0NC0xOC4xMjgsMTEuNzY5LTI4LjQxNiwxMS43NjljLTEwLjI4NSwwLTIwLjU2My0zLjkxOS0yOC40MTMtMTEuNzY5Yy0xNS42OTktMTUuNjk4LTE1LjY5OS00MS4xMzksMC01Ni44NWwxMDUuNTQtMTA1LjU0OUwxMS43NzQsNjguNjExYy0xNS42OTktMTUuNjk5LTE1LjY5OS00MS4xNDUsMC01Ni44NDRjMTUuNjk2LTE1LjY4Nyw0MS4xMjctMTUuNjg3LDU2LjgyOSwwbDEwNS41NjMsMTA1LjU1NEwyNzkuNzIxLDExLjc2N2MxNS43MDUtMTUuNjg3LDQxLjEzOS0xNS42ODcsNTYuODMyLDBDMzUyLjI1OCwyNy40NjYsMzUyLjI1OCw1Mi45MTIsMzM2LjU1OSw2OC42MTF6Ii8+PC9nPjwvc3ZnPg==&quot;);background-size:contain;background-repeat:no-repeat;background-position:center;height:12px;width:12px}#onetrust-banner-sdk .powered-by-logo,#onetrust-banner-sdk .ot-pc-footer-logo a,#onetrust-pc-sdk .powered-by-logo,#onetrust-pc-sdk .ot-pc-footer-logo a,#ot-sync-ntfy .powered-by-logo,#ot-sync-ntfy .ot-pc-footer-logo a{background-size:contain;background-repeat:no-repeat;background-position:center;height:25px;width:152px;display:block}#onetrust-banner-sdk h3 *,#onetrust-banner-sdk h4 *,#onetrust-banner-sdk h6 *,#onetrust-banner-sdk button *,#onetrust-banner-sdk a[data-parent-id] *,#onetrust-pc-sdk h3 *,#onetrust-pc-sdk h4 *,#onetrust-pc-sdk h6 *,#onetrust-pc-sdk button *,#onetrust-pc-sdk a[data-parent-id] *,#ot-sync-ntfy h3 *,#ot-sync-ntfy h4 *,#ot-sync-ntfy h6 *,#ot-sync-ntfy button *,#ot-sync-ntfy a[data-parent-id] *{font-size:inherit;font-weight:inherit;color:inherit}#onetrust-banner-sdk .ot-hide,#onetrust-pc-sdk .ot-hide,#ot-sync-ntfy .ot-hide{display:none !important}#onetrust-pc-sdk .ot-sdk-row .ot-sdk-column{padding:0}#onetrust-pc-sdk .ot-sdk-container{padding-right:0}#onetrust-pc-sdk .ot-sdk-row{flex-direction:initial;width:100%}#onetrust-pc-sdk [type=&quot;checkbox&quot;]:checked,#onetrust-pc-sdk [type=&quot;checkbox&quot;]:not(:checked){pointer-events:initial}#onetrust-pc-sdk [type=&quot;checkbox&quot;]:disabled+label::before,#onetrust-pc-sdk [type=&quot;checkbox&quot;]:disabled+label:after,#onetrust-pc-sdk [type=&quot;checkbox&quot;]:disabled+label{pointer-events:none;opacity:0.7}#onetrust-pc-sdk #vendor-list-content{transform:translate3d(0, 0, 0)}#onetrust-pc-sdk li input[type=&quot;checkbox&quot;]{z-index:1}#onetrust-pc-sdk li .ot-checkbox label{z-index:2}#onetrust-pc-sdk li .ot-checkbox input[type=&quot;checkbox&quot;]{height:auto;width:auto}#onetrust-pc-sdk li .host-title a,#onetrust-pc-sdk li .ot-host-name a,#onetrust-pc-sdk li .accordion-text,#onetrust-pc-sdk li .ot-acc-txt{z-index:2;position:relative}#onetrust-pc-sdk input{margin:3px 0.1ex}#onetrust-pc-sdk .toggle-always-active{opacity:0.6;cursor:default}#onetrust-pc-sdk .screen-reader-only,#onetrust-pc-sdk .ot-scrn-rdr{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}#onetrust-pc-sdk .pc-logo,#onetrust-pc-sdk .ot-pc-logo{height:60px;width:180px;background-position:center;background-size:contain;background-repeat:no-repeat}#onetrust-pc-sdk .ot-tooltip .ot-tooltiptext{visibility:hidden;width:120px;background-color:#555;color:#fff;text-align:center;padding:5px 0;border-radius:6px;position:absolute;z-index:1;bottom:125%;left:50%;margin-left:-60px;opacity:0;transition:opacity 0.3s}#onetrust-pc-sdk .ot-tooltip .ot-tooltiptext::after{content:&quot;&quot;;position:absolute;top:100%;left:50%;margin-left:-5px;border-width:5px;border-style:solid;border-color:#555 transparent transparent transparent}#onetrust-pc-sdk .ot-tooltip:hover .ot-tooltiptext{visibility:visible;opacity:1}#onetrust-pc-sdk .ot-tooltip{position:relative;display:inline-block;z-index:3}#onetrust-pc-sdk .ot-tooltip svg{color:grey;height:20px;width:20px}#onetrust-pc-sdk.ot-fade-in,.onetrust-pc-dark-filter.ot-fade-in{animation-name:onetrust-fade-in;animation-duration:400ms;animation-timing-function:ease-in-out}#onetrust-pc-sdk.ot-hide{display:none !important}.onetrust-pc-dark-filter.ot-hide{display:none !important}#ot-sdk-btn.ot-sdk-show-settings,#ot-sdk-btn.optanon-show-settings{color:#68b631;border:1px solid #68b631;height:auto;white-space:normal;word-wrap:break-word;padding:0.8em 2em;font-size:0.8em;line-height:1.2;cursor:pointer;-moz-transition:0.1s ease;-o-transition:0.1s ease;-webkit-transition:1s ease;transition:0.1s ease}#ot-sdk-btn.ot-sdk-show-settings:hover,#ot-sdk-btn.optanon-show-settings:hover{color:#fff;background-color:#68b631}.onetrust-pc-dark-filter{background:rgba(0,0,0,0.5);z-index:2147483646;width:100%;height:100%;overflow:hidden;position:fixed;top:0;bottom:0;left:0}@keyframes onetrust-fade-in{0%{opacity:0}100%{opacity:1}}@media only screen and (min-width: 426px) and (max-width: 896px) and (orientation: landscape){#onetrust-pc-sdk p{font-size:0.75em}}#onetrust-banner-sdk .banner-option-input:focus+label{outline:1px solid #000;outline-style:auto}
#onetrust-banner-sdk,#onetrust-pc-sdk,#ot-sdk-cookie-policy,#ot-sync-ntfy{font-size:16px}#onetrust-banner-sdk *,#onetrust-banner-sdk ::after,#onetrust-banner-sdk ::before,#onetrust-pc-sdk *,#onetrust-pc-sdk ::after,#onetrust-pc-sdk ::before,#ot-sdk-cookie-policy *,#ot-sdk-cookie-policy ::after,#ot-sdk-cookie-policy ::before,#ot-sync-ntfy *,#ot-sync-ntfy ::after,#ot-sync-ntfy ::before{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box}#onetrust-banner-sdk div,#onetrust-banner-sdk span,#onetrust-banner-sdk h1,#onetrust-banner-sdk h2,#onetrust-banner-sdk h3,#onetrust-banner-sdk h4,#onetrust-banner-sdk h5,#onetrust-banner-sdk h6,#onetrust-banner-sdk p,#onetrust-banner-sdk img,#onetrust-banner-sdk svg,#onetrust-banner-sdk button,#onetrust-banner-sdk section,#onetrust-banner-sdk a,#onetrust-banner-sdk label,#onetrust-banner-sdk input,#onetrust-banner-sdk ul,#onetrust-banner-sdk li,#onetrust-banner-sdk nav,#onetrust-banner-sdk table,#onetrust-banner-sdk thead,#onetrust-banner-sdk tr,#onetrust-banner-sdk td,#onetrust-banner-sdk tbody,#onetrust-banner-sdk .ot-main-content,#onetrust-banner-sdk .ot-toggle,#onetrust-banner-sdk #ot-content,#onetrust-banner-sdk #ot-pc-content,#onetrust-banner-sdk .checkbox,#onetrust-pc-sdk div,#onetrust-pc-sdk span,#onetrust-pc-sdk h1,#onetrust-pc-sdk h2,#onetrust-pc-sdk h3,#onetrust-pc-sdk h4,#onetrust-pc-sdk h5,#onetrust-pc-sdk h6,#onetrust-pc-sdk p,#onetrust-pc-sdk img,#onetrust-pc-sdk svg,#onetrust-pc-sdk button,#onetrust-pc-sdk section,#onetrust-pc-sdk a,#onetrust-pc-sdk label,#onetrust-pc-sdk input,#onetrust-pc-sdk ul,#onetrust-pc-sdk li,#onetrust-pc-sdk nav,#onetrust-pc-sdk table,#onetrust-pc-sdk thead,#onetrust-pc-sdk tr,#onetrust-pc-sdk td,#onetrust-pc-sdk tbody,#onetrust-pc-sdk .ot-main-content,#onetrust-pc-sdk .ot-toggle,#onetrust-pc-sdk #ot-content,#onetrust-pc-sdk #ot-pc-content,#onetrust-pc-sdk .checkbox,#ot-sdk-cookie-policy div,#ot-sdk-cookie-policy span,#ot-sdk-cookie-policy h1,#ot-sdk-cookie-policy h2,#ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy h5,#ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy p,#ot-sdk-cookie-policy img,#ot-sdk-cookie-policy svg,#ot-sdk-cookie-policy button,#ot-sdk-cookie-policy section,#ot-sdk-cookie-policy a,#ot-sdk-cookie-policy label,#ot-sdk-cookie-policy input,#ot-sdk-cookie-policy ul,#ot-sdk-cookie-policy li,#ot-sdk-cookie-policy nav,#ot-sdk-cookie-policy table,#ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy tr,#ot-sdk-cookie-policy td,#ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy .ot-main-content,#ot-sdk-cookie-policy .ot-toggle,#ot-sdk-cookie-policy #ot-content,#ot-sdk-cookie-policy #ot-pc-content,#ot-sdk-cookie-policy .checkbox,#ot-sync-ntfy div,#ot-sync-ntfy span,#ot-sync-ntfy h1,#ot-sync-ntfy h2,#ot-sync-ntfy h3,#ot-sync-ntfy h4,#ot-sync-ntfy h5,#ot-sync-ntfy h6,#ot-sync-ntfy p,#ot-sync-ntfy img,#ot-sync-ntfy svg,#ot-sync-ntfy button,#ot-sync-ntfy section,#ot-sync-ntfy a,#ot-sync-ntfy label,#ot-sync-ntfy input,#ot-sync-ntfy ul,#ot-sync-ntfy li,#ot-sync-ntfy nav,#ot-sync-ntfy table,#ot-sync-ntfy thead,#ot-sync-ntfy tr,#ot-sync-ntfy td,#ot-sync-ntfy tbody,#ot-sync-ntfy .ot-main-content,#ot-sync-ntfy .ot-toggle,#ot-sync-ntfy #ot-content,#ot-sync-ntfy #ot-pc-content,#ot-sync-ntfy .checkbox{font-family:inherit;font-weight:normal;-webkit-font-smoothing:auto;letter-spacing:normal;line-height:normal;padding:0;margin:0;height:auto;min-height:0;max-height:none;width:auto;min-width:0;max-width:none;border-radius:0;border:none;clear:none;float:none;position:static;bottom:auto;left:auto;right:auto;top:auto;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;white-space:normal;background:none;overflow:visible;vertical-align:baseline;visibility:visible;z-index:auto;box-shadow:none}#onetrust-banner-sdk label:before,#onetrust-banner-sdk label:after,#onetrust-banner-sdk .checkbox:after,#onetrust-banner-sdk .checkbox:before,#onetrust-pc-sdk label:before,#onetrust-pc-sdk label:after,#onetrust-pc-sdk .checkbox:after,#onetrust-pc-sdk .checkbox:before,#ot-sdk-cookie-policy label:before,#ot-sdk-cookie-policy label:after,#ot-sdk-cookie-policy .checkbox:after,#ot-sdk-cookie-policy .checkbox:before,#ot-sync-ntfy label:before,#ot-sync-ntfy label:after,#ot-sync-ntfy .checkbox:after,#ot-sync-ntfy .checkbox:before{content:&quot;&quot;;content:none}
#onetrust-banner-sdk .ot-sdk-container,#onetrust-pc-sdk .ot-sdk-container,#ot-sdk-cookie-policy .ot-sdk-container{position:relative;width:100%;max-width:100%;margin:0 auto;padding:0 20px;box-sizing:border-box}#onetrust-banner-sdk .ot-sdk-column,#onetrust-banner-sdk .ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-column,#onetrust-pc-sdk .ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-columns{width:100%;float:left;box-sizing:border-box;padding:0;display:initial}@media (min-width: 400px){#onetrust-banner-sdk .ot-sdk-container,#onetrust-pc-sdk .ot-sdk-container,#ot-sdk-cookie-policy .ot-sdk-container{width:90%;padding:0}}@media (min-width: 550px){#onetrust-banner-sdk .ot-sdk-container,#onetrust-pc-sdk .ot-sdk-container,#ot-sdk-cookie-policy .ot-sdk-container{width:100%}#onetrust-banner-sdk .ot-sdk-column,#onetrust-banner-sdk .ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-column,#onetrust-pc-sdk .ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-columns{margin-left:4%}#onetrust-banner-sdk .ot-sdk-column:first-child,#onetrust-banner-sdk .ot-sdk-columns:first-child,#onetrust-pc-sdk .ot-sdk-column:first-child,#onetrust-pc-sdk .ot-sdk-columns:first-child,#ot-sdk-cookie-policy .ot-sdk-column:first-child,#ot-sdk-cookie-policy .ot-sdk-columns:first-child{margin-left:0}#onetrust-banner-sdk .ot-sdk-one.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-one.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-one.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-one.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-one.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-one.ot-sdk-columns{width:4.66666666667%}#onetrust-banner-sdk .ot-sdk-two.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-two.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-two.ot-sdk-columns{width:13.3333333333%}#onetrust-banner-sdk .ot-sdk-three.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-three.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-three.ot-sdk-columns{width:22%}#onetrust-banner-sdk .ot-sdk-four.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-four.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-four.ot-sdk-columns{width:30.6666666667%}#onetrust-banner-sdk .ot-sdk-five.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-five.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-five.ot-sdk-columns{width:39.3333333333%}#onetrust-banner-sdk .ot-sdk-six.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-six.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-six.ot-sdk-columns{width:48%}#onetrust-banner-sdk .ot-sdk-seven.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-seven.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-seven.ot-sdk-columns{width:56.6666666667%}#onetrust-banner-sdk .ot-sdk-eight.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-eight.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-eight.ot-sdk-columns{width:65.3333333333%}#onetrust-banner-sdk .ot-sdk-nine.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-nine.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-nine.ot-sdk-columns{width:74%}#onetrust-banner-sdk .ot-sdk-ten.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-ten.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-ten.ot-sdk-columns{width:82.6666666667%}#onetrust-banner-sdk .ot-sdk-eleven.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-eleven.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-eleven.ot-sdk-columns{width:91.3333333333%}#onetrust-banner-sdk .ot-sdk-twelve.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-twelve.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-twelve.ot-sdk-columns{width:100%;margin-left:0}#onetrust-banner-sdk .ot-sdk-one-third.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-one-third.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-one-third.ot-sdk-column{width:30.6666666667%}#onetrust-banner-sdk .ot-sdk-two-thirds.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-two-thirds.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-two-thirds.ot-sdk-column{width:65.3333333333%}#onetrust-banner-sdk .ot-sdk-one-half.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-one-half.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-one-half.ot-sdk-column{width:48%}#onetrust-banner-sdk .ot-sdk-offset-by-one.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-one.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-one.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-one.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-one.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-one.ot-sdk-columns{margin-left:8.66666666667%}#onetrust-banner-sdk .ot-sdk-offset-by-two.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-two.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-two.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-two.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-two.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-two.ot-sdk-columns{margin-left:17.3333333333%}#onetrust-banner-sdk .ot-sdk-offset-by-three.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-three.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-three.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-three.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-three.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-three.ot-sdk-columns{margin-left:26%}#onetrust-banner-sdk .ot-sdk-offset-by-four.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-four.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-four.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-four.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-four.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-four.ot-sdk-columns{margin-left:34.6666666667%}#onetrust-banner-sdk .ot-sdk-offset-by-five.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-five.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-five.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-five.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-five.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-five.ot-sdk-columns{margin-left:43.3333333333%}#onetrust-banner-sdk .ot-sdk-offset-by-six.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-six.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-six.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-six.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-six.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-six.ot-sdk-columns{margin-left:52%}#onetrust-banner-sdk .ot-sdk-offset-by-seven.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-seven.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-seven.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-seven.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-seven.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-seven.ot-sdk-columns{margin-left:60.6666666667%}#onetrust-banner-sdk .ot-sdk-offset-by-eight.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-eight.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-eight.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-eight.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-eight.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-eight.ot-sdk-columns{margin-left:69.3333333333%}#onetrust-banner-sdk .ot-sdk-offset-by-nine.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-nine.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-nine.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-nine.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-nine.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-nine.ot-sdk-columns{margin-left:78%}#onetrust-banner-sdk .ot-sdk-offset-by-ten.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-ten.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-ten.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-ten.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-ten.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-ten.ot-sdk-columns{margin-left:86.6666666667%}#onetrust-banner-sdk .ot-sdk-offset-by-eleven.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-eleven.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-eleven.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-eleven.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-eleven.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-eleven.ot-sdk-columns{margin-left:95.3333333333%}#onetrust-banner-sdk .ot-sdk-offset-by-one-third.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-one-third.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-one-third.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-one-third.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-one-third.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-one-third.ot-sdk-columns{margin-left:34.6666666667%}#onetrust-banner-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-two-thirds.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-two-thirds.ot-sdk-columns{margin-left:69.3333333333%}#onetrust-banner-sdk .ot-sdk-offset-by-one-half.ot-sdk-column,#onetrust-banner-sdk .ot-sdk-offset-by-one-half.ot-sdk-columns,#onetrust-pc-sdk .ot-sdk-offset-by-one-half.ot-sdk-column,#onetrust-pc-sdk .ot-sdk-offset-by-one-half.ot-sdk-columns,#ot-sdk-cookie-policy .ot-sdk-offset-by-one-half.ot-sdk-column,#ot-sdk-cookie-policy .ot-sdk-offset-by-one-half.ot-sdk-columns{margin-left:52%}}#onetrust-banner-sdk h1,#onetrust-banner-sdk h2,#onetrust-banner-sdk h3,#onetrust-banner-sdk h4,#onetrust-banner-sdk h5,#onetrust-banner-sdk h6,#onetrust-pc-sdk h1,#onetrust-pc-sdk h2,#onetrust-pc-sdk h3,#onetrust-pc-sdk h4,#onetrust-pc-sdk h5,#onetrust-pc-sdk h6,#ot-sdk-cookie-policy h1,#ot-sdk-cookie-policy h2,#ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy h5,#ot-sdk-cookie-policy h6{margin-top:0;font-weight:600;font-family:inherit}#onetrust-banner-sdk h1,#onetrust-pc-sdk h1,#ot-sdk-cookie-policy h1{font-size:1.5rem;line-height:1.2}#onetrust-banner-sdk h2,#onetrust-pc-sdk h2,#ot-sdk-cookie-policy h2{font-size:1.5rem;line-height:1.25}#onetrust-banner-sdk h3,#onetrust-pc-sdk h3,#ot-sdk-cookie-policy h3{font-size:1.5rem;line-height:1.3}#onetrust-banner-sdk h4,#onetrust-pc-sdk h4,#ot-sdk-cookie-policy h4{font-size:1.5rem;line-height:1.35}#onetrust-banner-sdk h5,#onetrust-pc-sdk h5,#ot-sdk-cookie-policy h5{font-size:1.5rem;line-height:1.5}#onetrust-banner-sdk h6,#onetrust-pc-sdk h6,#ot-sdk-cookie-policy h6{font-size:1.5rem;line-height:1.6}@media (min-width: 550px){#onetrust-banner-sdk h1,#onetrust-pc-sdk h1,#ot-sdk-cookie-policy h1{font-size:1.5rem}#onetrust-banner-sdk h2,#onetrust-pc-sdk h2,#ot-sdk-cookie-policy h2{font-size:1.5rem}#onetrust-banner-sdk h3,#onetrust-pc-sdk h3,#ot-sdk-cookie-policy h3{font-size:1.5rem}#onetrust-banner-sdk h4,#onetrust-pc-sdk h4,#ot-sdk-cookie-policy h4{font-size:1.5rem}#onetrust-banner-sdk h5,#onetrust-pc-sdk h5,#ot-sdk-cookie-policy h5{font-size:1.5rem}#onetrust-banner-sdk h6,#onetrust-pc-sdk h6,#ot-sdk-cookie-policy h6{font-size:1.5rem}}#onetrust-banner-sdk p,#onetrust-pc-sdk p,#ot-sdk-cookie-policy p{margin:0 0 1em 0;font-family:inherit;line-height:normal}#onetrust-banner-sdk a,#onetrust-pc-sdk a,#ot-sdk-cookie-policy a{color:#565656;text-decoration:underline}#onetrust-banner-sdk a:hover,#onetrust-pc-sdk a:hover,#ot-sdk-cookie-policy a:hover{color:#565656;text-decoration:none}#onetrust-banner-sdk .ot-sdk-button,#onetrust-banner-sdk button,#onetrust-pc-sdk .ot-sdk-button,#onetrust-pc-sdk button,#ot-sdk-cookie-policy .ot-sdk-button,#ot-sdk-cookie-policy button{margin-bottom:1rem;font-family:inherit}#onetrust-banner-sdk .ot-sdk-button,#onetrust-banner-sdk button,#onetrust-banner-sdk input[type=&quot;submit&quot;],#onetrust-banner-sdk input[type=&quot;reset&quot;],#onetrust-banner-sdk input[type=&quot;button&quot;],#onetrust-pc-sdk .ot-sdk-button,#onetrust-pc-sdk button,#onetrust-pc-sdk input[type=&quot;submit&quot;],#onetrust-pc-sdk input[type=&quot;reset&quot;],#onetrust-pc-sdk input[type=&quot;button&quot;],#ot-sdk-cookie-policy .ot-sdk-button,#ot-sdk-cookie-policy button,#ot-sdk-cookie-policy input[type=&quot;submit&quot;],#ot-sdk-cookie-policy input[type=&quot;reset&quot;],#ot-sdk-cookie-policy input[type=&quot;button&quot;]{display:inline-block;height:38px;padding:0 30px;color:#555;text-align:center;font-size:0.9em;font-weight:400;line-height:38px;letter-spacing:0.01em;text-decoration:none;white-space:nowrap;background-color:transparent;border-radius:2px;border:1px solid #bbb;cursor:pointer;box-sizing:border-box}#onetrust-banner-sdk .ot-sdk-button:hover,#onetrust-banner-sdk :not(.ot-leg-btn-container)>button:hover,#onetrust-banner-sdk input[type=&quot;submit&quot;]:hover,#onetrust-banner-sdk input[type=&quot;reset&quot;]:hover,#onetrust-banner-sdk input[type=&quot;button&quot;]:hover,#onetrust-banner-sdk .ot-sdk-button:focus,#onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus,#onetrust-banner-sdk input[type=&quot;submit&quot;]:focus,#onetrust-banner-sdk input[type=&quot;reset&quot;]:focus,#onetrust-banner-sdk input[type=&quot;button&quot;]:focus,#onetrust-pc-sdk .ot-sdk-button:hover,#onetrust-pc-sdk :not(.ot-leg-btn-container)>button:hover,#onetrust-pc-sdk input[type=&quot;submit&quot;]:hover,#onetrust-pc-sdk input[type=&quot;reset&quot;]:hover,#onetrust-pc-sdk input[type=&quot;button&quot;]:hover,#onetrust-pc-sdk .ot-sdk-button:focus,#onetrust-pc-sdk :not(.ot-leg-btn-container)>button:focus,#onetrust-pc-sdk input[type=&quot;submit&quot;]:focus,#onetrust-pc-sdk input[type=&quot;reset&quot;]:focus,#onetrust-pc-sdk input[type=&quot;button&quot;]:focus,#ot-sdk-cookie-policy .ot-sdk-button:hover,#ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:hover,#ot-sdk-cookie-policy input[type=&quot;submit&quot;]:hover,#ot-sdk-cookie-policy input[type=&quot;reset&quot;]:hover,#ot-sdk-cookie-policy input[type=&quot;button&quot;]:hover,#ot-sdk-cookie-policy .ot-sdk-button:focus,#ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:focus,#ot-sdk-cookie-policy input[type=&quot;submit&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;reset&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;button&quot;]:focus{color:#333;border-color:#888;opacity:0.7}#onetrust-banner-sdk .ot-sdk-button:focus,#onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus,#onetrust-banner-sdk input[type=&quot;submit&quot;]:focus,#onetrust-banner-sdk input[type=&quot;reset&quot;]:focus,#onetrust-banner-sdk input[type=&quot;button&quot;]:focus,#onetrust-pc-sdk .ot-sdk-button:focus,#onetrust-pc-sdk :not(.ot-leg-btn-container)>button:focus,#onetrust-pc-sdk input[type=&quot;submit&quot;]:focus,#onetrust-pc-sdk input[type=&quot;reset&quot;]:focus,#onetrust-pc-sdk input[type=&quot;button&quot;]:focus,#ot-sdk-cookie-policy .ot-sdk-button:focus,#ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:focus,#ot-sdk-cookie-policy input[type=&quot;submit&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;reset&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;button&quot;]:focus{outline:2px solid #000}#onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary,#onetrust-banner-sdk button.ot-sdk-button-primary,#onetrust-banner-sdk input[type=&quot;submit&quot;].ot-sdk-button-primary,#onetrust-banner-sdk input[type=&quot;reset&quot;].ot-sdk-button-primary,#onetrust-banner-sdk input[type=&quot;button&quot;].ot-sdk-button-primary,#onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary,#onetrust-pc-sdk button.ot-sdk-button-primary,#onetrust-pc-sdk input[type=&quot;submit&quot;].ot-sdk-button-primary,#onetrust-pc-sdk input[type=&quot;reset&quot;].ot-sdk-button-primary,#onetrust-pc-sdk input[type=&quot;button&quot;].ot-sdk-button-primary,#ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary,#ot-sdk-cookie-policy button.ot-sdk-button-primary,#ot-sdk-cookie-policy input[type=&quot;submit&quot;].ot-sdk-button-primary,#ot-sdk-cookie-policy input[type=&quot;reset&quot;].ot-sdk-button-primary,#ot-sdk-cookie-policy input[type=&quot;button&quot;].ot-sdk-button-primary{color:#fff;background-color:#33c3f0;border-color:#33c3f0}#onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:hover,#onetrust-banner-sdk button.ot-sdk-button-primary:hover,#onetrust-banner-sdk input[type=&quot;submit&quot;].ot-sdk-button-primary:hover,#onetrust-banner-sdk input[type=&quot;reset&quot;].ot-sdk-button-primary:hover,#onetrust-banner-sdk input[type=&quot;button&quot;].ot-sdk-button-primary:hover,#onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:focus,#onetrust-banner-sdk button.ot-sdk-button-primary:focus,#onetrust-banner-sdk input[type=&quot;submit&quot;].ot-sdk-button-primary:focus,#onetrust-banner-sdk input[type=&quot;reset&quot;].ot-sdk-button-primary:focus,#onetrust-banner-sdk input[type=&quot;button&quot;].ot-sdk-button-primary:focus,#onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:hover,#onetrust-pc-sdk button.ot-sdk-button-primary:hover,#onetrust-pc-sdk input[type=&quot;submit&quot;].ot-sdk-button-primary:hover,#onetrust-pc-sdk input[type=&quot;reset&quot;].ot-sdk-button-primary:hover,#onetrust-pc-sdk input[type=&quot;button&quot;].ot-sdk-button-primary:hover,#onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:focus,#onetrust-pc-sdk button.ot-sdk-button-primary:focus,#onetrust-pc-sdk input[type=&quot;submit&quot;].ot-sdk-button-primary:focus,#onetrust-pc-sdk input[type=&quot;reset&quot;].ot-sdk-button-primary:focus,#onetrust-pc-sdk input[type=&quot;button&quot;].ot-sdk-button-primary:focus,#ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:hover,#ot-sdk-cookie-policy button.ot-sdk-button-primary:hover,#ot-sdk-cookie-policy input[type=&quot;submit&quot;].ot-sdk-button-primary:hover,#ot-sdk-cookie-policy input[type=&quot;reset&quot;].ot-sdk-button-primary:hover,#ot-sdk-cookie-policy input[type=&quot;button&quot;].ot-sdk-button-primary:hover,#ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:focus,#ot-sdk-cookie-policy button.ot-sdk-button-primary:focus,#ot-sdk-cookie-policy input[type=&quot;submit&quot;].ot-sdk-button-primary:focus,#ot-sdk-cookie-policy input[type=&quot;reset&quot;].ot-sdk-button-primary:focus,#ot-sdk-cookie-policy input[type=&quot;button&quot;].ot-sdk-button-primary:focus{color:#fff;background-color:#1eaedb;border-color:#1eaedb}#onetrust-banner-sdk input[type=&quot;email&quot;],#onetrust-banner-sdk input[type=&quot;number&quot;],#onetrust-banner-sdk input[type=&quot;search&quot;],#onetrust-banner-sdk input[type=&quot;text&quot;],#onetrust-banner-sdk input[type=&quot;tel&quot;],#onetrust-banner-sdk input[type=&quot;url&quot;],#onetrust-banner-sdk input[type=&quot;password&quot;],#onetrust-banner-sdk textarea,#onetrust-banner-sdk select,#onetrust-pc-sdk input[type=&quot;email&quot;],#onetrust-pc-sdk input[type=&quot;number&quot;],#onetrust-pc-sdk input[type=&quot;search&quot;],#onetrust-pc-sdk input[type=&quot;text&quot;],#onetrust-pc-sdk input[type=&quot;tel&quot;],#onetrust-pc-sdk input[type=&quot;url&quot;],#onetrust-pc-sdk input[type=&quot;password&quot;],#onetrust-pc-sdk textarea,#onetrust-pc-sdk select,#ot-sdk-cookie-policy input[type=&quot;email&quot;],#ot-sdk-cookie-policy input[type=&quot;number&quot;],#ot-sdk-cookie-policy input[type=&quot;search&quot;],#ot-sdk-cookie-policy input[type=&quot;text&quot;],#ot-sdk-cookie-policy input[type=&quot;tel&quot;],#ot-sdk-cookie-policy input[type=&quot;url&quot;],#ot-sdk-cookie-policy input[type=&quot;password&quot;],#ot-sdk-cookie-policy textarea,#ot-sdk-cookie-policy select{height:38px;padding:6px 10px;background-color:#fff;border:1px solid #d1d1d1;border-radius:4px;box-shadow:none;box-sizing:border-box}#onetrust-banner-sdk input[type=&quot;email&quot;],#onetrust-banner-sdk input[type=&quot;number&quot;],#onetrust-banner-sdk input[type=&quot;search&quot;],#onetrust-banner-sdk input[type=&quot;text&quot;],#onetrust-banner-sdk input[type=&quot;tel&quot;],#onetrust-banner-sdk input[type=&quot;url&quot;],#onetrust-banner-sdk input[type=&quot;password&quot;],#onetrust-banner-sdk textarea,#onetrust-pc-sdk input[type=&quot;email&quot;],#onetrust-pc-sdk input[type=&quot;number&quot;],#onetrust-pc-sdk input[type=&quot;search&quot;],#onetrust-pc-sdk input[type=&quot;text&quot;],#onetrust-pc-sdk input[type=&quot;tel&quot;],#onetrust-pc-sdk input[type=&quot;url&quot;],#onetrust-pc-sdk input[type=&quot;password&quot;],#onetrust-pc-sdk textarea,#ot-sdk-cookie-policy input[type=&quot;email&quot;],#ot-sdk-cookie-policy input[type=&quot;number&quot;],#ot-sdk-cookie-policy input[type=&quot;search&quot;],#ot-sdk-cookie-policy input[type=&quot;text&quot;],#ot-sdk-cookie-policy input[type=&quot;tel&quot;],#ot-sdk-cookie-policy input[type=&quot;url&quot;],#ot-sdk-cookie-policy input[type=&quot;password&quot;],#ot-sdk-cookie-policy textarea{-webkit-appearance:none;-moz-appearance:none;appearance:none}#onetrust-banner-sdk textarea,#onetrust-pc-sdk textarea,#ot-sdk-cookie-policy textarea{min-height:65px;padding-top:6px;padding-bottom:6px}#onetrust-banner-sdk input[type=&quot;email&quot;]:focus,#onetrust-banner-sdk input[type=&quot;number&quot;]:focus,#onetrust-banner-sdk input[type=&quot;search&quot;]:focus,#onetrust-banner-sdk input[type=&quot;text&quot;]:focus,#onetrust-banner-sdk input[type=&quot;tel&quot;]:focus,#onetrust-banner-sdk input[type=&quot;url&quot;]:focus,#onetrust-banner-sdk input[type=&quot;password&quot;]:focus,#onetrust-banner-sdk textarea:focus,#onetrust-banner-sdk select:focus,#onetrust-pc-sdk input[type=&quot;email&quot;]:focus,#onetrust-pc-sdk input[type=&quot;number&quot;]:focus,#onetrust-pc-sdk input[type=&quot;search&quot;]:focus,#onetrust-pc-sdk input[type=&quot;text&quot;]:focus,#onetrust-pc-sdk input[type=&quot;tel&quot;]:focus,#onetrust-pc-sdk input[type=&quot;url&quot;]:focus,#onetrust-pc-sdk input[type=&quot;password&quot;]:focus,#onetrust-pc-sdk textarea:focus,#onetrust-pc-sdk select:focus,#ot-sdk-cookie-policy input[type=&quot;email&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;number&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;search&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;text&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;tel&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;url&quot;]:focus,#ot-sdk-cookie-policy input[type=&quot;password&quot;]:focus,#ot-sdk-cookie-policy textarea:focus,#ot-sdk-cookie-policy select:focus{border:1px solid #000;outline:0}#onetrust-banner-sdk label,#onetrust-banner-sdk legend,#onetrust-pc-sdk label,#onetrust-pc-sdk legend,#ot-sdk-cookie-policy label,#ot-sdk-cookie-policy legend{display:block;margin-bottom:0.5rem;font-weight:600}#onetrust-banner-sdk fieldset,#onetrust-pc-sdk fieldset,#ot-sdk-cookie-policy fieldset{padding:0;border-width:0}#onetrust-banner-sdk input[type=&quot;checkbox&quot;],#onetrust-banner-sdk input[type=&quot;radio&quot;],#onetrust-pc-sdk input[type=&quot;checkbox&quot;],#onetrust-pc-sdk input[type=&quot;radio&quot;],#ot-sdk-cookie-policy input[type=&quot;checkbox&quot;],#ot-sdk-cookie-policy input[type=&quot;radio&quot;]{display:inline}#onetrust-banner-sdk label>.label-body,#onetrust-pc-sdk label>.label-body,#ot-sdk-cookie-policy label>.label-body{display:inline-block;margin-left:0.5rem;font-weight:normal}#onetrust-banner-sdk ul,#onetrust-pc-sdk ul,#ot-sdk-cookie-policy ul{list-style:circle inside}#onetrust-banner-sdk ol,#onetrust-pc-sdk ol,#ot-sdk-cookie-policy ol{list-style:decimal inside}#onetrust-banner-sdk ol,#onetrust-banner-sdk ul,#onetrust-pc-sdk ol,#onetrust-pc-sdk ul,#ot-sdk-cookie-policy ol,#ot-sdk-cookie-policy ul{padding-left:0;margin-top:0}#onetrust-banner-sdk ul ul,#onetrust-banner-sdk ul ol,#onetrust-banner-sdk ol ol,#onetrust-banner-sdk ol ul,#onetrust-pc-sdk ul ul,#onetrust-pc-sdk ul ol,#onetrust-pc-sdk ol ol,#onetrust-pc-sdk ol ul,#ot-sdk-cookie-policy ul ul,#ot-sdk-cookie-policy ul ol,#ot-sdk-cookie-policy ol ol,#ot-sdk-cookie-policy ol ul{margin:1.5rem 0 1.5rem 3rem;font-size:90%}#onetrust-banner-sdk li,#onetrust-pc-sdk li,#ot-sdk-cookie-policy li{margin-bottom:1rem}#onetrust-banner-sdk code,#onetrust-pc-sdk code,#ot-sdk-cookie-policy code{padding:0.2rem 0.5rem;margin:0 0.2rem;font-size:90%;white-space:nowrap;background:#f1f1f1;border:1px solid #e1e1e1;border-radius:4px}#onetrust-banner-sdk pre>code,#onetrust-pc-sdk pre>code,#ot-sdk-cookie-policy pre>code{display:block;padding:1rem 1.5rem;white-space:pre}#onetrust-banner-sdk th,#onetrust-banner-sdk td,#onetrust-pc-sdk th,#onetrust-pc-sdk td,#ot-sdk-cookie-policy th,#ot-sdk-cookie-policy td{padding:12px 15px;text-align:left;border-bottom:1px solid #e1e1e1}#onetrust-banner-sdk .ot-sdk-u-full-width,#onetrust-pc-sdk .ot-sdk-u-full-width,#ot-sdk-cookie-policy .ot-sdk-u-full-width{width:100%;box-sizing:border-box}#onetrust-banner-sdk .ot-sdk-u-max-full-width,#onetrust-pc-sdk .ot-sdk-u-max-full-width,#ot-sdk-cookie-policy .ot-sdk-u-max-full-width{max-width:100%;box-sizing:border-box}#onetrust-banner-sdk .ot-sdk-u-pull-right,#onetrust-pc-sdk .ot-sdk-u-pull-right,#ot-sdk-cookie-policy .ot-sdk-u-pull-right{float:right}#onetrust-banner-sdk .ot-sdk-u-pull-left,#onetrust-pc-sdk .ot-sdk-u-pull-left,#ot-sdk-cookie-policy .ot-sdk-u-pull-left{float:left}#onetrust-banner-sdk hr,#onetrust-pc-sdk hr,#ot-sdk-cookie-policy hr{margin-top:3rem;margin-bottom:3.5rem;border-width:0;border-top:1px solid #e1e1e1}#onetrust-banner-sdk .ot-sdk-container:after,#onetrust-banner-sdk .ot-sdk-row:after,#onetrust-banner-sdk .ot-sdk-u-cf,#onetrust-pc-sdk .ot-sdk-container:after,#onetrust-pc-sdk .ot-sdk-row:after,#onetrust-pc-sdk .ot-sdk-u-cf,#ot-sdk-cookie-policy .ot-sdk-container:after,#ot-sdk-cookie-policy .ot-sdk-row:after,#ot-sdk-cookie-policy .ot-sdk-u-cf{content:&quot;&quot;;display:table;clear:both}#onetrust-banner-sdk .ot-sdk-row,#onetrust-pc-sdk .ot-sdk-row,#ot-sdk-cookie-policy .ot-sdk-row{margin:0;max-width:none;display:block}
#onetrust-banner-sdk{box-shadow:0 0 18px rgba(0,0,0,.2)}#onetrust-banner-sdk.otFlat{position:fixed;z-index:2147483645;bottom:0;right:0;left:0;background-color:#fff;max-height:90%;overflow-x:hidden;overflow-y:auto}#onetrust-banner-sdk>.ot-sdk-container{overflow:hidden}#onetrust-banner-sdk::-webkit-scrollbar{width:11px}#onetrust-banner-sdk::-webkit-scrollbar-thumb{border-radius:10px;background:#c1c1c1}#onetrust-banner-sdk{scrollbar-arrow-color:#c1c1c1;scrollbar-darkshadow-color:#c1c1c1;scrollbar-face-color:#c1c1c1;scrollbar-shadow-color:#c1c1c1}#onetrust-banner-sdk #onetrust-policy{margin:1.25em 0 .625em 2em;overflow:hidden}#onetrust-banner-sdk #onetrust-policy .ot-gv-list-handler{float:left;font-size:.82em;padding:0;margin-bottom:0;border:0;line-height:normal;height:auto;width:auto}#onetrust-banner-sdk #onetrust-policy-title{font-size:1.2em;line-height:1.3;margin-bottom:10px}#onetrust-banner-sdk #onetrust-policy-text{clear:both;text-align:left;font-size:.88em;line-height:1.4}#onetrust-banner-sdk #onetrust-policy-text *{font-size:inherit;line-height:inherit}#onetrust-banner-sdk #onetrust-policy-text a{font-weight:bold;margin-left:5px}#onetrust-banner-sdk #onetrust-policy-title,#onetrust-banner-sdk #onetrust-policy-text{color:dimgray;float:left}#onetrust-banner-sdk #onetrust-button-group-parent{min-height:1px;text-align:center}#onetrust-banner-sdk #onetrust-button-group{display:inline-block}#onetrust-banner-sdk #onetrust-accept-btn-handler,#onetrust-banner-sdk #onetrust-reject-all-handler,#onetrust-banner-sdk #onetrust-pc-btn-handler{background-color:#68b631;color:#fff;border-color:#68b631;margin-right:1em;min-width:125px;height:auto;white-space:normal;word-break:break-word;word-wrap:break-word;padding:12px 10px;line-height:1.2;font-size:.813em;font-weight:600}#onetrust-banner-sdk #onetrust-pc-btn-handler.cookie-setting-link{background-color:#fff;border:none;color:#68b631;text-decoration:underline;padding-right:0}#onetrust-banner-sdk #onetrust-close-btn-container{text-align:center}#onetrust-banner-sdk .onetrust-close-btn-ui{width:.8em;height:18px;margin:50% 0 0 50%;border:none}#onetrust-banner-sdk .onetrust-close-btn-ui.onetrust-lg{top:50%;margin:auto;transform:translate(-50%, -50%);position:absolute;padding:0}#onetrust-banner-sdk .banner_logo{display:none}#onetrust-banner-sdk .ot-b-addl-desc{clear:both;float:left;display:block}#onetrust-banner-sdk #banner-options{float:left;display:table;margin-right:0;margin-left:1em;width:calc(100% - 1em)}#onetrust-banner-sdk #banner-options label{margin:0;display:inline-block}#onetrust-banner-sdk .banner-option{margin-bottom:12px;border:none;float:left;padding:0}#onetrust-banner-sdk .banner-option:not(:first-child){padding:0;border:none}#onetrust-banner-sdk .banner-option-input{position:absolute;cursor:pointer;width:auto;height:20px;opacity:0}#onetrust-banner-sdk .banner-option-header{margin-bottom:6px;cursor:pointer;display:inline-block}#onetrust-banner-sdk .banner-option-header :first-child{font-size:.82em;line-height:1.4;color:dimgray;font-weight:bold;float:left}#onetrust-banner-sdk .banner-option-header .ot-arrow-container{display:inline-block;border-top:6px solid transparent;border-bottom:6px solid transparent;border-left:6px solid dimgray;margin-left:10px;margin-top:2px}#onetrust-banner-sdk .banner-option-details{display:none;font-size:.83em;line-height:1.5;padding:10px 0px 5px 10px;margin-right:10px;height:0px}#onetrust-banner-sdk .banner-option-details *{font-size:inherit;line-height:inherit;color:dimgray}#onetrust-banner-sdk .ot-arrow-container,#onetrust-banner-sdk .banner-option-details{transition:all 300ms ease-in 0s;-webkit-transition:all 300ms ease-in 0s;-moz-transition:all 300ms ease-in 0s;-o-transition:all 300ms ease-in 0s}#onetrust-banner-sdk .banner-option-input:checked~label .banner-option-header .ot-arrow-container{transform:rotate(90deg)}#onetrust-banner-sdk .banner-option-input:checked~.banner-option-details{height:auto;display:block}#onetrust-banner-sdk .ot-dpd-container{float:left}#onetrust-banner-sdk .ot-dpd-title{margin-bottom:10px}#onetrust-banner-sdk .ot-dpd-title,#onetrust-banner-sdk .ot-dpd-desc{font-size:.88em;line-height:1.4;color:dimgray}#onetrust-banner-sdk .ot-dpd-title *,#onetrust-banner-sdk .ot-dpd-desc *{font-size:inherit;line-height:inherit}#onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text *{margin-bottom:0}#onetrust-banner-sdk.ot-iab-2 .onetrust-vendors-list-handler{display:block;margin-left:0;margin-top:5px;clear:both;margin-bottom:0;padding:0;border:0;height:auto;width:auto}#onetrust-banner-sdk.ot-iab-2 #onetrust-button-group button{display:block}#onetrust-banner-sdk #onetrust-policy-text,#onetrust-banner-sdk .ot-dpd-desc,#onetrust-banner-sdk .ot-b-addl-desc{font-size:.813em;line-height:1.5}#onetrust-banner-sdk .ot-dpd-desc{margin-bottom:10px}#onetrust-banner-sdk .ot-dpd-desc>.ot-b-addl-desc{margin-top:10px;margin-bottom:10px;font-size:1em}@media only screen and (max-width: 425px){#onetrust-banner-sdk #onetrust-policy{margin-left:0}#onetrust-banner-sdk .ot-hide-small{display:none}#onetrust-banner-sdk #onetrust-button-group{display:block}#onetrust-banner-sdk #onetrust-accept-btn-handler,#onetrust-banner-sdk #onetrust-reject-all-handler,#onetrust-banner-sdk #onetrust-pc-btn-handler{width:100%}#onetrust-banner-sdk .onetrust-close-btn-ui{margin:5px 0 0 0;float:right;padding:0}#onetrust-banner-sdk #onetrust-close-btn-container-mobile,#onetrust-banner-sdk #onetrust-policy-title{display:inline;float:none}#onetrust-banner-sdk #banner-options{margin:0;padding:0;width:100%}}@media only screen and (min-width: 426px)and (max-width: 896px){#onetrust-banner-sdk #onetrust-policy{margin-left:1em;margin-right:1em}#onetrust-banner-sdk .onetrust-close-btn-ui.onetrust-lg{top:25%;right:2%}#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container{width:95%}#onetrust-banner-sdk.ot-iab-2 #onetrust-group-container{width:100%}#onetrust-banner-sdk #onetrust-button-group-parent{width:100%;position:relative;margin-left:0}#onetrust-banner-sdk .ot-hide-large{display:none}#onetrust-banner-sdk #onetrust-button-group button{display:inline-block}#onetrust-banner-sdk #onetrust-button-group{margin-right:0;text-align:center}#onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler{float:left}#onetrust-banner-sdk .has-reject-all-button #onetrust-reject-all-handler,#onetrust-banner-sdk .has-reject-all-button #onetrust-accept-btn-handler{float:right}#onetrust-banner-sdk .has-reject-all-button #onetrust-button-group{width:calc(100% - 2em);margin-right:0}#onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler.cookie-setting-link{padding-left:0px;text-align:left}#onetrust-banner-sdk.ot-buttons-fw .ot-sdk-three button{width:100%;text-align:center}#onetrust-banner-sdk.ot-buttons-fw #onetrust-button-group-parent button{float:none}#onetrust-banner-sdk.ot-buttons-fw #onetrust-pc-btn-handler.cookie-setting-link{text-align:center}}@media only screen and (min-width: 550px){#onetrust-banner-sdk .banner-option:not(:first-child){border-left:1px solid #d8d8d8;padding-left:25px}}@media only screen and (min-width: 425px)and (max-width: 550px){#onetrust-banner-sdk.ot-iab-2 #onetrust-button-group,#onetrust-banner-sdk.ot-iab-2 #onetrust-policy,#onetrust-banner-sdk.ot-iab-2 .banner-option{width:100%}}@media only screen and (min-width: 769px){#onetrust-banner-sdk .ot-hide-large{display:none}#onetrust-banner-sdk #onetrust-button-group{margin-right:30%}#onetrust-banner-sdk #banner-options{margin-left:2em;margin-right:5em;margin-bottom:1.25em;width:calc(100% - 7em)}#onetrust-banner-sdk .banner-option{float:none;display:table-cell}}@media only screen and (min-width: 1024px){#onetrust-banner-sdk #onetrust-policy{margin-left:2em}#onetrust-banner-sdk.vertical-align-content #onetrust-button-group-parent{position:absolute;top:50%;left:60%;transform:translateY(-50%)}#onetrust-banner-sdk.ot-iab-2 #onetrust-policy-title{width:50%}#onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text,#onetrust-banner-sdk.ot-iab-2 :not(.ot-dpd-desc)>.ot-b-addl-desc{margin-bottom:1em;width:50%;border-right:1px solid #d8d8d8;padding-right:1rem}#onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text{margin-bottom:0;padding-bottom:1em}#onetrust-banner-sdk.ot-iab-2 :not(.ot-dpd-desc)>.ot-b-addl-desc{margin-bottom:0;padding-bottom:1em}#onetrust-banner-sdk.ot-iab-2 .ot-dpd-container{width:45%;padding-left:1rem;display:inline-block;float:none}#onetrust-banner-sdk.ot-iab-2 .ot-dpd-title{line-height:1.7}#onetrust-banner-sdk.ot-iab-2 #onetrust-button-group-parent{left:auto;right:4%;margin-left:0}#onetrust-banner-sdk.ot-iab-2 #onetrust-button-group button{display:block}#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-button-group-parent{margin:auto;width:36%}#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container{width:60%}#onetrust-banner-sdk #onetrust-button-group{margin-right:auto}#onetrust-banner-sdk #onetrust-close-btn-container{float:right}#onetrust-banner-sdk #onetrust-accept-btn-handler,#onetrust-banner-sdk #onetrust-reject-all-handler,#onetrust-banner-sdk #onetrust-pc-btn-handler{margin-top:1em}}@media only screen and (min-width: 890px){#onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group-parent{padding-left:4%;margin-left:0}#onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group{margin-right:0;margin-top:1.25em;width:100%}#onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group button{width:100%;margin-bottom:5px;margin-top:5px}#onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group button:last-of-type{margin-bottom:20px}}@media only screen and (min-width: 1280px){#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container{width:55%}#onetrust-banner-sdk:not(.ot-iab-2) #onetrust-button-group-parent{width:44%;padding-left:2%;padding-right:2%}#onetrust-banner-sdk:not(.ot-iab-2).vertical-align-content #onetrust-button-group-parent{position:absolute;left:55%}}
        #onetrust-consent-sdk #onetrust-banner-sdk {background-color: #181616;}
            #onetrust-consent-sdk #onetrust-policy-title,
                    #onetrust-consent-sdk #onetrust-policy-text,
                    #onetrust-consent-sdk .ot-b-addl-desc,
                    #onetrust-consent-sdk .ot-dpd-desc,
                    #onetrust-consent-sdk .ot-dpd-title,
                    #onetrust-consent-sdk #onetrust-policy-text *:not(.onetrust-vendors-list-handler),
                    #onetrust-consent-sdk .ot-dpd-desc *:not(.onetrust-vendors-list-handler),
                    #onetrust-consent-sdk #onetrust-banner-sdk #banner-options * {
                        color: #f9fbf9;
                    }
            #onetrust-consent-sdk #onetrust-banner-sdk .banner-option-details {
                    background-color: #E9E9E9;}
            #onetrust-consent-sdk #onetrust-accept-btn-handler,
                         #onetrust-banner-sdk #onetrust-reject-all-handler {
                            background-color: #05b974;border-color: #05b974;
                            color: #f9fbf9;
                        }
            #onetrust-consent-sdk #onetrust-pc-btn-handler,
            #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link {
                color: #f9fbf9; border-color: #f9fbf9;
                background-color: 
                #181616;
            }#onetrust-pc-sdk.otPcCenter{overflow:hidden;position:fixed;margin:0 auto;top:5%;bottom:10%;right:0;left:0;width:40%;max-width:575px;min-width:575px;border-radius:2.5px;z-index:2147483647;background-color:#fff;-webkit-box-shadow:0px 2px 10px -3px #999;-moz-box-shadow:0px 2px 10px -3px #999;box-shadow:0px 2px 10px -3px #999}#onetrust-pc-sdk.otPcCenter[dir=rtl]{right:0;left:0}#onetrust-pc-sdk #ot-addtl-venlst .ot-arw-cntr,#onetrust-pc-sdk #ot-addtl-venlst .ot-plus-minus,#onetrust-pc-sdk .ot-hide-tgl{visibility:hidden}#onetrust-pc-sdk #ot-addtl-venlst .ot-arw-cntr *,#onetrust-pc-sdk #ot-addtl-venlst .ot-plus-minus *,#onetrust-pc-sdk .ot-hide-tgl *{visibility:hidden}#onetrust-pc-sdk #ot-gn-venlst .ot-ven-item .ot-acc-hdr{min-height:40px}#onetrust-pc-sdk .ot-pc-header{height:39px;padding:10px 0 10px 30px;border-bottom:1px solid #e9e9e9}#onetrust-pc-sdk #ot-pc-title,#onetrust-pc-sdk #ot-category-title,#onetrust-pc-sdk .ot-cat-header,#onetrust-pc-sdk #ot-lst-title,#onetrust-pc-sdk .ot-ven-hdr .ot-ven-name,#onetrust-pc-sdk .ot-always-active{font-weight:bold;color:dimgray}#onetrust-pc-sdk .ot-cat-header{float:left;font-weight:600;font-size:.875em;line-height:1.5;max-width:90%;vertical-align:middle}#onetrust-pc-sdk .ot-always-active-group .ot-cat-header{width:55%;font-weight:700}#onetrust-pc-sdk .ot-cat-item p{clear:both;float:left;margin-top:10px;margin-bottom:5px;line-height:1.5;font-size:.812em;color:dimgray}#onetrust-pc-sdk .ot-close-icon{height:10px;width:10px}#onetrust-pc-sdk #ot-pc-title{float:left;font-size:1em;line-height:1.5;margin-bottom:10px;margin-top:10px;width:100%}#onetrust-pc-sdk #accept-recommended-btn-handler{margin-right:10px;margin-bottom:25px;outline-offset:-1px}#onetrust-pc-sdk #ot-pc-desc{clear:both;width:100%;font-size:.812em;line-height:1.5;margin-bottom:25px}#onetrust-pc-sdk #ot-pc-desc a{margin-left:5px}#onetrust-pc-sdk #ot-pc-desc *{font-size:inherit;line-height:inherit}#onetrust-pc-sdk #ot-pc-desc ul li{padding:10px 0px}#onetrust-pc-sdk a{color:#656565;cursor:pointer}#onetrust-pc-sdk a:hover{color:#3860be}#onetrust-pc-sdk label{margin-bottom:0}#onetrust-pc-sdk #vdr-lst-dsc{font-size:.812em;line-height:1.5;padding:10px 15px 5px 15px}#onetrust-pc-sdk button{max-width:394px;padding:12px 30px;line-height:1;word-break:break-word;word-wrap:break-word;white-space:normal;font-weight:bold;height:auto}#onetrust-pc-sdk .ot-link-btn{padding:0;margin-bottom:0;border:0;font-weight:normal;line-height:normal;width:auto;height:auto}#onetrust-pc-sdk #ot-pc-content{position:absolute;overflow-y:scroll;padding-left:0px;padding-right:30px;top:60px;bottom:110px;margin:1px 3px 0 30px;width:calc(100% - 63px)}#onetrust-pc-sdk .ot-cat-grp .ot-always-active{float:right;clear:none;color:#3860be;margin:0;font-size:.813em;line-height:1.3}#onetrust-pc-sdk .ot-pc-scrollbar::-webkit-scrollbar-track{margin-right:20px}#onetrust-pc-sdk .ot-pc-scrollbar::-webkit-scrollbar{width:11px}#onetrust-pc-sdk .ot-pc-scrollbar::-webkit-scrollbar-thumb{border-radius:10px;background:#d8d8d8}#onetrust-pc-sdk input[type=checkbox]:focus+.ot-acc-hdr{outline:#000 1px solid}#onetrust-pc-sdk .ot-pc-scrollbar{scrollbar-arrow-color:#d8d8d8;scrollbar-darkshadow-color:#d8d8d8;scrollbar-face-color:#d8d8d8;scrollbar-shadow-color:#d8d8d8}#onetrust-pc-sdk .save-preference-btn-handler{margin-right:20px}#onetrust-pc-sdk .ot-pc-refuse-all-handler{margin-right:10px}#onetrust-pc-sdk #privacy-notice-link{text-decoration:underline}#onetrust-pc-sdk .ot-subgrp-cntr{display:inline-block;clear:both;width:100%;padding-top:15px}#onetrust-pc-sdk .ot-switch+.ot-subgrp-cntr{padding-top:10px}#onetrust-pc-sdk ul.ot-subgrps{margin:0;font-size:initial}#onetrust-pc-sdk ul.ot-subgrps li p,#onetrust-pc-sdk ul.ot-subgrps li h5{font-size:.813em;line-height:1.4;color:dimgray}#onetrust-pc-sdk ul.ot-subgrps .ot-switch{min-height:auto}#onetrust-pc-sdk ul.ot-subgrps .ot-switch-nob{top:0}#onetrust-pc-sdk ul.ot-subgrps .ot-acc-hdr{display:inline-block;width:100%}#onetrust-pc-sdk ul.ot-subgrps .ot-acc-txt{margin:0}#onetrust-pc-sdk ul.ot-subgrps li{padding:0;border:none}#onetrust-pc-sdk ul.ot-subgrps li h5{position:relative;top:5px;font-weight:bold;margin-bottom:0;float:left}#onetrust-pc-sdk li.ot-subgrp{margin-left:20px;overflow:auto}#onetrust-pc-sdk li.ot-subgrp>h5{width:calc(100% - 100px)}#onetrust-pc-sdk .ot-cat-item p>ul,#onetrust-pc-sdk li.ot-subgrp p>ul{margin:0px;list-style:disc;margin-left:15px;font-size:inherit}#onetrust-pc-sdk .ot-cat-item p>ul li,#onetrust-pc-sdk li.ot-subgrp p>ul li{font-size:inherit;padding-top:10px;padding-left:0px;padding-right:0px;border:none}#onetrust-pc-sdk .ot-cat-item p>ul li:last-child,#onetrust-pc-sdk li.ot-subgrp p>ul li:last-child{padding-bottom:10px}#onetrust-pc-sdk .ot-pc-logo{height:40px;width:120px;display:inline-block}#onetrust-pc-sdk .ot-pc-footer{position:absolute;bottom:0px;width:100%;max-height:160px;border-top:1px solid #d8d8d8}#onetrust-pc-sdk.ot-ftr-stacked .ot-pc-refuse-all-handler{margin-bottom:0px}#onetrust-pc-sdk.ot-ftr-stacked #ot-pc-content{bottom:160px}#onetrust-pc-sdk.ot-ftr-stacked .ot-pc-footer button{width:100%;max-width:none}#onetrust-pc-sdk.ot-ftr-stacked .ot-btn-container{margin:0 30px;width:calc(100% - 60px);padding-right:0}#onetrust-pc-sdk .ot-pc-footer-logo{height:30px;width:100%;text-align:right;background:#f4f4f4}#onetrust-pc-sdk .ot-pc-footer-logo a{display:inline-block;margin-top:5px;margin-right:10px}#onetrust-pc-sdk[dir=rtl] .ot-pc-footer-logo{direction:rtl}#onetrust-pc-sdk[dir=rtl] .ot-pc-footer-logo a{margin-right:25px}#onetrust-pc-sdk .ot-tgl{float:right;position:relative;z-index:1}#onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob{background-color:#cddcf2;border:1px solid #3860be}#onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob:before{-webkit-transform:translateX(20px);-ms-transform:translateX(20px);transform:translateX(20px);background-color:#3860be;border-color:#3860be}#onetrust-pc-sdk .ot-tgl input:focus+.ot-switch{outline:#000 solid 1px}#onetrust-pc-sdk .ot-switch{position:relative;display:inline-block;width:45px;height:25px}#onetrust-pc-sdk .ot-switch-nob{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#f2f1f1;border:1px solid #ddd;transition:all .2s ease-in 0s;-moz-transition:all .2s ease-in 0s;-o-transition:all .2s ease-in 0s;-webkit-transition:all .2s ease-in 0s;border-radius:20px}#onetrust-pc-sdk .ot-switch-nob:before{position:absolute;content:&quot;&quot;;height:21px;width:21px;bottom:1px;background-color:#7d7d7d;-webkit-transition:.4s;transition:.4s;border-radius:20px}#onetrust-pc-sdk .ot-chkbox input:checked~label::before{background-color:#3860be}#onetrust-pc-sdk .ot-chkbox input+label::after{content:none;color:#fff}#onetrust-pc-sdk .ot-chkbox input:checked+label::after{content:&quot;&quot;}#onetrust-pc-sdk .ot-chkbox input:focus+label::before{outline-style:solid;outline-width:2px;outline-style:auto}#onetrust-pc-sdk .ot-chkbox label{position:relative;display:inline-block;padding-left:30px;cursor:pointer;font-weight:500}#onetrust-pc-sdk .ot-chkbox label::before,#onetrust-pc-sdk .ot-chkbox label::after{position:absolute;content:&quot;&quot;;display:inline-block;border-radius:3px}#onetrust-pc-sdk .ot-chkbox label::before{height:18px;width:18px;border:1px solid #3860be;left:0px;top:auto}#onetrust-pc-sdk .ot-chkbox label::after{height:5px;width:9px;border-left:3px solid;border-bottom:3px solid;transform:rotate(-45deg);-o-transform:rotate(-45deg);-ms-transform:rotate(-45deg);-webkit-transform:rotate(-45deg);left:4px;top:5px}#onetrust-pc-sdk .ot-label-txt{display:none}#onetrust-pc-sdk .ot-chkbox input,#onetrust-pc-sdk .ot-tgl input{position:absolute;opacity:0;width:0;height:0}#onetrust-pc-sdk .ot-arw-cntr{float:right;position:relative}#onetrust-pc-sdk .ot-arw-cntr .ot-arw{width:16px;height:16px;margin-left:5px;color:dimgray;display:inline-block;vertical-align:middle;-webkit-transition:all 300ms ease-in 0s;-moz-transition:all 300ms ease-in 0s;-o-transition:all 300ms ease-in 0s;transition:all 300ms ease-in 0s}#onetrust-pc-sdk input:checked~.ot-acc-hdr .ot-arw{transform:rotate(90deg);-o-transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg)}#onetrust-pc-sdk input[type=checkbox]:focus+.ot-acc-hdr{outline:#000 1px solid}#onetrust-pc-sdk .ot-tgl-cntr,#onetrust-pc-sdk .ot-arw-cntr{display:inline-block}#onetrust-pc-sdk .ot-tgl-cntr{width:45px;float:right;margin-top:2px}#onetrust-pc-sdk #ot-lst-cnt .ot-tgl-cntr{margin-top:10px}#onetrust-pc-sdk .ot-always-active-subgroup{width:auto;padding-left:0px !important;top:3px;position:relative}#onetrust-pc-sdk .ot-label-status{padding-left:5px;font-size:.75em;display:none}#onetrust-pc-sdk .ot-arw-cntr{margin-top:-1px}#onetrust-pc-sdk .ot-arw-cntr svg{-webkit-transition:all 300ms ease-in 0s;-moz-transition:all 300ms ease-in 0s;-o-transition:all 300ms ease-in 0s;transition:all 300ms ease-in 0s;height:10px;width:10px}#onetrust-pc-sdk input:checked~.ot-acc-hdr .ot-arw{transform:rotate(90deg);-o-transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg)}#onetrust-pc-sdk .ot-arw{width:10px;margin-left:15px;transition:all 300ms ease-in 0s;-webkit-transition:all 300ms ease-in 0s;-moz-transition:all 300ms ease-in 0s;-o-transition:all 300ms ease-in 0s}#onetrust-pc-sdk .ot-vlst-cntr{margin-bottom:0}#onetrust-pc-sdk .ot-hlst-cntr{margin-top:5px;display:inline-block;width:100%}#onetrust-pc-sdk .category-vendors-list-handler,#onetrust-pc-sdk .category-vendors-list-handler+a,#onetrust-pc-sdk .category-host-list-handler{clear:both;color:#3860be;margin-left:0;font-size:.813em;text-decoration:none;float:left;overflow:hidden}#onetrust-pc-sdk .category-vendors-list-handler:hover,#onetrust-pc-sdk .category-vendors-list-handler+a:hover,#onetrust-pc-sdk .category-host-list-handler:hover{color:#1883fd}#onetrust-pc-sdk .category-vendors-list-handler+a{clear:none}#onetrust-pc-sdk .category-vendors-list-handler+a::after{content:&quot;&quot;;height:15px;width:15px;background-repeat:no-repeat;margin-left:5px;float:right;background-image:url(&quot;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 511.626 511.627'%3E%3Cg fill='%231276CE'%3E%3Cpath d='M392.857 292.354h-18.274c-2.669 0-4.859.855-6.563 2.573-1.718 1.708-2.573 3.897-2.573 6.563v91.361c0 12.563-4.47 23.315-13.415 32.262-8.945 8.945-19.701 13.414-32.264 13.414H82.224c-12.562 0-23.317-4.469-32.264-13.414-8.945-8.946-13.417-19.698-13.417-32.262V155.31c0-12.562 4.471-23.313 13.417-32.259 8.947-8.947 19.702-13.418 32.264-13.418h200.994c2.669 0 4.859-.859 6.57-2.57 1.711-1.713 2.566-3.9 2.566-6.567V82.221c0-2.662-.855-4.853-2.566-6.563-1.711-1.713-3.901-2.568-6.57-2.568H82.224c-22.648 0-42.016 8.042-58.102 24.125C8.042 113.297 0 132.665 0 155.313v237.542c0 22.647 8.042 42.018 24.123 58.095 16.086 16.084 35.454 24.13 58.102 24.13h237.543c22.647 0 42.017-8.046 58.101-24.13 16.085-16.077 24.127-35.447 24.127-58.095v-91.358c0-2.669-.856-4.859-2.574-6.57-1.713-1.718-3.903-2.573-6.565-2.573z'/%3E%3Cpath d='M506.199 41.971c-3.617-3.617-7.905-5.424-12.85-5.424H347.171c-4.948 0-9.233 1.807-12.847 5.424-3.617 3.615-5.428 7.898-5.428 12.847s1.811 9.233 5.428 12.85l50.247 50.248-186.147 186.151c-1.906 1.903-2.856 4.093-2.856 6.563 0 2.479.953 4.668 2.856 6.571l32.548 32.544c1.903 1.903 4.093 2.852 6.567 2.852s4.665-.948 6.567-2.852l186.148-186.148 50.251 50.248c3.614 3.617 7.898 5.426 12.847 5.426s9.233-1.809 12.851-5.426c3.617-3.616 5.424-7.898 5.424-12.847V54.818c-.001-4.952-1.814-9.232-5.428-12.847z'/%3E%3C/g%3E%3C/svg%3E&quot;)}#onetrust-pc-sdk .back-btn-handler{font-size:1em;text-decoration:none}#onetrust-pc-sdk .back-btn-handler:hover{opacity:.6}#onetrust-pc-sdk #ot-lst-title span{display:inline-block;word-break:break-word;word-wrap:break-word;margin-bottom:0;color:#656565;font-size:1em;font-weight:bold;margin-left:15px}#onetrust-pc-sdk #ot-lst-title{margin:10px 0 10px 0px;font-size:1em;text-align:left}#onetrust-pc-sdk #ot-pc-hdr{margin:0 0 0 30px;height:auto;width:auto}#onetrust-pc-sdk #ot-pc-hdr input::placeholder{color:#d4d4d4;font-style:italic}#onetrust-pc-sdk #vendor-search-handler{height:31px;width:100%;border-radius:50px;font-size:.8em;padding-right:35px;padding-left:15px;float:left;margin-left:15px}#onetrust-pc-sdk .ot-ven-name{display:block;width:auto;padding-right:5px}#onetrust-pc-sdk #ot-lst-cnt{overflow-y:auto;margin-left:20px;margin-right:7px;width:calc(100% - 27px);max-height:calc(100% - 80px);height:100%;transform:translate3d(0, 0, 0)}#onetrust-pc-sdk #ot-lst-cnt.no-results{height:calc(100% - 300px)}#onetrust-pc-sdk #ot-pc-lst{width:100%;bottom:160px;position:absolute;top:60px}#onetrust-pc-sdk #ot-pc-lst:not(.ot-enbl-chr) .ot-tgl-cntr .ot-arw-cntr,#onetrust-pc-sdk #ot-pc-lst:not(.ot-enbl-chr) .ot-tgl-cntr .ot-arw-cntr *{visibility:hidden}#onetrust-pc-sdk #ot-pc-lst .ot-tgl-cntr{right:12px;position:absolute}#onetrust-pc-sdk #ot-pc-lst .ot-arw-cntr{float:right;position:relative}#onetrust-pc-sdk #ot-pc-lst .ot-arw{margin-left:10px}#onetrust-pc-sdk #ot-pc-lst .ot-acc-hdr{overflow:hidden;cursor:pointer}#onetrust-pc-sdk .ot-vlst-cntr{overflow:hidden}#onetrust-pc-sdk #ot-sel-blk{overflow:hidden;width:100%;position:sticky;position:-webkit-sticky;top:0;z-index:3}#onetrust-pc-sdk #ot-back-arw{height:12px;width:12px}#onetrust-pc-sdk .ot-lst-subhdr{width:100%;display:inline-block}#onetrust-pc-sdk .ot-search-cntr{float:left;width:78%;position:relative}#onetrust-pc-sdk .ot-search-cntr>svg{width:30px;height:30px;position:absolute;float:left;right:-15px}#onetrust-pc-sdk .ot-fltr-cntr{float:right;right:50px;position:relative}#onetrust-pc-sdk #filter-btn-handler{background-color:#3860be;border-radius:17px;display:inline-block;position:relative;width:32px;height:32px;-moz-transition:.1s ease;-o-transition:.1s ease;-webkit-transition:1s ease;transition:.1s ease;padding:0;margin:0}#onetrust-pc-sdk #filter-btn-handler:hover{background-color:#3860be}#onetrust-pc-sdk #filter-btn-handler svg{width:12px;height:12px;margin:3px 10px 0 10px;display:block;position:static;right:auto;top:auto}#onetrust-pc-sdk .ot-ven-link{color:#3860be;text-decoration:none;font-weight:100;display:inline-block;padding-top:10px;transform:translate(0, 1%);-o-transform:translate(0, 1%);-ms-transform:translate(0, 1%);-webkit-transform:translate(0, 1%);position:relative;z-index:2}#onetrust-pc-sdk .ot-ven-link *{font-size:inherit}#onetrust-pc-sdk .ot-ven-link:hover{text-decoration:underline}#onetrust-pc-sdk .ot-ven-hdr{width:calc(100% - 160px);height:auto;float:left;word-break:break-word;word-wrap:break-word;vertical-align:middle;padding-bottom:3px}#onetrust-pc-sdk .ot-ven-link{letter-spacing:.03em;font-size:.75em;font-weight:400}#onetrust-pc-sdk .ot-ven-dets{border-radius:2px;background-color:#f8f8f8}#onetrust-pc-sdk .ot-ven-dets div:first-child p:first-child{border-top:none}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:not(:first-child){border-top:1px solid #e9e9e9}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:nth-child(n+3) p{display:inline-block}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:nth-child(n+3) p:nth-of-type(odd){width:30%}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:nth-child(n+3) p:nth-of-type(even){width:50%;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc p{padding-top:5px;padding-bottom:5px;display:block}#onetrust-pc-sdk .ot-ven-dets p{font-size:.69em;text-align:left;vertical-align:middle;word-break:break-word;word-wrap:break-word;margin:0;padding-bottom:10px;padding-left:15px;color:#2e3644}#onetrust-pc-sdk .ot-ven-dets p:first-child{padding-top:5px}#onetrust-pc-sdk .ot-ven-dets .ot-ven-pur p:first-child{border-top:1px solid #e9e9e9;border-bottom:1px solid #e9e9e9;padding-bottom:5px;margin-bottom:5px;font-weight:bold}#onetrust-pc-sdk #ot-host-lst .ot-sel-all{float:right;position:relative;margin-right:42px;top:10px}#onetrust-pc-sdk #ot-host-lst .ot-sel-all input[type=checkbox]{width:auto;height:auto}#onetrust-pc-sdk #ot-host-lst .ot-sel-all label{height:20px;width:20px;padding-left:0px}#onetrust-pc-sdk #ot-host-lst .ot-acc-txt{overflow:hidden;width:95%}#onetrust-pc-sdk .ot-host-hdr{width:calc(100% - 125px);float:left}#onetrust-pc-sdk .ot-host-name,#onetrust-pc-sdk .ot-host-desc{display:inline-block;width:90%}#onetrust-pc-sdk .ot-host-hdr>a{text-decoration:underline;font-size:.82em;position:relative;z-index:2;float:left;width:100%;margin-bottom:5px}#onetrust-pc-sdk .ot-host-name+a{margin-top:5px}#onetrust-pc-sdk .ot-host-expand{margin-top:3px;margin-bottom:3px}#onetrust-pc-sdk .ot-host-name,#onetrust-pc-sdk .ot-host-name a,#onetrust-pc-sdk .ot-host-desc,#onetrust-pc-sdk .ot-host-info{color:dimgray;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-host-name,#onetrust-pc-sdk .ot-host-name a{font-weight:bold;font-size:.82em;line-height:1.3}#onetrust-pc-sdk .ot-host-name a{font-size:1em}#onetrust-pc-sdk .ot-host-expand{color:#3860be;font-size:.72em;font-weight:normal;display:inline-block}#onetrust-pc-sdk .ot-host-expand *{font-size:inherit}#onetrust-pc-sdk .ot-host-desc,#onetrust-pc-sdk .ot-host-info{font-size:.688em;line-height:1.4;font-weight:normal}#onetrust-pc-sdk .ot-host-desc{margin-top:10px}#onetrust-pc-sdk .ot-host-opt{margin:0;font-size:inherit;display:inline-block;width:100%}#onetrust-pc-sdk .ot-host-opt li>div div{font-size:.8em;padding:5px 0}#onetrust-pc-sdk .ot-host-opt li>div div:nth-child(1){width:30%;float:left}#onetrust-pc-sdk .ot-host-opt li>div div:nth-child(2){width:70%;float:left;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-host-info{border:none;display:inline-block;width:calc(100% - 10px);padding:10px;margin-bottom:10px;background-color:#f8f8f8}#onetrust-pc-sdk #no-results{text-align:center;margin-top:30px}#onetrust-pc-sdk #no-results p{font-size:1em;color:#2e3644;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk #no-results p span{font-weight:bold}#onetrust-pc-sdk #ot-fltr-modal{width:100%;height:auto;display:none;-moz-transition:.2s ease;-o-transition:.2s ease;-webkit-transition:2s ease;transition:.2s ease;overflow:hidden;opacity:1;right:0}#onetrust-pc-sdk #ot-fltr-modal .ot-label-txt{display:inline-block;font-size:.85em;color:dimgray}#onetrust-pc-sdk #ot-fltr-cnt{z-index:2147483646;background-color:#fff;position:absolute;height:90%;max-height:300px;width:325px;left:210px;margin-top:10px;margin-bottom:20px;padding-right:10px;border-radius:3px;-webkit-box-shadow:0px 0px 12px 2px #c7c5c7;-moz-box-shadow:0px 0px 12px 2px #c7c5c7;box-shadow:0px 0px 12px 2px #c7c5c7}#onetrust-pc-sdk .ot-fltr-scrlcnt{overflow-y:auto;overflow-x:hidden;clear:both;max-height:calc(100% - 60px)}#onetrust-pc-sdk #ot-anchor{border:12px solid transparent;display:none;position:absolute;z-index:2147483647;right:55px;top:75px;transform:rotate(45deg);-o-transform:rotate(45deg);-ms-transform:rotate(45deg);-webkit-transform:rotate(45deg);background-color:#fff;-webkit-box-shadow:-3px -3px 5px -2px #c7c5c7;-moz-box-shadow:-3px -3px 5px -2px #c7c5c7;box-shadow:-3px -3px 5px -2px #c7c5c7}#onetrust-pc-sdk .ot-fltr-btns{margin-left:15px}#onetrust-pc-sdk #filter-apply-handler{margin-right:15px}#onetrust-pc-sdk .ot-fltr-opt{margin-bottom:25px;margin-left:15px;width:75%;position:relative}#onetrust-pc-sdk .ot-fltr-opt p{display:inline-block;margin:0;font-size:.9em;color:#2e3644}#onetrust-pc-sdk .ot-chkbox label span{font-size:.85em;color:dimgray}#onetrust-pc-sdk .ot-chkbox input[type=checkbox]+label::after{content:none;color:#fff}#onetrust-pc-sdk .ot-chkbox input[type=checkbox]:checked+label::after{content:&quot;&quot;}#onetrust-pc-sdk .ot-chkbox input[type=checkbox]:focus+label::before{outline-style:solid;outline-width:2px;outline-style:auto}#onetrust-pc-sdk #ot-selall-vencntr,#onetrust-pc-sdk #ot-selall-adtlvencntr,#onetrust-pc-sdk #ot-selall-hostcntr,#onetrust-pc-sdk #ot-selall-licntr,#onetrust-pc-sdk #ot-selall-gnvencntr{right:15px;position:relative;width:20px;height:20px;float:right}#onetrust-pc-sdk #ot-selall-vencntr label,#onetrust-pc-sdk #ot-selall-adtlvencntr label,#onetrust-pc-sdk #ot-selall-hostcntr label,#onetrust-pc-sdk #ot-selall-licntr label,#onetrust-pc-sdk #ot-selall-gnvencntr label{float:left;padding-left:0}#onetrust-pc-sdk #ot-ven-lst:first-child{border-top:1px solid #e2e2e2}#onetrust-pc-sdk ul{list-style:none;padding:0}#onetrust-pc-sdk ul li{position:relative;margin:0;padding:15px 15px 15px 10px;border-bottom:1px solid #e2e2e2}#onetrust-pc-sdk ul li h3{font-size:.75em;color:#656565;margin:0;display:inline-block;width:70%;height:auto;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk ul li p{margin:0;font-size:.7em}#onetrust-pc-sdk ul li input[type=checkbox]{position:absolute;cursor:pointer;width:100%;height:100%;opacity:0;margin:0;top:0;left:0}#onetrust-pc-sdk .ot-cat-item>button:focus,#onetrust-pc-sdk .ot-acc-cntr>button:focus,#onetrust-pc-sdk li>button:focus{outline:#000 solid 2px}#onetrust-pc-sdk .ot-cat-item>button,#onetrust-pc-sdk .ot-acc-cntr>button,#onetrust-pc-sdk li>button{position:absolute;cursor:pointer;width:100%;height:100%;margin:0;top:0;left:0;z-index:1;max-width:none;border:none}#onetrust-pc-sdk .ot-cat-item>button[aria-expanded=false]~.ot-acc-txt,#onetrust-pc-sdk .ot-acc-cntr>button[aria-expanded=false]~.ot-acc-txt,#onetrust-pc-sdk li>button[aria-expanded=false]~.ot-acc-txt{margin-top:0;max-height:0;opacity:0;overflow:hidden;width:100%;transition:.25s ease-out;display:none}#onetrust-pc-sdk .ot-cat-item>button[aria-expanded=true]~.ot-acc-txt,#onetrust-pc-sdk .ot-acc-cntr>button[aria-expanded=true]~.ot-acc-txt,#onetrust-pc-sdk li>button[aria-expanded=true]~.ot-acc-txt{transition:.1s ease-in;margin-top:10px;width:100%;overflow:auto;display:block}#onetrust-pc-sdk .ot-cat-item>button[aria-expanded=true]~.ot-acc-grpcntr,#onetrust-pc-sdk .ot-acc-cntr>button[aria-expanded=true]~.ot-acc-grpcntr,#onetrust-pc-sdk li>button[aria-expanded=true]~.ot-acc-grpcntr{width:auto;margin-top:0px;padding-bottom:10px}#onetrust-pc-sdk .ot-host-item>button:focus,#onetrust-pc-sdk .ot-ven-item>button:focus{outline:0;border:2px solid #000}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt){padding-right:10px;width:calc(100% - 37px);margin-top:10px;max-height:calc(100% - 90px)}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) #ot-sel-blk{background-color:#f9f9fc;border:1px solid #e2e2e2;width:calc(100% - 2px);padding-bottom:5px;padding-top:5px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) .ot-sel-all{padding-right:34px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) .ot-sel-all-chkbox{width:auto}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) ul li{border:1px solid #e2e2e2;margin-bottom:10px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) .ot-acc-cntr>.ot-acc-hdr{padding:10px 0 10px 15px}#onetrust-pc-sdk.ot-addtl-vendors .ot-sel-all-chkbox{right:8px;float:right}#onetrust-pc-sdk.ot-addtl-vendors .ot-plus-minus~.ot-sel-all-chkbox{right:34px}#onetrust-pc-sdk.ot-addtl-vendors #ot-ven-lst:first-child{border-top:none}#onetrust-pc-sdk .ot-acc-cntr{position:relative;border-left:1px solid #e2e2e2;border-right:1px solid #e2e2e2;border-bottom:1px solid #e2e2e2}#onetrust-pc-sdk .ot-acc-cntr input{z-index:1}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr{background-color:#f9f9fc;padding:5px 0 5px 15px;width:auto}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr .ot-plus-minus{vertical-align:middle;top:auto}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr .ot-arw-cntr{right:10px}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr input{z-index:2}#onetrust-pc-sdk .ot-acc-cntr>input[type=checkbox]:checked~.ot-acc-hdr{border-bottom:1px solid #e2e2e2}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-txt{padding-left:10px;padding-right:10px}#onetrust-pc-sdk .ot-acc-cntr button[aria-expanded=true]~.ot-acc-txt{width:auto}#onetrust-pc-sdk .ot-acc-cntr .ot-addtl-venbox{display:none}#onetrust-pc-sdk .ot-vlst-cntr{margin-bottom:0;width:100%}#onetrust-pc-sdk .ot-vensec-title{font-size:.813em;vertical-align:middle;display:inline-block}#onetrust-pc-sdk .category-vendors-list-handler,#onetrust-pc-sdk .category-vendors-list-handler+a{margin-left:0;margin-top:10px}#onetrust-pc-sdk #ot-selall-vencntr.line-through label::after,#onetrust-pc-sdk #ot-selall-adtlvencntr.line-through label::after,#onetrust-pc-sdk #ot-selall-licntr.line-through label::after,#onetrust-pc-sdk #ot-selall-hostcntr.line-through label::after,#onetrust-pc-sdk #ot-selall-gnvencntr.line-through label::after{height:auto;border-left:0;transform:none;-o-transform:none;-ms-transform:none;-webkit-transform:none;left:5px;top:9px}#onetrust-pc-sdk #ot-category-title{float:left;padding-bottom:10px;font-size:1em;width:100%}#onetrust-pc-sdk .ot-cat-grp{margin-top:10px}#onetrust-pc-sdk .ot-cat-item{line-height:1.1;margin-top:10px;display:inline-block;width:100%}#onetrust-pc-sdk .ot-btn-container{text-align:right}#onetrust-pc-sdk .ot-btn-container button{display:inline-block;font-size:.75em;letter-spacing:.08em;margin-top:19px}#onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon{position:absolute;top:20px;right:20px;z-index:1;padding:0;background-color:transparent;border:none}#onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon:hover{opacity:.7}#onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon svg{display:block;height:10px;width:10px}#onetrust-pc-sdk #clear-filters-handler{margin-top:20px;float:right;max-width:200px;text-decoration:none;color:#3860be;font-size:.9em;font-weight:bold;background-color:transparent;border-color:transparent;padding:1px}#onetrust-pc-sdk #clear-filters-handler:hover{color:#2285f7}#onetrust-pc-sdk #clear-filters-handler:focus{outline:#000 solid 1px}#onetrust-pc-sdk .ot-accordion-layout.ot-cat-item{position:relative;border-radius:2px;margin:0;padding:0;border:1px solid #d8d8d8;border-top:none;width:calc(100% - 2px);float:left}#onetrust-pc-sdk .ot-accordion-layout.ot-cat-item:first-of-type{margin-top:10px;border-top:1px solid #d8d8d8}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpdesc{padding-left:20px;padding-right:20px;width:calc(100% - 40px);font-size:.812em;margin-bottom:10px;margin-top:15px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpdesc>ul{padding-top:10px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpdesc>ul li{padding-top:0;line-height:1.5;padding-bottom:10px}#onetrust-pc-sdk .ot-accordion-layout div+.ot-acc-grpdesc{margin-top:5px}#onetrust-pc-sdk .ot-accordion-layout .ot-vlst-cntr:first-child{margin-top:10px}#onetrust-pc-sdk .ot-accordion-layout .ot-vlst-cntr:last-child,#onetrust-pc-sdk .ot-accordion-layout .ot-hlst-cntr:last-child{margin-bottom:5px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-hdr{padding-top:11.5px;padding-bottom:11.5px;padding-left:20px;padding-right:20px;width:calc(100% - 40px);display:inline-block}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-txt{width:100%;padding:0px}#onetrust-pc-sdk .ot-accordion-layout .ot-subgrp-cntr{padding-left:20px;padding-right:15px;padding-bottom:0;width:calc(100% - 35px)}#onetrust-pc-sdk .ot-accordion-layout .ot-subgrp{padding-right:5px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpcntr{z-index:1;position:relative}#onetrust-pc-sdk .ot-accordion-layout .ot-cat-header+.ot-arw-cntr{position:absolute;top:50%;transform:translateY(-50%);right:20px;margin-top:-2px}#onetrust-pc-sdk .ot-accordion-layout .ot-cat-header+.ot-arw-cntr .ot-arw{width:15px;height:20px;margin-left:5px;color:dimgray}#onetrust-pc-sdk .ot-accordion-layout .ot-cat-header{float:none;color:#2e3644;margin:0;display:inline-block;height:auto;word-wrap:break-word;min-height:inherit}#onetrust-pc-sdk .ot-accordion-layout .ot-vlst-cntr,#onetrust-pc-sdk .ot-accordion-layout .ot-hlst-cntr{padding-left:20px;width:calc(100% - 20px);display:inline-block;margin-top:0px;padding-bottom:2px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-hdr{position:relative;min-height:25px}#onetrust-pc-sdk .ot-accordion-layout h4~.ot-tgl,#onetrust-pc-sdk .ot-accordion-layout h4~.ot-always-active{position:absolute;top:50%;transform:translateY(-50%);right:20px}#onetrust-pc-sdk .ot-accordion-layout h4~.ot-tgl+.ot-tgl{right:95px}#onetrust-pc-sdk .ot-accordion-layout .category-vendors-list-handler,#onetrust-pc-sdk .ot-accordion-layout .category-vendors-list-handler+a{margin-top:5px}#onetrust-pc-sdk .ot-enbl-chr h4~.ot-tgl,#onetrust-pc-sdk .ot-enbl-chr h4~.ot-always-active{right:45px}#onetrust-pc-sdk .ot-enbl-chr h4~.ot-tgl+.ot-tgl{right:120px}#onetrust-pc-sdk .ot-enbl-chr .ot-pli-hdr.ot-leg-border-color span:first-child{width:90px}#onetrust-pc-sdk .ot-enbl-chr li.ot-subgrp>h5+.ot-tgl-cntr{padding-right:25px}#onetrust-pc-sdk .ot-plus-minus{width:20px;height:20px;font-size:1.5em;position:relative;display:inline-block;margin-right:5px;top:3px}#onetrust-pc-sdk .ot-plus-minus span{position:absolute;background:#27455c;border-radius:1px}#onetrust-pc-sdk .ot-plus-minus span:first-of-type{top:25%;bottom:25%;width:10%;left:45%}#onetrust-pc-sdk .ot-plus-minus span:last-of-type{left:25%;right:25%;height:10%;top:45%}#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-plus-minus span:first-of-type,#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-plus-minus span:last-of-type{transform:rotate(90deg)}#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-plus-minus span:last-of-type{left:50%;right:50%}#onetrust-pc-sdk #ot-selall-vencntr label,#onetrust-pc-sdk #ot-selall-adtlvencntr label,#onetrust-pc-sdk #ot-selall-hostcntr label,#onetrust-pc-sdk #ot-selall-licntr label{position:relative;display:inline-block;width:20px;height:20px}#onetrust-pc-sdk .ot-host-item .ot-plus-minus,#onetrust-pc-sdk .ot-ven-item .ot-plus-minus{float:left;margin-right:8px;top:10px}#onetrust-pc-sdk .ot-pli-hdr{color:#77808e;overflow:hidden;padding-top:7.5px;padding-bottom:7.5px;width:calc(100% - 2px);border-top-left-radius:3px;border-top-right-radius:3px}#onetrust-pc-sdk .ot-pli-hdr span:first-child{top:50%;transform:translateY(50%);max-width:90px}#onetrust-pc-sdk .ot-pli-hdr span:last-child{padding-right:10px;max-width:95px;text-align:center}#onetrust-pc-sdk .ot-li-title{float:right;font-size:13px}#onetrust-pc-sdk .ot-pli-hdr.ot-leg-border-color{background-color:#f4f4f4;border:1px solid #d8d8d8}#onetrust-pc-sdk .ot-pli-hdr.ot-leg-border-color span:first-child{text-align:left;width:70px}#onetrust-pc-sdk li.ot-subgrp>h5,#onetrust-pc-sdk .ot-cat-header{width:calc(100% - 130px)}#onetrust-pc-sdk li.ot-subgrp>h5+.ot-tgl-cntr{padding-left:13px}#onetrust-pc-sdk .ot-acc-grpcntr .ot-acc-grpdesc{margin-bottom:5px}#onetrust-pc-sdk .ot-acc-grpcntr .ot-subgrp-cntr{border-top:1px solid #d8d8d8}#onetrust-pc-sdk .ot-acc-grpcntr .ot-vlst-cntr+.ot-subgrp-cntr{border-top:none}#onetrust-pc-sdk .ot-acc-hdr .ot-arw-cntr+.ot-tgl-cntr,#onetrust-pc-sdk .ot-acc-txt h4+.ot-tgl-cntr{padding-left:13px}#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item .ot-subgrp>h5,#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item .ot-cat-header{width:calc(100% - 145px)}#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item h5+.ot-tgl-cntr,#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item .ot-cat-header+.ot-tgl{padding-left:28px}#onetrust-pc-sdk .ot-sel-all-hdr,#onetrust-pc-sdk .ot-sel-all-chkbox{display:inline-block;width:100%;position:relative}#onetrust-pc-sdk .ot-sel-all-chkbox{z-index:1}#onetrust-pc-sdk .ot-sel-all{margin:0;position:relative;padding-right:23px;float:right}#onetrust-pc-sdk .ot-consent-hdr,#onetrust-pc-sdk .ot-li-hdr{float:right;font-size:.812em;line-height:normal;text-align:center;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-li-hdr{max-width:100px;padding-right:10px}#onetrust-pc-sdk .ot-consent-hdr{max-width:55px}#onetrust-pc-sdk #ot-selall-licntr{display:block;width:21px;height:auto;float:right;position:relative;right:80px}#onetrust-pc-sdk #ot-selall-licntr label{position:absolute}#onetrust-pc-sdk .ot-ven-ctgl{margin-left:66px}#onetrust-pc-sdk .ot-ven-litgl+.ot-arw-cntr{margin-left:81px}#onetrust-pc-sdk .ot-enbl-chr .ot-host-cnt .ot-tgl-cntr{width:auto}#onetrust-pc-sdk #ot-lst-cnt:not(.ot-host-cnt) .ot-tgl-cntr{width:auto;top:auto;height:20px}#onetrust-pc-sdk #ot-lst-cnt .ot-chkbox{position:relative;display:inline-block;width:20px;height:20px}#onetrust-pc-sdk #ot-lst-cnt .ot-chkbox label{position:absolute;padding:0;width:20px;height:20px}#onetrust-pc-sdk .ot-acc-grpdesc+.ot-leg-btn-container{padding-left:20px;padding-right:20px;width:calc(100% - 40px);margin-bottom:5px}#onetrust-pc-sdk .ot-subgrp .ot-leg-btn-container{margin-bottom:5px}#onetrust-pc-sdk #ot-ven-lst .ot-leg-btn-container{margin-top:10px}#onetrust-pc-sdk .ot-leg-btn-container{display:inline-block;width:100%;margin-bottom:10px}#onetrust-pc-sdk .ot-leg-btn-container button{height:32px;padding:6.5px 8px;margin-bottom:0;letter-spacing:0;font-size:.75em}#onetrust-pc-sdk .ot-leg-btn-container svg{display:none;height:14px;width:14px;padding-right:5px;vertical-align:sub}#onetrust-pc-sdk .ot-active-leg-btn{cursor:default;pointer-events:none}#onetrust-pc-sdk .ot-active-leg-btn svg{display:inline-block}#onetrust-pc-sdk .ot-remove-objection-handler{text-decoration:underline;padding:0;font-size:.75em;font-weight:600;line-height:1;padding-left:10px}#onetrust-pc-sdk .ot-obj-leg-btn-handler span{font-weight:bold;text-align:center;font-size:inherit;line-height:1.5}#onetrust-pc-sdk[dir=rtl] #ot-back-arw,#onetrust-pc-sdk[dir=rtl] input~.ot-acc-hdr .ot-arw{transform:rotate(180deg);-o-transform:rotate(180deg);-ms-transform:rotate(180deg);-webkit-transform:rotate(180deg)}#onetrust-pc-sdk[dir=rtl] input:checked~.ot-acc-hdr .ot-arw{transform:rotate(270deg);-o-transform:rotate(270deg);-ms-transform:rotate(270deg);-webkit-transform:rotate(270deg)}#onetrust-pc-sdk[dir=rtl] .ot-chkbox label::after{transform:rotate(45deg);-webkit-transform:rotate(45deg);-o-transform:rotate(45deg);-ms-transform:rotate(45deg);border-left:0;border-right:3px solid}#onetrust-pc-sdk[dir=rtl] .ot-search-cntr>svg{right:0}@media only screen and (max-width: 600px){#onetrust-pc-sdk.otPcCenter{left:0;min-width:100%;height:100%;top:0;border-radius:0}#onetrust-pc-sdk #ot-pc-content,#onetrust-pc-sdk.ot-ftr-stacked .ot-btn-container{margin:1px 3px 0 10px;padding-right:10px;width:calc(100% - 23px)}#onetrust-pc-sdk .ot-btn-container button{max-width:none;letter-spacing:.01em}#onetrust-pc-sdk #close-pc-btn-handler{top:10px;right:17px}#onetrust-pc-sdk p{font-size:.7em}#onetrust-pc-sdk #ot-pc-hdr{margin:10px 10px 0 5px;width:calc(100% - 15px)}#onetrust-pc-sdk .vendor-search-handler{font-size:1em}#onetrust-pc-sdk #ot-back-arw{margin-left:12px}#onetrust-pc-sdk #ot-lst-cnt{margin:0;padding:0 5px 0 10px;min-width:95%}#onetrust-pc-sdk .switch+p{max-width:80%}#onetrust-pc-sdk .ot-ftr-stacked button{width:100%}#onetrust-pc-sdk #ot-fltr-cnt{max-width:320px;width:90%;border-top-right-radius:0;border-bottom-right-radius:0;margin:0;margin-left:15px;left:auto;right:40px;top:85px}#onetrust-pc-sdk .ot-fltr-opt{margin-left:25px;margin-bottom:10px}#onetrust-pc-sdk .ot-pc-refuse-all-handler{margin-bottom:0}#onetrust-pc-sdk #ot-fltr-cnt{right:40px}}@media only screen and (max-width: 476px){#onetrust-pc-sdk .ot-fltr-cntr,#onetrust-pc-sdk #ot-fltr-cnt{right:10px}#onetrust-pc-sdk #ot-anchor{right:25px}#onetrust-pc-sdk button{width:100%}#onetrust-pc-sdk:not(.ot-addtl-vendors) #ot-pc-lst:not(.ot-enbl-chr) .ot-sel-all{padding-right:9px}#onetrust-pc-sdk:not(.ot-addtl-vendors) #ot-pc-lst:not(.ot-enbl-chr) .ot-tgl-cntr{right:0}}@media only screen and (max-width: 896px)and (max-height: 425px)and (orientation: landscape){#onetrust-pc-sdk.otPcCenter{left:0;top:0;min-width:100%;height:100%;border-radius:0}#onetrust-pc-sdk #ot-anchor{left:initial;right:50px}#onetrust-pc-sdk #ot-lst-title{margin-top:12px}#onetrust-pc-sdk #ot-lst-title *{font-size:inherit}#onetrust-pc-sdk #ot-pc-hdr input{margin-right:0;padding-right:45px}#onetrust-pc-sdk .switch+p{max-width:85%}#onetrust-pc-sdk #ot-sel-blk{position:static}#onetrust-pc-sdk #ot-pc-lst{overflow:auto}#onetrust-pc-sdk .ot-pc-footer-logo{display:none}#onetrust-pc-sdk #ot-lst-cnt{max-height:none;overflow:initial}#onetrust-pc-sdk #ot-lst-cnt.no-results{height:auto}#onetrust-pc-sdk input{font-size:1em !important}#onetrust-pc-sdk p{font-size:.6em}#onetrust-pc-sdk #ot-fltr-modal{width:100%;top:0}#onetrust-pc-sdk ul li p,#onetrust-pc-sdk .category-vendors-list-handler,#onetrust-pc-sdk .category-vendors-list-handler+a,#onetrust-pc-sdk .category-host-list-handler{font-size:.6em}#onetrust-pc-sdk.ot-shw-fltr #ot-anchor{display:none !important}#onetrust-pc-sdk.ot-shw-fltr #ot-pc-lst{height:100% !important;overflow:hidden;top:0px}#onetrust-pc-sdk.ot-shw-fltr #ot-fltr-cnt{margin:0;height:100%;max-height:none;padding:10px;top:0;width:calc(100% - 20px);position:absolute;right:0;left:0;max-width:none}#onetrust-pc-sdk.ot-shw-fltr .ot-fltr-scrlcnt{max-height:calc(100% - 65px)}}
            #onetrust-consent-sdk #onetrust-pc-sdk,
                #onetrust-consent-sdk #ot-search-cntr,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-switch.ot-toggle,
                #onetrust-consent-sdk #onetrust-pc-sdk ot-grp-hdr1 .checkbox,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-title:after
                ,#onetrust-consent-sdk #onetrust-pc-sdk #ot-sel-blk,
                        #onetrust-consent-sdk #onetrust-pc-sdk #ot-fltr-cnt,
                        #onetrust-consent-sdk #onetrust-pc-sdk #ot-anchor {
                    background-color: #f9fbf9;
                }
               
            #onetrust-consent-sdk #onetrust-pc-sdk h3,
                #onetrust-consent-sdk #onetrust-pc-sdk h4,
                #onetrust-consent-sdk #onetrust-pc-sdk h5,
                #onetrust-consent-sdk #onetrust-pc-sdk h6,
                #onetrust-consent-sdk #onetrust-pc-sdk p,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-ven-lst .ot-ven-opts p,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-desc,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-title,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-li-title,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-sel-all-hdr span,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-fltr-modal #modal-header,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-checkbox label span,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst #ot-sel-blk p,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst #ot-lst-title span,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst .back-btn-handler p,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst .ot-ven-name,
                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst #ot-ven-lst .consent-category,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-label-status,
                #onetrust-consent-sdk #onetrust-pc-sdk .ot-chkbox label span,
                #onetrust-consent-sdk #onetrust-pc-sdk #clear-filters-handler 
                {
                    color: #181616;
                }
             #onetrust-consent-sdk #onetrust-pc-sdk .privacy-notice-link,
                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler,
                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler + a,
                    #onetrust-consent-sdk #onetrust-pc-sdk .category-host-list-handler,
                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-ven-link,
                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-name a,
                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-acc-hdr .ot-host-expand,
                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info a
                    {
                        color: #181616;
                    }
             #onetrust-consent-sdk #onetrust-banner-sdk a[href],
                     #onetrust-consent-sdk #onetrust-banner-sdk .ot-link-btn
                        {
                            color: #f9fbf9;
                        }           
            #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler:hover { opacity: .7;}
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-acc-grpcntr.ot-acc-txt,
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-acc-txt .ot-subgrp-tgl .ot-switch.ot-toggle
             {
                background-color: #f9fbf9;
            }
            
             #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info,
                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-acc-txt .ot-ven-dets
                            {
                                background-color: #f9fbf9;
                            }
        #onetrust-consent-sdk #onetrust-pc-sdk 
            button:not(#clear-filters-handler):not(.ot-close-icon):not(#filter-btn-handler):not(.ot-remove-objection-handler):not(.ot-obj-leg-btn-handler):not([aria-expanded]):not(.ot-link-btn),
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-active-leg-btn {
                background-color: #05b974;border-color: #05b974;
                color: #FFFFFF;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-active-menu {
                border-color: #05b974;
            }
            
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-remove-objection-handler{
                background-color: transparent;
                border:1px solid transparent;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn {
                background-color: #FFFFFF;
                color: #78808E; border-color: #78808E;
            }
            .ot-sdk-cookie-policy{font-family:inherit;font-size:16px}.ot-sdk-cookie-policy h3,.ot-sdk-cookie-policy h4,.ot-sdk-cookie-policy h6,.ot-sdk-cookie-policy p,.ot-sdk-cookie-policy li,.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy th,.ot-sdk-cookie-policy #cookie-policy-description,.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}.ot-sdk-cookie-policy h4{font-size:1.2em}.ot-sdk-cookie-policy h6{font-size:1em;margin-top:2em}.ot-sdk-cookie-policy th{min-width:75px}.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy a:hover{background:#fff}.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}.ot-sdk-cookie-policy .ot-mobile-border{display:none}.ot-sdk-cookie-policy section{margin-bottom:2em}.ot-sdk-cookie-policy table{border-collapse:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy{font-family:inherit;font-size:16px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup{margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td{font-size:.9em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a{font-size:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group{font-size:1em;margin-bottom:.6em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title{margin-bottom:1.2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th{min-width:75px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover{background:#fff}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border{display:none}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section{margin-bottom:2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li{list-style:disc;margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4{display:inline-block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{border-collapse:inherit;margin:auto;border:1px solid #d7d7d7;border-radius:5px;border-spacing:initial;width:100%;overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border-bottom:1px solid #d7d7d7;border-right:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child{border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:25%}.ot-sdk-cookie-policy[dir=rtl]{text-align:left}#ot-sdk-cookie-policy h3{font-size:1.5em}@media only screen and (max-width: 530px){.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{display:block}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr{position:absolute;top:-9999px;left:-9999px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{margin:0 0 1em 0}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a{background:#f6f6f4}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td{border:none;border-bottom:1px solid #eee;position:relative;padding-left:50%}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{position:absolute;height:100%;left:6px;width:40%;padding-right:10px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border{display:inline-block;background-color:#e4e4e4;position:absolute;height:100%;top:0;left:45%;width:2px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{content:attr(data-label);font-weight:bold}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border:none;border-bottom:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{display:block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:auto}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{margin:0 0 1em 0}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{height:100%;width:40%;padding-right:10px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{content:attr(data-label);font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr{position:absolute;top:-9999px;left:-9999px;z-index:-9999}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:1px solid #d7d7d7;border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child{border-bottom:0px}}
                
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h5,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
                        color: #696969;
                    }
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
                        color: #696969;
                    }
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
                        color: #696969;
                    }
                    
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
                            color: #696969;
                        }
                    
            
                    #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th {
                            background-color: #F8F8F8;
                        }
                    
            


    
    

&lt;iframe src=&quot;//www.googletagmanager.com/ns.html?id=GTM-PLBRD26&quot; height=&quot;0&quot; width=&quot;0&quot; style=&quot;display:none;visibility:hidden&quot;>&lt;/iframe>


    
    


    

            
            
                
                Eroare
                Numele de utilizator sau adresa de e-mail exista deja, va rugam sa incercati altele.
            
        
    


    
    

    
                    







    
                    


                    
                /**/
.title h3 {
font-size:40px;
}

section.page nav ul {
    left: 0;
}
.page.choice .left header ul li {
  display: list-item;
  position: static;
  float: none;
  font-size: 16px;
  line-height: 1rem;
}
.page.choice p {
  font-size: 16px;
}
.page.choice .bottom {
  clear: both;
}

section.page ul li {
    display: list-item;
    float: inherit;
}

section.page nav ul li {
    display: inline;
    float: left;
}

.faulttree-container .step {
    list-style-type: inherit;
    display: inherit;
    margin-left: 0;
}

.left header .markdown-able {
    font-size: 22px;
    letter-spacing: 0px;
    margin-top:30px;
    text-align: inherit;
}

.left header .markdown-able ol {
    line-height: 16px;
    font-size: 16px;
}

.left header .markdown-able p {
   margin-bottom: 0;
}

.left header .markdown-able p + p {
   margin-top: 1.5rem;
}

.bottom footer {
    text-align: left;
    padding: 0 30px;
}

.goto + .goto button:not([data-page^=&quot;page-c24_other_issue&quot;]) {
    border: 2px solid red;
    color: red;
}

.faulttree-container .step .step {
  margin-left: 0;
}


 /* fix pentru mobile-view burger menu dublu */
    #main-nav > ul > li.show-md > div {
        display: none !important;
    }
    
    /*burger menu telefon */
    .flickity-prev-next-button {
        background-color: black !important;
        bottom: 4px !important;
        width: 2.5rem !important;
    }
    .flickity-prev-next-button.previous {
        box-shadow: 11px -13px 15px 0px rgba(0,0,0,0.75);
    }
    .flickity-prev-next-button.next {
        box-shadow: 11px 13px 15px 0px rgba(0,0,0,0.75)
    }
    
    @media (max-width: 960px) {
    #header #main-nav ul {
         width: 60%;
    }
    }
    
#onetrust-pc-sdk .category-host-list-handler {
text-decoration: underline;
}

#onetrust-pc-sdk #ot-pc-desc a {
margin-left: 0;
}
    

/* center images for mobile menu */
#sticky-filters {
    text-align: initial;
}
/* enable prev/next arrows */
.flickity-prev-next-button.previous {
    display: block !important;
    box-shadow: none;
}
.flickity-prev-next-button.next {
    display: block !important;
    box-shadow: none;
}
/* transparent background for arrows */
.flickity-prev-next-button {
    margin-right: -6px;
    margin-left: -6px;
    background-color: transparent !important; 
}

/* desktop menu fix */
#header #main-nav ul {
    font-size: .68rem;
    padding: 0.15rem .2rem;
    font-weight: 500;
}

#header #main-nav ul li {
    margin: 0;
}
@media (max-width: 1130px){
#header #main-nav ul li a {
    padding: 1.625rem .2rem;
    }
}

@media (min-width: 1280px){
#header #main-nav ul {
    font-size: .85rem;
    padding: 0.15rem .2rem;
    font-weight: normal;
    }
}

@media (max-width: 960px){
#header #main-nav ul {
    width: 60%;
    flex-direction: column;
    font-size: .9rem;
    margin: 0;
    padding: 0;
    list-style: none;
    height: 100%;
    display: flex;
    justify-content: center;
}
}

@media (max-width: 960px){
#header #main-nav ul li {
    padding: .5rem .5rem;
    margin: 0.40rem 0 0 0.20rem;
    margin-top: 0;
}
}

@media (max-width: 960px){
#header #main-nav ul li a {
    margin: 0;
    padding: .1rem 0;
    display: block;
    width: 80%;
    position: relative;
    letter-spacing: 0;
}
}

/* Checkout second step - Buttons */
.btn-back-icon {
    display: none;
}

.btn-consumer-info {
box-sizing: inherit !important;
font-family: inherit !important;
margin: 0 !important;
border: 0.05rem solid #111 !important;
border-radius: 0 !important;
cursor: pointer !important;
display: inline-block !important;
font-size: .6rem !important;
padding: 0.35rem 1.2rem !important;
text-transform: uppercase !important;
letter-spacing: .12rem !important;
font-weight: 700 !important;
height: 1.80rem !important;
line-height: 1rem !important;
outline: none !important;
text-align: center !important;
text-decoration: none !important;
user-select: none !important;
vertical-align: middle !important;
white-space: nowrap !important;
background: #111 !important;
border-color: #090909 !important;
color: #fff !important;
background-color: #333 !important;  
}

.btn-consumer-info:hover {
    background-color: #000 !important;
}




        
        
        
        DESPRE IQOS
        


                                
        
        
        
        DESPRE HEETS
        


                                
        
        
        
        SHOP
        


                                
        
        
        
        ȘTIINȚĂ
        


                                
        
        
        
        PĂRERI
        


                                
        
        
        
        SHOP
        


                    
.flickity-prev-next-button {
        display: none !important;
    }
    ._flickity-container {
        display: none !important;
    }


$(function(){
var allClosed = false;
$(&quot;#main-nav > ul > li&quot;).each(function(){
if($(this).hasClass(&quot;tapped&quot;)){ allClosed = true; }
});
if (!allClosed ){ $(&quot;#main-nav > ul > li&quot;).first().addClass(&quot;tapped&quot;);}
});

                            


    
        
        
        
        
    
        IQOS 3 DUO
    
        IQOS 3 MULTI
    
        IQOS 2.4+
    
        HEETS
    



            
            IQOS 3 DUO
        
            
            IQOS 3 MULTI
        
            
            IQOS 2.4+
        
            
            HEETS
        
    

                        
        
        
        
        ASISTENȚĂ
        


                                
        
        
        
        ASISTENȚĂ
        


                    
.flickity-prev-next-button {
        display: none !important;
    }
    ._flickity-container {
        display: none !important;
    }


$(function(){
var allClosed = false;
$(&quot;#main-nav > ul > li&quot;).each(function(){
if($(this).hasClass(&quot;tapped&quot;)){ allClosed = true; }
});
if (!allClosed ){ $(&quot;#main-nav > ul > li&quot;).first().addClass(&quot;tapped&quot;);}
});

                            


    
        
        
        
        
        
        
    
        IQOS 3 DUO
    
        IQOS 3
    
        IQOS 3 Multi
    
        IQOS 2.4+
    
        IQOS 2.4
    
        INLOCUIRE
    



            
            IQOS 3 DUO
        
            
            IQOS 3
        
            
            IQOS 3 Multi
        
            
            IQOS 2.4+
        
            
            IQOS 2.4
        
            
            INLOCUIRE
        
    

                        
        
        
        
        IQOS CONNECT
        


                    
                        
        
        
        
        PROMISIUNEA
        


                    
                        
        
        
        
        CLUB
        


                    
                        
        
        
        
        Contact
        


                    0800030333
                        
        
        
        
        GĂSEȘTE UN MAGAZIN
        


                    
                        
    



    
        
            
        
    
    


        
                    







    
        
    



    
                    


                    
                
    //&lt;![CDATA[
    (function(_, $) {
        let zipCodeInitializer = function () {
            
            $.ceRebuildStates('init', {
                default_country: 'RO',
                states: {&quot;&quot;:[{&quot;country_code&quot;:&quot;&quot;,&quot;code&quot;:&quot;CONSTANTA&quot;,&quot;state&quot;:null}],&quot;AU&quot;:[{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;ACT&quot;,&quot;state&quot;:&quot;Australian Capital Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NSW&quot;,&quot;state&quot;:&quot;New South Wales&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northern Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;QLD&quot;,&quot;state&quot;:&quot;Queensland&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;South Australia&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;TAS&quot;,&quot;state&quot;:&quot;Tasmania&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;VIC&quot;,&quot;state&quot;:&quot;Victoria&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Western Australia&quot;}],&quot;BG&quot;:[{&quot;country_code&quot;:&quot;BG&quot;,&quot;code&quot;:&quot;SF&quot;,&quot;state&quot;:&quot;Sofia&quot;}],&quot;CA&quot;:[{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Alberta&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;British Columbia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;MB&quot;,&quot;state&quot;:&quot;Manitoba&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;New Brunswick&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NL&quot;,&quot;state&quot;:&quot;Newfoundland and Labrador&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northwest Territories&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NS&quot;,&quot;state&quot;:&quot;Nova Scotia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nunavut&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;ON&quot;,&quot;state&quot;:&quot;Ontario&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Prince Edward Island&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;QC&quot;,&quot;state&quot;:&quot;Quebec&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;SK&quot;,&quot;state&quot;:&quot;Saskatchewan&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;YT&quot;,&quot;state&quot;:&quot;Yukon&quot;}],&quot;CH&quot;:[{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Ext\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AI&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Int\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Argovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;B\u00e2le-Campagne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;B\u00e2le-Ville&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BE&quot;,&quot;state&quot;:&quot;Berne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Fribourg&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gen\u00e8ve&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;Glaris&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grisons&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;JU&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucerne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Neuch\u00e2tel&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NW&quot;,&quot;state&quot;:&quot;Nidwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;OW&quot;,&quot;state&quot;:&quot;Obwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Saint-Gall&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SH&quot;,&quot;state&quot;:&quot;Schaffhouse&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SZ&quot;,&quot;state&quot;:&quot;Schwytz&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soleure&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TI&quot;,&quot;state&quot;:&quot;Tessin&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TG&quot;,&quot;state&quot;:&quot;Thurgovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;UR&quot;,&quot;state&quot;:&quot;Uri&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Valais&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VD&quot;,&quot;state&quot;:&quot;Vaud&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZG&quot;,&quot;state&quot;:&quot;Zoug&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zurich&quot;}],&quot;DE&quot;:[{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAW&quot;,&quot;state&quot;:&quot;Baden-W\u00fcrttemberg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAY&quot;,&quot;state&quot;:&quot;Bayern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BER&quot;,&quot;state&quot;:&quot;Berlin&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRG&quot;,&quot;state&quot;:&quot;Branderburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRE&quot;,&quot;state&quot;:&quot;Bremen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HAM&quot;,&quot;state&quot;:&quot;Hamburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HES&quot;,&quot;state&quot;:&quot;Hessen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;MEC&quot;,&quot;state&quot;:&quot;Mecklenburg-Vorpommern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NDS&quot;,&quot;state&quot;:&quot;Niedersachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NRW&quot;,&quot;state&quot;:&quot;Nordrhein-Westfalen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;RHE&quot;,&quot;state&quot;:&quot;Rheinland-Pfalz&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saarland&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAS&quot;,&quot;state&quot;:&quot;Sachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAC&quot;,&quot;state&quot;:&quot;Sachsen-Anhalt&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SCN&quot;,&quot;state&quot;:&quot;Schleswig-Holstein&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;THE&quot;,&quot;state&quot;:&quot;Th\u00fcringen&quot;}],&quot;ES&quot;:[{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;C&quot;,&quot;state&quot;:&quot;A Coru\u00f1a&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;\u00c1lava&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Albacete&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;A&quot;,&quot;state&quot;:&quot;Alicante&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Almer\u00eda&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;O&quot;,&quot;state&quot;:&quot;Asturias&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;\u00c1vila&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Badajoz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PM&quot;,&quot;state&quot;:&quot;Baleares&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;Barcelona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Burgos&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CC&quot;,&quot;state&quot;:&quot;C\u00e1ceres&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;C\u00e1diz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;S&quot;,&quot;state&quot;:&quot;Cantabria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Castell\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Ceuta&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Ciudad Real&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;C\u00f3rdoba&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Cuenca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GI&quot;,&quot;state&quot;:&quot;Girona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Granada&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guadalajara&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Guip\u00fazcoa&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;H&quot;,&quot;state&quot;:&quot;Huelva&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;HU&quot;,&quot;state&quot;:&quot;Huesca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;J&quot;,&quot;state&quot;:&quot;Ja\u00e9n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;La Rioja&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GC&quot;,&quot;state&quot;:&quot;Las Palmas&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Le\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;L&quot;,&quot;state&quot;:&quot;Lleida&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lugo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;M&quot;,&quot;state&quot;:&quot;Madrid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;M\u00e1laga&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ML&quot;,&quot;state&quot;:&quot;Melilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MU&quot;,&quot;state&quot;:&quot;Murcia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Navarra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Ourense&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;P&quot;,&quot;state&quot;:&quot;Palencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Pontevedra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salamanca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TF&quot;,&quot;state&quot;:&quot;Santa Cruz de Tenerife&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Segovia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Sevilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;T&quot;,&quot;state&quot;:&quot;Tarragona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teruel&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Toledo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;V&quot;,&quot;state&quot;:&quot;Valencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Valladolid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Vizcaya&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ZA&quot;,&quot;state&quot;:&quot;Zamora&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;Z&quot;,&quot;state&quot;:&quot;Zaragoza&quot;}],&quot;FR&quot;:[{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;01&quot;,&quot;state&quot;:&quot;Ain&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;02&quot;,&quot;state&quot;:&quot;Aisne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;03&quot;,&quot;state&quot;:&quot;Allier&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;04&quot;,&quot;state&quot;:&quot;Alpes-de-Haute-Provence&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;06&quot;,&quot;state&quot;:&quot;Alpes-Maritimes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;07&quot;,&quot;state&quot;:&quot;Ard\u00e8che&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;08&quot;,&quot;state&quot;:&quot;Ardennes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;09&quot;,&quot;state&quot;:&quot;Ari\u00e8ge&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;10&quot;,&quot;state&quot;:&quot;Aube&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;11&quot;,&quot;state&quot;:&quot;Aude&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;12&quot;,&quot;state&quot;:&quot;Aveyron&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;67&quot;,&quot;state&quot;:&quot;Bas-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;13&quot;,&quot;state&quot;:&quot;Bouches-du-Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;14&quot;,&quot;state&quot;:&quot;Calvados&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;15&quot;,&quot;state&quot;:&quot;Cantal&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;16&quot;,&quot;state&quot;:&quot;Charente&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;17&quot;,&quot;state&quot;:&quot;Charente-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;18&quot;,&quot;state&quot;:&quot;Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;19&quot;,&quot;state&quot;:&quot;Corr\u00e8ze&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2A&quot;,&quot;state&quot;:&quot;Corse-du-Sud&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;21&quot;,&quot;state&quot;:&quot;C\u00f4te-d'Or&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;22&quot;,&quot;state&quot;:&quot;C\u00f4tes-d'Armor&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;23&quot;,&quot;state&quot;:&quot;Creuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;79&quot;,&quot;state&quot;:&quot;Deux-S\u00e8vres&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;24&quot;,&quot;state&quot;:&quot;Dordogne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;25&quot;,&quot;state&quot;:&quot;Doubs&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;26&quot;,&quot;state&quot;:&quot;Dr\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;91&quot;,&quot;state&quot;:&quot;Essonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;27&quot;,&quot;state&quot;:&quot;Eure&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;28&quot;,&quot;state&quot;:&quot;Eure-et-Loir&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;29&quot;,&quot;state&quot;:&quot;Finist\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;30&quot;,&quot;state&quot;:&quot;Gard&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;32&quot;,&quot;state&quot;:&quot;Gers&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;33&quot;,&quot;state&quot;:&quot;Gironde&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;68&quot;,&quot;state&quot;:&quot;Haut-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2B&quot;,&quot;state&quot;:&quot;Haute-Corse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;31&quot;,&quot;state&quot;:&quot;Haute-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;43&quot;,&quot;state&quot;:&quot;Haute-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;52&quot;,&quot;state&quot;:&quot;Haute-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;70&quot;,&quot;state&quot;:&quot;Haute-Sa\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;74&quot;,&quot;state&quot;:&quot;Haute-Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;87&quot;,&quot;state&quot;:&quot;Haute-Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;05&quot;,&quot;state&quot;:&quot;Hautes-Alpes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;65&quot;,&quot;state&quot;:&quot;Hautes-Pyr\u00e9n\u00e9es&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;92&quot;,&quot;state&quot;:&quot;Hauts-de-Seine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;34&quot;,&quot;state&quot;:&quot;H\u00e9rault&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;35&quot;,&quot;state&quot;:&quot;Ille-et-Vilaine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;36&quot;,&quot;state&quot;:&quot;Indre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;37&quot;,&quot;state&quot;:&quot;Indre-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;38&quot;,&quot;state&quot;:&quot;Is\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;39&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;40&quot;,&quot;state&quot;:&quot;Landes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;41&quot;,&quot;state&quot;:&quot;Loir-et-Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;42&quot;,&quot;state&quot;:&quot;Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;44&quot;,&quot;state&quot;:&quot;Loire-Atlantique&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;45&quot;,&quot;state&quot;:&quot;Loiret&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;46&quot;,&quot;state&quot;:&quot;Lot&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;47&quot;,&quot;state&quot;:&quot;Lot-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;48&quot;,&quot;state&quot;:&quot;Loz\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;49&quot;,&quot;state&quot;:&quot;Maine-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;50&quot;,&quot;state&quot;:&quot;Manche&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;51&quot;,&quot;state&quot;:&quot;Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;53&quot;,&quot;state&quot;:&quot;Mayenne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;54&quot;,&quot;state&quot;:&quot;Meurthe-et-Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;55&quot;,&quot;state&quot;:&quot;Meuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;56&quot;,&quot;state&quot;:&quot;Morbihan&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;57&quot;,&quot;state&quot;:&quot;Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;58&quot;,&quot;state&quot;:&quot;Ni\u00e8vre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;59&quot;,&quot;state&quot;:&quot;Nord&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;60&quot;,&quot;state&quot;:&quot;Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;61&quot;,&quot;state&quot;:&quot;Orne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;75&quot;,&quot;state&quot;:&quot;Paris&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;62&quot;,&quot;state&quot;:&quot;Pas-de-Calais&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;63&quot;,&quot;state&quot;:&quot;Puy-de-D\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;64&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Atlantiques&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;66&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Orientales&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;69&quot;,&quot;state&quot;:&quot;Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;71&quot;,&quot;state&quot;:&quot;Sa\u00f4ne-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;72&quot;,&quot;state&quot;:&quot;Sarthe&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;73&quot;,&quot;state&quot;:&quot;Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;77&quot;,&quot;state&quot;:&quot;Seine-et-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;76&quot;,&quot;state&quot;:&quot;Seine-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;93&quot;,&quot;state&quot;:&quot;Seine-Saint-Denis&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;80&quot;,&quot;state&quot;:&quot;Somme&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;81&quot;,&quot;state&quot;:&quot;Tarn&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;82&quot;,&quot;state&quot;:&quot;Tarn-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;90&quot;,&quot;state&quot;:&quot;Territoire de Belfort&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;95&quot;,&quot;state&quot;:&quot;Val-d'Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;94&quot;,&quot;state&quot;:&quot;Val-de-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;83&quot;,&quot;state&quot;:&quot;Var&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;84&quot;,&quot;state&quot;:&quot;Vaucluse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;85&quot;,&quot;state&quot;:&quot;Vend\u00e9e&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;86&quot;,&quot;state&quot;:&quot;Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;88&quot;,&quot;state&quot;:&quot;Vosges&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;89&quot;,&quot;state&quot;:&quot;Yonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;78&quot;,&quot;state&quot;:&quot;Yvelines&quot;}],&quot;GB&quot;:[{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABN&quot;,&quot;state&quot;:&quot;Aberdeen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABNS&quot;,&quot;state&quot;:&quot;Aberdeenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANG&quot;,&quot;state&quot;:&quot;Anglesey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AGS&quot;,&quot;state&quot;:&quot;Angus&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARY&quot;,&quot;state&quot;:&quot;Argyll and Bute&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AVN&quot;,&quot;state&quot;:&quot;Avon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BAN&quot;,&quot;state&quot;:&quot;Banffshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEDS&quot;,&quot;state&quot;:&quot;Bedfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BERKS&quot;,&quot;state&quot;:&quot;Berkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEW&quot;,&quot;state&quot;:&quot;Berwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BLA&quot;,&quot;state&quot;:&quot;Blaenau Gwent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BRI&quot;,&quot;state&quot;:&quot;Bridgend&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BSTL&quot;,&quot;state&quot;:&quot;Bristol&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BUCKS&quot;,&quot;state&quot;:&quot;Buckinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAE&quot;,&quot;state&quot;:&quot;Caerphilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAI&quot;,&quot;state&quot;:&quot;Caithness&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAMBS&quot;,&quot;state&quot;:&quot;Cambridgeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDF&quot;,&quot;state&quot;:&quot;Cardiff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CARM&quot;,&quot;state&quot;:&quot;Carmarthenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDGN&quot;,&quot;state&quot;:&quot;Ceredigion&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CHES&quot;,&quot;state&quot;:&quot;Cheshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLACK&quot;,&quot;state&quot;:&quot;Clackmannanshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLV&quot;,&quot;state&quot;:&quot;Cleveland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CWD&quot;,&quot;state&quot;:&quot;Clwyd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CON&quot;,&quot;state&quot;:&quot;Conwy&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CORN&quot;,&quot;state&quot;:&quot;Cornwall&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANT&quot;,&quot;state&quot;:&quot;County Antrim&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARM&quot;,&quot;state&quot;:&quot;County Armagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOW&quot;,&quot;state&quot;:&quot;County Down&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FER&quot;,&quot;state&quot;:&quot;County Fermanagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDY&quot;,&quot;state&quot;:&quot;County Londonderry&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TYR&quot;,&quot;state&quot;:&quot;County Tyrone&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CMA&quot;,&quot;state&quot;:&quot;Cumbria&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DNBG&quot;,&quot;state&quot;:&quot;Denbighshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DERBY&quot;,&quot;state&quot;:&quot;Derbyshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DVN&quot;,&quot;state&quot;:&quot;Devon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOR&quot;,&quot;state&quot;:&quot;Dorset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DGL&quot;,&quot;state&quot;:&quot;Dumfries and Galloway&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFS&quot;,&quot;state&quot;:&quot;Dumfries-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUND&quot;,&quot;state&quot;:&quot;Dundee&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DHM&quot;,&quot;state&quot;:&quot;Durham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFD&quot;,&quot;state&quot;:&quot;Dyfed&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYE&quot;,&quot;state&quot;:&quot;East Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUNBE&quot;,&quot;state&quot;:&quot;East Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LOTE&quot;,&quot;state&quot;:&quot;East Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RENE&quot;,&quot;state&quot;:&quot;East Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ERYS&quot;,&quot;state&quot;:&quot;East Riding of Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXE&quot;,&quot;state&quot;:&quot;East Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;EDIN&quot;,&quot;state&quot;:&quot;Edinburgh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ESX&quot;,&quot;state&quot;:&quot;Essex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FALK&quot;,&quot;state&quot;:&quot;Falkirk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FFE&quot;,&quot;state&quot;:&quot;Fife&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FLINT&quot;,&quot;state&quot;:&quot;Flintshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLAS&quot;,&quot;state&quot;:&quot;Glasgow&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLOS&quot;,&quot;state&quot;:&quot;Gloucestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDN&quot;,&quot;state&quot;:&quot;Greater London&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MCH&quot;,&quot;state&quot;:&quot;Greater Manchester&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GDD&quot;,&quot;state&quot;:&quot;Gwynedd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HANTS&quot;,&quot;state&quot;:&quot;Hampshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HWR&quot;,&quot;state&quot;:&quot;Herefordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HERTS&quot;,&quot;state&quot;:&quot;Hertfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HLD&quot;,&quot;state&quot;:&quot;Highlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HUM&quot;,&quot;state&quot;:&quot;Humberside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IVER&quot;,&quot;state&quot;:&quot;Inverclyde&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;INV&quot;,&quot;state&quot;:&quot;Inverness-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOW&quot;,&quot;state&quot;:&quot;Isle of Wight&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOS&quot;,&quot;state&quot;:&quot;Isles of Scilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KNT&quot;,&quot;state&quot;:&quot;Kent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KCD&quot;,&quot;state&quot;:&quot;Kincardineshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANCS&quot;,&quot;state&quot;:&quot;Lancashire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LEICS&quot;,&quot;state&quot;:&quot;Leicestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LINCS&quot;,&quot;state&quot;:&quot;Lincolnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MER&quot;,&quot;state&quot;:&quot;Merionethshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MSY&quot;,&quot;state&quot;:&quot;Merseyside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MERT&quot;,&quot;state&quot;:&quot;Merthyr Tydfil&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MDX&quot;,&quot;state&quot;:&quot;Middlesex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MLOT&quot;,&quot;state&quot;:&quot;Midlothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MMOUTH&quot;,&quot;state&quot;:&quot;Monmouthshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MORAY&quot;,&quot;state&quot;:&quot;Moray&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NAI&quot;,&quot;state&quot;:&quot;Nairnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NPRTAL&quot;,&quot;state&quot;:&quot;Neath Port Talbot&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NEWPT&quot;,&quot;state&quot;:&quot;Newport&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOR&quot;,&quot;state&quot;:&quot;Norfolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYN&quot;,&quot;state&quot;:&quot;North Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANN&quot;,&quot;state&quot;:&quot;North Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSN&quot;,&quot;state&quot;:&quot;North Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NHM&quot;,&quot;state&quot;:&quot;Northamptonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NLD&quot;,&quot;state&quot;:&quot;Northumberland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOT&quot;,&quot;state&quot;:&quot;Nottinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ORK&quot;,&quot;state&quot;:&quot;Orkney Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;OFE&quot;,&quot;state&quot;:&quot;Oxfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEE&quot;,&quot;state&quot;:&quot;Peebles-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEM&quot;,&quot;state&quot;:&quot;Pembrokeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PERTH&quot;,&quot;state&quot;:&quot;Perth and Kinross&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PWS&quot;,&quot;state&quot;:&quot;Powys&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;REN&quot;,&quot;state&quot;:&quot;Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RHON&quot;,&quot;state&quot;:&quot;Rhondda Cynon Taff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ROX&quot;,&quot;state&quot;:&quot;Roxburghshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RUT&quot;,&quot;state&quot;:&quot;Rutland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BOR&quot;,&quot;state&quot;:&quot;Scottish Borders&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SEL&quot;,&quot;state&quot;:&quot;Selkirkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SHET&quot;,&quot;state&quot;:&quot;Shetland Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Shropshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SOM&quot;,&quot;state&quot;:&quot;Somerset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYS&quot;,&quot;state&quot;:&quot;South Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANS&quot;,&quot;state&quot;:&quot;South Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SYK&quot;,&quot;state&quot;:&quot;South Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFD&quot;,&quot;state&quot;:&quot;Staffordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STIR&quot;,&quot;state&quot;:&quot;Stirling&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STI&quot;,&quot;state&quot;:&quot;Stirlingshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFK&quot;,&quot;state&quot;:&quot;Suffolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SRY&quot;,&quot;state&quot;:&quot;Surrey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SUT&quot;,&quot;state&quot;:&quot;Sutherland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SWAN&quot;,&quot;state&quot;:&quot;Swansea&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TORF&quot;,&quot;state&quot;:&quot;Torfaen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TWR&quot;,&quot;state&quot;:&quot;Tyne and Wear&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;VGLAM&quot;,&quot;state&quot;:&quot;Vale of Glamorgan&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WARKS&quot;,&quot;state&quot;:&quot;Warwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WDUN&quot;,&quot;state&quot;:&quot;West Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLOT&quot;,&quot;state&quot;:&quot;West Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WMD&quot;,&quot;state&quot;:&quot;West Midlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXW&quot;,&quot;state&quot;:&quot;West Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSW&quot;,&quot;state&quot;:&quot;West Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIL&quot;,&quot;state&quot;:&quot;Western Isles&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIG&quot;,&quot;state&quot;:&quot;Wigtownshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLT&quot;,&quot;state&quot;:&quot;Wiltshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WORCS&quot;,&quot;state&quot;:&quot;Worcestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WRX&quot;,&quot;state&quot;:&quot;Wrexham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YKS&quot;,&quot;state&quot;:&quot;Yorkshire&quot;}],&quot;IT&quot;:[{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Agrigento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alessandria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AN&quot;,&quot;state&quot;:&quot;Ancona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AO&quot;,&quot;state&quot;:&quot;Aosta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arezzo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AP&quot;,&quot;state&quot;:&quot;Ascoli Piceno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AT&quot;,&quot;state&quot;:&quot;Asti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;Avellino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Bari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;Belluno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;Benevento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BG&quot;,&quot;state&quot;:&quot;Bergamo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Biella&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BO&quot;,&quot;state&quot;:&quot;Bologna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;Bolzano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;Brescia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;Brindisi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;Cagliari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;Caltanissetta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CB&quot;,&quot;state&quot;:&quot;Campobasso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CI&quot;,&quot;state&quot;:&quot;Carbonia-Iglesias&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Caserta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Catania&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CZ&quot;,&quot;state&quot;:&quot;Catanzaro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CH&quot;,&quot;state&quot;:&quot;Chieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Como&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Cosenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Cremona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Crotone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CN&quot;,&quot;state&quot;:&quot;Cuneo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;EN&quot;,&quot;state&quot;:&quot;Enna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FE&quot;,&quot;state&quot;:&quot;Ferrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FI&quot;,&quot;state&quot;:&quot;Firenze&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FG&quot;,&quot;state&quot;:&quot;Foggia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FC&quot;,&quot;state&quot;:&quot;Forli-Cesena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Frosinone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Genova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GO&quot;,&quot;state&quot;:&quot;Gorizia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grosseto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IM&quot;,&quot;state&quot;:&quot;Imperia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;Isernia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AQ&quot;,&quot;state&quot;:&quot;L'Aquila&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SP&quot;,&quot;state&quot;:&quot;La Spezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LT&quot;,&quot;state&quot;:&quot;Latina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Lecce&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LC&quot;,&quot;state&quot;:&quot;Lecco&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Livorno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;Lodi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucca&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MC&quot;,&quot;state&quot;:&quot;Macerata&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Mantova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Massa-Carrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Matera&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Medio Campidano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Messina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Milano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Modena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Napoli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NO&quot;,&quot;state&quot;:&quot;Novara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nuoro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OG&quot;,&quot;state&quot;:&quot;Ogliastra&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;Olbia-Tempio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oristano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PD&quot;,&quot;state&quot;:&quot;Padova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Palermo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Parma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PV&quot;,&quot;state&quot;:&quot;Pavia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PG&quot;,&quot;state&quot;:&quot;Perugia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PU&quot;,&quot;state&quot;:&quot;Pesaro e Urbino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Pescara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PC&quot;,&quot;state&quot;:&quot;Piacenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PI&quot;,&quot;state&quot;:&quot;Pisa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PT&quot;,&quot;state&quot;:&quot;Pistoia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PN&quot;,&quot;state&quot;:&quot;Pordenone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PZ&quot;,&quot;state&quot;:&quot;Potenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Prato&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RG&quot;,&quot;state&quot;:&quot;Ragusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RA&quot;,&quot;state&quot;:&quot;Ravenna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RC&quot;,&quot;state&quot;:&quot;Reggio Calabria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RE&quot;,&quot;state&quot;:&quot;Reggio Emilia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RN&quot;,&quot;state&quot;:&quot;Rimini&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RM&quot;,&quot;state&quot;:&quot;Roma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RO&quot;,&quot;state&quot;:&quot;Rovigo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salerno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Sassari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;Savona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SI&quot;,&quot;state&quot;:&quot;Siena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SR&quot;,&quot;state&quot;:&quot;Siracusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Sondrio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Taranto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teramo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;Terni&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Torino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TP&quot;,&quot;state&quot;:&quot;Trapani&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Trento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TV&quot;,&quot;state&quot;:&quot;Treviso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TS&quot;,&quot;state&quot;:&quot;Trieste&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udine&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Varese&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VE&quot;,&quot;state&quot;:&quot;Venezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VB&quot;,&quot;state&quot;:&quot;Verbano-Cusio-Ossola&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VC&quot;,&quot;state&quot;:&quot;Vercelli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VR&quot;,&quot;state&quot;:&quot;Verona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VV&quot;,&quot;state&quot;:&quot;Vibo Valentia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Vicenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Viterbo&quot;}],&quot;JP&quot;:[{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AICHI&quot;,&quot;state&quot;:&quot;AICHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AKITA&quot;,&quot;state&quot;:&quot;AKITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AOMORI&quot;,&quot;state&quot;:&quot;AOMORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;CHIBA&quot;,&quot;state&quot;:&quot;CHIBA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;EHIME&quot;,&quot;state&quot;:&quot;EHIME&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUI&quot;,&quot;state&quot;:&quot;FUKUI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUOKA&quot;,&quot;state&quot;:&quot;FUKUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUSHIMA&quot;,&quot;state&quot;:&quot;FUKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GIFU&quot;,&quot;state&quot;:&quot;GIFU&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GUMMA&quot;,&quot;state&quot;:&quot;GUMMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HIROSHIMA&quot;,&quot;state&quot;:&quot;HIROSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HOKKAIDO&quot;,&quot;state&quot;:&quot;HOKKAIDO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HYOGO&quot;,&quot;state&quot;:&quot;HYOGO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IBARAKI&quot;,&quot;state&quot;:&quot;IBARAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;ISHIKAWA&quot;,&quot;state&quot;:&quot;ISHIKAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IWATE&quot;,&quot;state&quot;:&quot;IWATE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGAWA&quot;,&quot;state&quot;:&quot;KAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGOSHIMA&quot;,&quot;state&quot;:&quot;KAGOSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KANAGAWA&quot;,&quot;state&quot;:&quot;KANAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KOCHI&quot;,&quot;state&quot;:&quot;KOCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KUMAMOTO&quot;,&quot;state&quot;:&quot;KUMAMOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KYOTO&quot;,&quot;state&quot;:&quot;KYOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIE&quot;,&quot;state&quot;:&quot;MIE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAGI&quot;,&quot;state&quot;:&quot;MIYAGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAZAKI&quot;,&quot;state&quot;:&quot;MIYAZAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGANO&quot;,&quot;state&quot;:&quot;NAGANO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGASAKI&quot;,&quot;state&quot;:&quot;NAGASAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NARA&quot;,&quot;state&quot;:&quot;NARA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NIIGATA&quot;,&quot;state&quot;:&quot;NIIGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OITA&quot;,&quot;state&quot;:&quot;OITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKAYAMA&quot;,&quot;state&quot;:&quot;OKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKINAWA&quot;,&quot;state&quot;:&quot;OKINAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OSAKA&quot;,&quot;state&quot;:&quot;OSAKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAGA&quot;,&quot;state&quot;:&quot;SAGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAITAMA&quot;,&quot;state&quot;:&quot;SAITAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIGA&quot;,&quot;state&quot;:&quot;SHIGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIMANE&quot;,&quot;state&quot;:&quot;SHIMANE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIZUOKA&quot;,&quot;state&quot;:&quot;SHIZUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOCHIGI&quot;,&quot;state&quot;:&quot;TOCHIGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKUSHIMA&quot;,&quot;state&quot;:&quot;TOKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKYO&quot;,&quot;state&quot;:&quot;TOKYO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOTTORI&quot;,&quot;state&quot;:&quot;TOTTORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOYAMA&quot;,&quot;state&quot;:&quot;TOYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;WAKAYAMA&quot;,&quot;state&quot;:&quot;WAKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGATA&quot;,&quot;state&quot;:&quot;YAMAGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGUCHI&quot;,&quot;state&quot;:&quot;YAMAGUCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMANASHI&quot;,&quot;state&quot;:&quot;YAMANASHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4e09\u91cd\u770c&quot;,&quot;state&quot;:&quot;\u4e09\u91cd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4eac\u90fd\u5e9c&quot;,&quot;state&quot;:&quot;\u4eac\u90fd\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4f50\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u4f50\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5175\u5eab\u770c&quot;,&quot;state&quot;:&quot;\u5175\u5eab\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5317\u6d77\u9053&quot;,&quot;state&quot;:&quot;\u5317\u6d77\u9053&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5343\u8449\u770c&quot;,&quot;state&quot;:&quot;\u5343\u8449\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u57fc\u7389\u770c&quot;,&quot;state&quot;:&quot;\u57fc\u7389\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u5206\u770c&quot;,&quot;state&quot;:&quot;\u5927\u5206\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u962a\u5e9c&quot;,&quot;state&quot;:&quot;\u5927\u962a\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5948\u826f\u770c&quot;,&quot;state&quot;:&quot;\u5948\u826f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bcc\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5bcc\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u53e3\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u53e3\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u5f62\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u5f62\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u68a8\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u68a8\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c90\u961c\u770c&quot;,&quot;state&quot;:&quot;\u5c90\u961c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca1\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5ca1\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca9\u624b\u770c&quot;,&quot;state&quot;:&quot;\u5ca9\u624b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5cf6\u6839\u770c&quot;,&quot;state&quot;:&quot;\u5cf6\u6839\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5e83\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5e83\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5fb3\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5fb3\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u5a9b\u770c&quot;,&quot;state&quot;:&quot;\u611b\u5a9b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u611b\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u65b0\u6f5f\u770c&quot;,&quot;state&quot;:&quot;\u65b0\u6f5f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6771\u4eac\u90fd&quot;,&quot;state&quot;:&quot;\u6771\u4eac\u90fd&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6803\u6728\u770c&quot;,&quot;state&quot;:&quot;\u6803\u6728\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6c96\u7e04\u770c&quot;,&quot;state&quot;:&quot;\u6c96\u7e04\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6ecb\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u6ecb\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u718a\u672c\u770c&quot;,&quot;state&quot;:&quot;\u718a\u672c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u77f3\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u77f3\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u4e95\u770c&quot;,&quot;state&quot;:&quot;\u798f\u4e95\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u79cb\u7530\u770c&quot;,&quot;state&quot;:&quot;\u79cb\u7530\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u7fa4\u99ac\u770c&quot;,&quot;state&quot;:&quot;\u7fa4\u99ac\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u8328\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u8328\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u9577\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u91ce\u770c&quot;,&quot;state&quot;:&quot;\u9577\u91ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9752\u68ee\u770c&quot;,&quot;state&quot;:&quot;\u9752\u68ee\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9759\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u9759\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9999\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u9999\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ad8\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u9ad8\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ce5\u53d6\u770c&quot;,&quot;state&quot;:&quot;\u9ce5\u53d6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;}],&quot;NL&quot;:[{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;DR&quot;,&quot;state&quot;:&quot;Drenthe&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Flevoland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Friesland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gelderland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Groningen&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Limburg&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;Noord Brabant&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;Noord Holland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;OV&quot;,&quot;state&quot;:&quot;Overijssel&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utrecht&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZE&quot;,&quot;state&quot;:&quot;Zeeland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zuid Holland&quot;}],&quot;RO&quot;:[{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;ALBA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;ARAD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;ARGES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;BACAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BH&quot;,&quot;state&quot;:&quot;BIHOR&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;BISTRITA-NASAUD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BT&quot;,&quot;state&quot;:&quot;BOTOSANI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;BRAILA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BV&quot;,&quot;state&quot;:&quot;BRASOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;BUCURESTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;BUZAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;CALARASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;CARAS-SEVERIN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CJ&quot;,&quot;state&quot;:&quot;CLUJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CV&quot;,&quot;state&quot;:&quot;COVASNA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DB&quot;,&quot;state&quot;:&quot;DAMBOVITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DJ&quot;,&quot;state&quot;:&quot;DOLJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;GALATI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;GIURGIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GJ&quot;,&quot;state&quot;:&quot;GORJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HR&quot;,&quot;state&quot;:&quot;HARGHITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HD&quot;,&quot;state&quot;:&quot;HUNEDOARA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;IALOMITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;IASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IF&quot;,&quot;state&quot;:&quot;ILFOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MM&quot;,&quot;state&quot;:&quot;MARAMURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MH&quot;,&quot;state&quot;:&quot;MEHEDINTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;MURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;NEAMT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;OLT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;PH&quot;,&quot;state&quot;:&quot;PRAHOVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SJ&quot;,&quot;state&quot;:&quot;SALAJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SM&quot;,&quot;state&quot;:&quot;SATU MARE&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SB&quot;,&quot;state&quot;:&quot;SIBIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;SUCEAVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;TELEORMAN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TM&quot;,&quot;state&quot;:&quot;TIMIS&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TL&quot;,&quot;state&quot;:&quot;TULCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VL&quot;,&quot;state&quot;:&quot;VALCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;VASLUI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VN&quot;,&quot;state&quot;:&quot;VRANCEA&quot;}],&quot;RU&quot;:[{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ALT&quot;,&quot;state&quot;:&quot;Altajskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AMU&quot;,&quot;state&quot;:&quot;Amurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ARK&quot;,&quot;state&quot;:&quot;Arhangel'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AST&quot;,&quot;state&quot;:&quot;Astrahanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BEL&quot;,&quot;state&quot;:&quot;Belgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BRY&quot;,&quot;state&quot;:&quot;Brjanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Chechenskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHE&quot;,&quot;state&quot;:&quot;Cheljabinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHU&quot;,&quot;state&quot;:&quot;Chukotskij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Chuvashskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YEV&quot;,&quot;state&quot;:&quot;Evrejskaja avtonomnaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHA&quot;,&quot;state&quot;:&quot;Habarovskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHM&quot;,&quot;state&quot;:&quot;Hanty-Mansijskij avtonomnyj okrug - Jugra&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IRK&quot;,&quot;state&quot;:&quot;Irkutskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IVA&quot;,&quot;state&quot;:&quot;Ivanovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAN&quot;,&quot;state&quot;:&quot;Jamalo-Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAR&quot;,&quot;state&quot;:&quot;Jaroslavskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KB&quot;,&quot;state&quot;:&quot;Kabardino-Balkarskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGD&quot;,&quot;state&quot;:&quot;Kaliningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KLU&quot;,&quot;state&quot;:&quot;Kaluzhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KAM&quot;,&quot;state&quot;:&quot;Kamchatskiy kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KC&quot;,&quot;state&quot;:&quot;Karachaevo-Cherkesskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KEM&quot;,&quot;state&quot;:&quot;Kemerovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIR&quot;,&quot;state&quot;:&quot;Kirovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KOS&quot;,&quot;state&quot;:&quot;Kostromskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KDA&quot;,&quot;state&quot;:&quot;Krasnodarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIA&quot;,&quot;state&quot;:&quot;Krasnojarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGN&quot;,&quot;state&quot;:&quot;Kurganskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KRS&quot;,&quot;state&quot;:&quot;Kurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LEN&quot;,&quot;state&quot;:&quot;Leningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LIP&quot;,&quot;state&quot;:&quot;Lipeckaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MAG&quot;,&quot;state&quot;:&quot;Magadanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOS&quot;,&quot;state&quot;:&quot;Moskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOW&quot;,&quot;state&quot;:&quot;Moskva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MUR&quot;,&quot;state&quot;:&quot;Murmanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NEN&quot;,&quot;state&quot;:&quot;Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NIZ&quot;,&quot;state&quot;:&quot;Nizhegorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NGR&quot;,&quot;state&quot;:&quot;Novgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NVS&quot;,&quot;state&quot;:&quot;Novosibirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;OMS&quot;,&quot;state&quot;:&quot;Omskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORE&quot;,&quot;state&quot;:&quot;Orenburgskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORL&quot;,&quot;state&quot;:&quot;Orlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PNZ&quot;,&quot;state&quot;:&quot;Penzenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PER&quot;,&quot;state&quot;:&quot;Permskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PRI&quot;,&quot;state&quot;:&quot;Primorskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PSK&quot;,&quot;state&quot;:&quot;Pskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AD&quot;,&quot;state&quot;:&quot;Respublika Adygeja&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Respublika Altaj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Respublika Bashkortostan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Respublika Burjatija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;DA&quot;,&quot;state&quot;:&quot;Respublika Dagestan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KK&quot;,&quot;state&quot;:&quot;Respublika Hakasija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Respublika Ingushetija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KL&quot;,&quot;state&quot;:&quot;Respublika Kalmykija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Respublika Karelija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KO&quot;,&quot;state&quot;:&quot;Respublika Komi&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Respublika Marij Jel&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Respublika Mordovija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Respublika Saha (Jakutija)&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Respublika Severnaja Osetija-Alanija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Respublika Tatarstan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TY&quot;,&quot;state&quot;:&quot;Respublika Tyva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;RYA&quot;,&quot;state&quot;:&quot;Rjazanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ROS&quot;,&quot;state&quot;:&quot;Rostovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAK&quot;,&quot;state&quot;:&quot;Sahalinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAM&quot;,&quot;state&quot;:&quot;Samarskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Sankt-Peterburg&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saratovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SMO&quot;,&quot;state&quot;:&quot;Smolenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;STA&quot;,&quot;state&quot;:&quot;Stavropol'skij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SVE&quot;,&quot;state&quot;:&quot;Sverdlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TAM&quot;,&quot;state&quot;:&quot;Tambovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TYU&quot;,&quot;state&quot;:&quot;Tjumenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TOM&quot;,&quot;state&quot;:&quot;Tomskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TUL&quot;,&quot;state&quot;:&quot;Tul'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TVE&quot;,&quot;state&quot;:&quot;Tverskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udmurtskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ULY&quot;,&quot;state&quot;:&quot;Ul'janovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLA&quot;,&quot;state&quot;:&quot;Vladimirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VGG&quot;,&quot;state&quot;:&quot;Volgogradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLG&quot;,&quot;state&quot;:&quot;Vologodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VOR&quot;,&quot;state&quot;:&quot;Voronezhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ZAB&quot;,&quot;state&quot;:&quot;Zabaykal'skiy kraj&quot;}],&quot;US&quot;:[{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alabama&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AK&quot;,&quot;state&quot;:&quot;Alaska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AZ&quot;,&quot;state&quot;:&quot;Arizona&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arkansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;California&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Colorado&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Connecticut&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DE&quot;,&quot;state&quot;:&quot;Delaware&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DC&quot;,&quot;state&quot;:&quot;District of Columbia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Florida&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GA&quot;,&quot;state&quot;:&quot;Georgia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guam&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;HI&quot;,&quot;state&quot;:&quot;Hawaii&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ID&quot;,&quot;state&quot;:&quot;Idaho&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;Illinois&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Indiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IA&quot;,&quot;state&quot;:&quot;Iowa&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KS&quot;,&quot;state&quot;:&quot;Kansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KY&quot;,&quot;state&quot;:&quot;Kentucky&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;LA&quot;,&quot;state&quot;:&quot;Louisiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Maine&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MD&quot;,&quot;state&quot;:&quot;Maryland&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;Massachusetts&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Michigan&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Minnesota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Mississippi&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Missouri&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Montana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Nebraska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NV&quot;,&quot;state&quot;:&quot;Nevada&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;New Hampshire&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NJ&quot;,&quot;state&quot;:&quot;New Jersey&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NM&quot;,&quot;state&quot;:&quot;New Mexico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NY&quot;,&quot;state&quot;:&quot;New York&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NC&quot;,&quot;state&quot;:&quot;North Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ND&quot;,&quot;state&quot;:&quot;North Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MP&quot;,&quot;state&quot;:&quot;Northern Mariana Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OH&quot;,&quot;state&quot;:&quot;Ohio&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OK&quot;,&quot;state&quot;:&quot;Oklahoma&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oregon&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Pennsylvania&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Puerto Rico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rhode Island&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SC&quot;,&quot;state&quot;:&quot;South Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SD&quot;,&quot;state&quot;:&quot;South Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Tennessee&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TX&quot;,&quot;state&quot;:&quot;Texas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utah&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Vermont&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Virgin Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Washington&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WV&quot;,&quot;state&quot;:&quot;West Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WI&quot;,&quot;state&quot;:&quot;Wisconsin&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WY&quot;,&quot;state&quot;:&quot;Wyoming&quot;}]},
                countries_with_codes: {&quot;RO&quot;:&quot;RO&quot;}            });

                            
                $.ceFormValidator('setZipcode', {
                    US: {
                        regexp: /^(\d{5})(-\d{4})?$/,
                        format: '01342 (01342-5678)'
                    },
                    CA: {
                        regexp: /^[A-Z]{1}\d{1}[A-Z]{1} *\d{1}[A-Z]{1}\d{1}$/i,
                        format: 'V1A OB1 / V1AOB1'
                    },
                    RU: {
                        regexp: /^(\d{6})?$/,
                        format: '123456'
                    }
                });
                
                    }

                    zipCodeInitializer();
            }(Tygh, Tygh.$));
    //]]>





    
	
        Salut, zireal reverse flash
    Deconectare

 
    
                    PROFILUL TĂU
                                    Dispozitivele tale
        
        


                    Vezi toate comenzile tale
                                    Dezactivare cont
        
                                        
    
    
                    PROFILUL TĂU
                            Dispozitivele tale
        
        


                    Vezi toate comenzile tale
                            Dezactivare cont
                                                        Deconectare
    
 


    $(document).ready(function(){
        $('ul.leftMenu li a').on('click', function() {
            dataLayer.push({
                'profileSection': $(this).text(),
                'event': 'profileSectionChange'
            });
        });
    })





	
        	                     

                
            
                Datele tale
                
                    Editare
                    Anulare
                    Salvare
                
            
            
                
                
                
                                                    




    
                                    
                    E-MAIL *
                                            
                    
                                                        
                        
	
        //&lt;![CDATA[
            Tygh.tr(&quot;email_providers_ajax.waiting_text&quot;, &quot;În așteptarea ca serverul să valideze mesajele e-mail, așteptați&quot;);
            Tygh.tr(&quot;email_providers_ajax.blacklisted_email_error&quot;, &quot;Nu îți poți crea un cont cu această adresă de e-mail. Te rugăm să introduci alta.&quot;);
            Tygh.tr(&quot;email_providers_ajax.url&quot;, &quot;https://preprod.iqos.ro/index.php?dispatch=email_providers_ajax.validate_email&quot;);
        //]]>
	
    




    




                                                            


    

        



                                        
    
    
        
    
                                                    
    
    
        
    
        
    
    
                                                                
    
        
                                        
                
                                            PRENUME
                     *
                                    
                

                                                                                                                                                                                    
              
                
                                    
                                

            
                                

            

                                            
    
    
        
    
        
    
    
                                                                
    
        
                                        
                
                                            NUME
                     *
                                    
                

                                                                                                                                                                                    
              
                
                                    
                                

            
                                

            

                                            
    
    
        
    
        
    
    
                                                                
    
        
                                        
                
                                            DATA NAȘTERII
                     *
                                    
                

                                    
              
                                
                                                                                            
                    
        
                            01/01/1997
                    

            
                                    
                                                                                        Zi / Luna / An
                
            
                                

            

    








    /* Prefix phone number */
    .shipping-phone.-focus.input-container:before,
    .shipping-phone.-filled.input-container:before {
        content: &quot;07&quot;;
        height: 40px;
        position: absolute;
        display: block;
        line-height: 41px;
        padding-left: 12px;
    }
    .shipping-phone.-focus.-expanded.input-container:before,
    .shipping-phone.-filled.-expanded.input-container:before {
        height: 56px;
        line-height: 57px;
    }
    .shipping-phone.-focus.input-container input,
    .shipping-phone.-filled.input-container input {
        padding-left: 38px;
    }
    .user-info .s_phone:before, .user-info .b_phone:before {
        content: &quot;07&quot;;
    }






                
                                                                    
                            var address_switch = $('input:radio:checked', '.ty-address-switch');
                            $(&quot;#shipping_address_reset&quot;).on(&quot;click&quot;, function(e) {
                                setTimeout(function() {
                                    address_switch.click();
                                }, 50);
                            });
                        
                                                
            
                
                    Editare
                    Anulare
                    Salvare
                
            
            
            
        
        
            
                Adrese
                
                    Editare
                    Anulare
                    Salvare
                
            
            
                
                
                
                                    
                                                                                                                                                                                                                                                


        


            



                                        
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            JUDET
                     *
                                    
                

                                                                                                                                                
              
                
                                        
                                                                    
                            - Selectare stat -
                                                                                                
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                                    ALBAARADARGESBACAUBIHORBISTRITA-NASAUDBOTOSANIBRAILABRASOVBUCURESTIBUZAUCALARASICARAS-SEVERINCLUJCONSTANTACOVASNADAMBOVITADOLJGALATIGIURGIUGORJHARGHITAHUNEDOARAIALOMITAIASIILFOVMARAMURESMEHEDINTIMURESNEAMTOLTPRAHOVASALAJSATU MARESIBIUSUCEAVATELEORMANTIMISTULCEAVALCEAVASLUIVRANCEA
                        
                        
                                    


            
                                

            

                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            LOCALITATE
                     *
                                    
                

                                                                                                                                                                                    
              
                        
    
            
                                

            

                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            SECTOR
                    
                                     *
                

                                    
              
                
                                    
                    
                                            

                                

            
                                

            

                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            NUMĂR DE TELEFON
                     *
                                    
                

                                    
                                            
                            
                                

            

                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
                                        
                
                                            COUNTRY
                    
                                    
                

                                    
              
                
                                    
                        
                        - Selectate țară -
                                                Afghanistan
                                                Aland Islands
                                                Albania
                                                Algeria
                                                American Samoa
                                                Andorra
                                                Angola
                                                Anguilla
                                                Antarctica
                                                Antigua and Barbuda
                                                Argentina
                                                Armenia
                                                Aruba
                                                Asia-Pacific
                                                Australia
                                                Austria
                                                Azerbaijan
                                                Bahamas
                                                Bahrain
                                                Bangladesh
                                                Barbados
                                                Belarus
                                                Belgium
                                                Belize
                                                Benin
                                                Bermuda
                                                Bhutan
                                                Bolivia
                                                Bosnia and Herzegowina
                                                Botswana
                                                Bouvet Island
                                                Brazil
                                                British Indian Ocean Territory
                                                British Virgin Islands
                                                Brunei Darussalam
                                                Bulgaria
                                                Burkina Faso
                                                Burundi
                                                Cambodia
                                                Cameroon
                                                Canada
                                                Cape Verde
                                                Cayman Islands
                                                Central African Republic
                                                Chad
                                                Chile
                                                China
                                                Christmas Island
                                                Cocos (Keeling) Islands
                                                Colombia
                                                Comoros
                                                Congo
                                                Cook Islands
                                                Costa Rica
                                                Cote D'ivoire
                                                Croatia
                                                Cuba
                                                Curaçao
                                                Cyprus
                                                Czech Republic
                                                Denmark
                                                Djibouti
                                                Dominica
                                                Dominican Republic
                                                East Timor
                                                Ecuador
                                                Egypt
                                                El Salvador
                                                Equatorial Guinea
                                                Eritrea
                                                Estonia
                                                Ethiopia
                                                Europe
                                                Falkland Islands (Malvinas)
                                                Faroe Islands
                                                Fiji
                                                Finland
                                                France
                                                France, Metropolitan
                                                French Guiana
                                                French Polynesia
                                                French Southern Territories
                                                Gabon
                                                Gambia
                                                Georgia
                                                Germany
                                                Ghana
                                                Gibraltar
                                                Greece
                                                Greenland
                                                Grenada
                                                Guadeloupe
                                                Guam
                                                Guatemala
                                                Guernsey
                                                Guinea
                                                Guinea-Bissau
                                                Guyana
                                                Haiti
                                                Heard and McDonald Islands
                                                Honduras
                                                Hong Kong
                                                Hungary
                                                Iceland
                                                India
                                                Indonesia
                                                Iraq
                                                Ireland
                                                Islamic Republic of Iran
                                                Isle of Man
                                                Israel
                                                Italy
                                                Jamaica
                                                Japan
                                                Jersey
                                                Jordan
                                                Kazakhstan
                                                Kenya
                                                Kiribati
                                                Korea
                                                Korea, Republic of
                                                Kuwait
                                                Kyrgyzstan
                                                Laos
                                                Latvia
                                                Lebanon
                                                Lesotho
                                                Liberia
                                                Libyan Arab Jamahiriya
                                                Liechtenstein
                                                Lithuania
                                                Luxembourg
                                                Macau
                                                Macedonia
                                                Madagascar
                                                Malawi
                                                Malaysia
                                                Maldives
                                                Mali
                                                Malta
                                                Marshall Islands
                                                Martinique
                                                Mauritania
                                                Mauritius
                                                Mayotte
                                                Mexico
                                                Micronesia
                                                Moldova, Republic of
                                                Monaco
                                                Mongolia
                                                Montenegro
                                                Montserrat
                                                Morocco
                                                Mozambique
                                                Myanmar
                                                Namibia
                                                Nauru
                                                Nepal
                                                Netherlands
                                                New Caledonia
                                                New Zealand
                                                Nicaragua
                                                Niger
                                                Nigeria
                                                Niue
                                                Norfolk Island
                                                Northern Mariana Islands
                                                Norway
                                                Oman
                                                Pakistan
                                                Palau
                                                Palestine Authority
                                                Panama
                                                Papua New Guinea
                                                Paraguay
                                                Peru
                                                Philippines
                                                Pitcairn
                                                Poland
                                                Portugal
                                                Puerto Rico
                                                Qatar
                                                Republic of Serbia
                                                Reunion
                                                Romania
                                                Russian Federation
                                                Rwanda
                                                Saint Lucia
                                                Samoa
                                                San Marino
                                                Sao Tome and Principe
                                                Saudi Arabia
                                                Senegal
                                                Serbia
                                                Seychelles
                                                Sierra Leone
                                                Singapore
                                                Sint Maarten
                                                Slovakia
                                                Slovenia
                                                Solomon Islands
                                                Somalia
                                                South Africa
                                                Spain
                                                Sri Lanka
                                                St. Helena
                                                St. Kitts and Nevis
                                                St. Pierre and Miquelon
                                                St. Vincent and the Grenadines
                                                Sudan
                                                Suriname
                                                Svalbard and Jan Mayen Islands
                                                Swaziland
                                                Sweden
                                                Switzerland
                                                Syrian Arab Republic
                                                Taiwan
                                                Tajikistan
                                                Tanzania, United Republic of
                                                Thailand
                                                Togo
                                                Tokelau
                                                Tonga
                                                Trinidad and Tobago
                                                Tunisia
                                                Turkey
                                                Turkmenistan
                                                Turks and Caicos Islands
                                                Tuvalu
                                                Uganda
                                                Ukraine
                                                United Arab Emirates
                                                United Kingdom (Great Britain)
                                                United States
                                                United States Virgin Islands
                                                Uruguay
                                                Uzbekistan
                                                Vanuatu
                                                Vatican City State
                                                Venezuela
                                                Viet Nam
                                                Wallis And Futuna Islands
                                                Western Sahara
                                                Yemen
                                                Zaire
                                                Zambia
                                                Zimbabwe
                                                

                    
                
            
                                

            

    








    /* Prefix phone number */
    .shipping-phone.-focus.input-container:before,
    .shipping-phone.-filled.input-container:before {
        content: &quot;07&quot;;
        height: 40px;
        position: absolute;
        display: block;
        line-height: 41px;
        padding-left: 12px;
    }
    .shipping-phone.-focus.-expanded.input-container:before,
    .shipping-phone.-filled.-expanded.input-container:before {
        height: 56px;
        line-height: 57px;
    }
    .shipping-phone.-focus.input-container input,
    .shipping-phone.-filled.input-container input {
        padding-left: 38px;
    }
    .user-info .s_phone:before, .user-info .b_phone:before {
        content: &quot;07&quot;;
    }






                    



                    

                
                
            
            
                
                    Editare
                    Anulare
                    Salvare
                
            
            
            
        
                


    

    
                Modifică parola
                EditareAnulareSalvare
    
    
        
        
                        
                Parola dvs. actuală
                
            
            
                Parola dvs. actuală
                
            
                        
                Parolă nouă
                
                Trebuie să conțină între 8 și 20 de caractere, dintre care cel puțin o cifră.
            
            
                Confirmare parolă nouă
                
            
                
    
        EditareAnulareSalvare
    
    
    



    
    
        Comunicare
        EditareAnulareSalvare
            Salvare
        
            Ești sigur că dorești să nu mai beneficiezi de Care Plus?  Toate dispozitivele tale vor fi dezabonate.

            
                NU
                        


 
    
                    DA
            

            
        
    
    
        
        
        
        




        
                                
            
                            
                    
                    
                    
                    Nu vreau să ratez ofertele (reduceri, ediții limitate, noutăți despre produse ș.a.) Philip Morris Trading S.R.L. și sunt de acord să primesc prin email sau SMS informații comerciale despre IQOS, HEETS sau alte produse/servicii conexe oferite de Philip Morris Trading S.R.L. sau de partenerii săi.
                
            
            
            
Please note, by unticking the marketing opt-in, you will lose your care plus membership and all related advantages.
        
    
            
        
    




            
    
        EditareAnulareSalvare
    
    
    




    
	





  
    
  



  $('.banner-wrapper a').on('click', function() {
        var _ggt_banner_id = 'this banner must be changed on backend banners',
            _ggt_banner_name = 'Meet Your Match',
            _ggt_banner_creative = 'girl.jpg?d=0',
            _ggt_banner_position = 'Profile';
        
            dataLayer.push({
            'event': 'promotionView',
            'ecommerce': {
                'promoView': {
                    'promotions': [{
                        'id': _ggt_banner_id,
                        'name': _ggt_banner_name,
                        'creative': _ggt_banner_creative,
                        'position': _ggt_banner_position
                    }]
                }
            }
        })
    })

        
    


        
        
            
                
                    
                        
                    
                    
                        
                    
                    Product added to cart
                
            
            
            
                Your cart is empty
                Find the IQOS that suits you best.
                Compare models
            
            
                Validare informații comandă
            

            
                
                    
                
                
                    
                    
                    
                
                
                    
                                                    Gratuit
                                            
                    
                
            
        
    



                    


    
                    


                    
                                


                    
                



© 2019 Philip Morris Product SA. 

        
                    


                    
                
    
                
            
            Linkuri utile 
            

                        
    
                                        
             Găsește IQOS
                    
                                        
             Noutăți
                    
                                        
             Promisiunea IQOS
                    
                                        
             Accesează PMI.COM
                    
            

                    
                
            
            Asistență clienți 
            

                        
    
                                        
             Contactează-ne
                    
                                        
             Tutoriale
                    
                                        
             Înlocuire IQOS
                    
                                        
             Întrebări frecvente
                    
                                        
             Facturile mele
                    
            

                    
                
            
            Legal 
            

                        
    
                                        
             ANPC
                    
                                        
             Termeni și condiții
                    
                                        
             Notificare de protecție a datelor
                    
                                        
             Politică de cookies
                    
                                        Gestionează cookies
                                        
             Termeni și condiții de vânzare
                    
                                        
             Termeni și condiții - IQOS Care Plus
                    
                                        
             Termeni și condiții -  Trade-in
                    
                                        
             Conținut generat de utilizatori
                    
            

                    
                
            
            Urmărește-ne 
            

                        
    
                                        
            
                    
                                        
            
                    
                                        
            
                    
            

                    
            

        
    
        
                    


                    
                
    $.ceEvent('on', 'ce.formajaxpost_forget_password_form', function(data) {
        $('input#recover-email').val('');
    });

    .ot-sdk-show-settings { cursor: pointer; color: #999;}
    .ot-sdk-show-settings:hover { color: #666; }
  
   
  /* Get all Cookies */
  function getCookie(cname) {
    var name = cname + &quot;=&quot;;
    var all = document.cookie.split(';');
      for(var i = 0; i &lt; all.length; i++) {
          var c = all[i];
            while (c.charAt(0) == ' ') {
             c = c.substr(1);
            }
    if (c.indexOf(name) == 0) {
      return c.substr(name.length, c.length);
    }
  }
  return &quot;&quot;;
  }
	var _cookieSettingsDatalayer = function(type, value) {
	  dataLayer.push({
		  'event': 'cookieSettings',
		  'cookieType': type,
		  'cookieValue': value
	  });
	};
  /* Assign Values */
  function chkOneTrust() {
    var ot_value = getCookie(&quot;OptanonConsent&quot;);
    if (ot_value != &quot;&quot;) {
      var re = /([^%]*%[^%]*)%/gm;
      var subst = '$1;'; 
      var r1 = ot_value.substring(ot_value.indexOf(&quot;groups=&quot;) + 7);
      var r2 = r1.substring(0,r1.indexOf(&quot;&amp;&quot;));
      if (r2 != &quot;&quot;) { var r3 = r2.replace(re, subst); } else { var r3 = r1.replace(re, subst); }
      var rx = r3.split(';'); 

      var cc0002 = rx[1].substring(rx[1].length - 1);
      var cc0004 = rx[2].substring(rx[2].length - 1);
  
      var d = new Date();
          d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000));
      var expd = &quot;expires=&quot; + d.toUTCString() + &quot;; path=/; secure&quot;;
      if (cc0002 == 1) { document.cookie = 'dw_Technical_cookie=opt-in;' + expd;
						 _cookieSettingsDatalayer('performance', 'opt-in');
					   } 
				  else { document.cookie = 'dw_Technical_cookie=opt-out;' + expd;
						 _cookieSettingsDatalayer('performance', 'opt-out');
					   }
      if (cc0004 == 1) { document.cookie = 'dw_Advertisement_cookie=opt-in;' + expd;
						 _cookieSettingsDatalayer('advertising', 'opt-in');
					   } 
				  else { document.cookie = 'dw_Advertisement_cookie=opt-out;' + expd;
						 _cookieSettingsDatalayer('advertising', 'opt-out');
					   }
    } else {
      /*console.log('Not Exist'); */
      }
  }
  (function(window, document, undefined){
	window.onload = setTimeout(otdcs,2000);
  
	function otdcs(){
	  var d = new Date();
		  d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000));
	  var expd = &quot;expires=&quot;+d.toUTCString() + &quot;; path=/; secure&quot;;
      var dw_t = getCookie(&quot;dw_Technical_cookie&quot;);
      var dw_a = getCookie(&quot;dw_Advertisement_cookie&quot;);
	  var nct = &quot;N&quot;, nca = &quot;N&quot;;
	  /* create dw cookies if they don't exist */
		if (dw_t != &quot;&quot;) { /* console.log(&quot;DCS - Already Exist Technical&quot;) */ } else { document.cookie = 'dw_Technical_cookie=opt-in;' + expd; var nct = &quot;Y&quot;; }
		if (dw_a != &quot;&quot;) { /* console.log(&quot;DCS - Already Exist Advert&quot;) */ } else { document.cookie = 'dw_Advertisement_cookie=opt-out;' + expd; var nca = &quot;Y&quot;; }
	  /* assign action to elements */
		var btn1 = document.querySelectorAll(&quot;#onetrust-accept-btn-handler&quot;);
		var btn2 = document.querySelectorAll(&quot;#accept-recommended-btn-handler&quot;);
		var btn3 = document.querySelectorAll(&quot;.save-preference-btn-handler&quot;);
		  if (btn1.length > 0) { btn1[0].setAttribute(&quot;onclick&quot;,&quot;setTimeout(chkOneTrust,2000)&quot;); } else { /*console.log(&quot;otx not exist&quot;)*/ }
		  if (btn2.length > 0) { btn2[0].setAttribute(&quot;onclick&quot;,&quot;setTimeout(chkOneTrust,2000)&quot;); } else { /*console.log(&quot;oty not exist&quot;)*/ }
		  if (btn3.length > 0) { btn3[0].setAttribute(&quot;onclick&quot;,&quot;setTimeout(chkOneTrust,2000)&quot;); } else { /*console.log(&quot;otz not exist&quot;)*/ }
  
	  /* check if values are aligned - begin */ 
		var obj = { 
            &quot;1&quot;: &quot;opt-in&quot;, 
            &quot;0&quot;: &quot;opt-out&quot;
        };
		var reg = new RegExp(Object.keys(obj).join(&quot;|&quot;), &quot;gi&quot;); 	
		var ot_value = getCookie(&quot;OptanonConsent&quot;);
		var re = /([^%]*%[^%]*)%/gm;
		var subst = '$1;'; 
		var r1 = ot_value.substring(ot_value.indexOf(&quot;groups=&quot;) + 7);
		var r2 = r1.substring(0,r1.indexOf(&quot;&amp;&quot;));
		  if (r2 != &quot;&quot;) { var r3 = r2.replace(re, subst); } else { var r3 = r1.replace(re, subst); }
		var rx = r3.split(';'); 
      
		var cc02 = (rx[1].substring(rx[1].length - 1)).replace(reg, function(matched) { return obj[matched]; });
		var cc04 = (rx[2].substring(rx[2].length - 1)).replace(reg, function(matched) { return obj[matched]; });
		
		if (nct == &quot;N&quot;) {
		  if (dw_t == cc02) { /*console.log(&quot;do nothing&quot;);*/ } else { document.cookie = 'dw_Technical_cookie=' + cc02 + ';' + expd;
																		_cookieSettingsDatalayer('performance', cc02);
																	  } } else { /*console.log(&quot;do nothing&quot;)*/ }
		if (nca == &quot;N&quot;) {
		  if (dw_a == cc04) { /*console.log(&quot;do nothing&quot;);*/ } else { document.cookie = 'dw_Advertisement_cookie=' + cc04 + ';' + expd;
																		_cookieSettingsDatalayer('advertising', cc04);
																	  } } else { /*console.log(&quot;do nothing&quot;)*/ }
	  /* check if values are aligned - end */  
  }
  })(window, document, undefined);
  
        
    



    
    

    

    
			
		
	var gafd = '{&quot;logged&quot;:true,&quot;userid&quot;:&quot;4782&quot;,&quot;gender&quot;:&quot;F&quot;}';
			var products = new Array();
		





    

(function(a){var c=a.push;a.push=function(){var b=arguments[0];&quot;formTrySubmitted&quot;==b.event&amp;&amp;(b.formTrySubmittedID=&quot;1383209068&quot;);return c.apply(a,arguments)}})(window.dataLayer);
var MathTag={version:&quot;1.1&quot;,delimiter:&quot;/&quot;,previous_url:document.referrer,mt_exem:&quot;&quot;,industry:&quot;Tobacco&quot;,mt_adid:&quot;238100&quot;,event_type:&quot;catchall&quot;,mt_id:&quot;1480649&quot;,city:&quot;&quot;,country:&quot;RO&quot;,currency:&quot;RON&quot;,order_id:&quot;undefined&quot;,page_name:&quot;my account&quot;,payment_type:&quot;undefined&quot;,product_category:&quot;undefined&quot;,product_id:&quot;undefined&quot;,product_name:&quot;undefined&quot;,product_price:&quot;undefined&quot;,revenue:&quot;undefined&quot;,
site_language:&quot;ro-RO&quot;,store_id:&quot;&quot;,s3:&quot;undefined&quot;,s4:&quot;undefined&quot;,s5:&quot;undefined&quot;,s6:&quot;undefined&quot;,s7:&quot;&quot;,s8:&quot;preprod.iqos.ro&quot;,s9:&quot;&quot;,s10:&quot;my account&quot;,v3:&quot;&quot;,v4:&quot;&quot;};


function OptanonWrapper(){};


 window.sprChatSettings=window.sprChatSettings||{};window.sprChatSettings={appId:&quot;app_273317&quot;};
(function(){var e=window,c=e.sprChat;if(&quot;function&quot;===typeof c)c(&quot;update&quot;,e.sprChatSettings);else{var a=document,d=function(){d.m(arguments)};d.q=[];d.m=function(b){d.q.push(b)};e.sprChat=d;c=function(){var b=a.createElement(&quot;script&quot;);b.type=&quot;text/javascript&quot;;b.async=!0;b.src=&quot;https://prod-live-chat.sprinklr.com/api/livechat/handshake/widget/&quot;+e.sprChatSettings.appId;var f=a.getElementsByTagName(&quot;script&quot;)[0];f.parentNode.insertBefore(b,f)};(a.attachEvent?&quot;complete&quot;===a.readyState:&quot;loading&quot;!==a.readyState)?
c():a.addEventListener(&quot;DOMContentLoaded&quot;,c)}})();switch(google_tag_manager[&quot;GTM-PLBRD26&quot;].macro(194)){case &quot;open&quot;:window.sprChat(&quot;open&quot;);break;case &quot;close&quot;:window.sprChat(&quot;close&quot;)};
  /html[@class=&quot;profiles-update cap_cookies cap_flexbox cap_flexwrap age-gate-hidden not_IE&quot;]
(function(a){a=document.createElement(&quot;script&quot;);a.src=&quot;//survey.survicate.com/workspaces/e668aa655e09c2cba84e2c7b66274064/web_surveys.js&quot;;a.async=!0;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})(window);

(function(){var l=function(e,g,f,h){this.get=function(a){a+=&quot;\x3d&quot;;for(var b=document.cookie.split(&quot;;&quot;),c=0,k=b.length;c&lt;k;c++){for(var d=b[c];&quot; &quot;==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return null};this.set=function(a,b){var c=new Date;c.setTime(c.getTime()+6048E5);c=&quot;; expires\x3d&quot;+c.toGMTString();document.cookie=a+&quot;\x3d&quot;+b+c+&quot;; path\x3d/; &quot;};this.check=function(){var a=this.get(f);if(a)a=a.split(&quot;:&quot;);else if(100!=e)&quot;v&quot;==g&amp;&amp;(e=Math.random()>=
e/100?0:100),a=[g,e,0],this.set(f,a.join(&quot;:&quot;));else return!0;var b=a[1];if(100==b)return!0;switch(a[0]){case &quot;v&quot;:return!1;case &quot;r&quot;:return b=a[2]%Math.floor(100/b),a[2]++,this.set(f,a.join(&quot;:&quot;)),!b}return!0};this.go=function(){if(this.check()){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.src=h;document.body&amp;&amp;document.body.appendChild(a)}};this.start=function(){var a=this;&quot;complete&quot;!==document.readyState?window.addEventListener?window.addEventListener(&quot;load&quot;,function(){a.go()},
!1):window.attachEvent&amp;&amp;window.attachEvent(&quot;onload&quot;,function(){a.go()}):a.go()}};try{(new l(100,&quot;r&quot;,&quot;QSI_S_ZN_5vCyQ5OiCDZLk2N&quot;,&quot;https://zn5vcyq5oicdzlk2n-pmimsa.siteintercept.qualtrics.com/SIE/?Q_ZID\x3dZN_5vCyQ5OiCDZLk2N\x26Q_VERSION\x3d0&quot;)).start()}catch(e){}})();
 

ttd_dom_ready(function(){if(&quot;function&quot;===typeof TTDUniversalPixelApi){var a=new TTDUniversalPixelApi;a.init(&quot;lq9vsz7&quot;,[&quot;o1d9bmt&quot;],&quot;https://insight.adsrvr.org/track/up&quot;)}});
        ttd_dom_ready(function(){if(&quot;function&quot;===typeof TTDUniversalPixelApi){var a=new TTDUniversalPixelApi;a.init(&quot;pwk1d6f&quot;,[&quot;9uh1rku&quot;],&quot;https://insight.adsrvr.org/track/up&quot;)}});
        ttd_dom_ready(function(){if(&quot;function&quot;===typeof TTDUniversalPixelApi){var a=new TTDUniversalPixelApi;a.init(&quot;312psk4&quot;,[&quot;rfo4ndt&quot;],&quot;https://insight.adsrvr.org/track/up&quot;)}});
        ttd_dom_ready(function(){if(&quot;function&quot;===typeof TTDUniversalPixelApi){var a=new TTDUniversalPixelApi;a.init(&quot;7ueg8lw&quot;,[&quot;ny273y6&quot;],&quot;https://insight.adsrvr.org/track/up&quot;)}});
Ce cookie-uri utilizăm?Ce sunt cookies? Cookies sunt mici fișiere de tip text plasate în dispozitivul tău atunci când accesezi un website, care apoi sunt folosite pentru a identifica dispozitivul tău în scopurile prevăzute mai jos. Cookies instalate de proprietarul unei platforme digitale se numesc „cookies primare”. Cookies instalate de alte persoane se numesc „cookies terțe”. Acestea din urmă permit terților să ofere funcții sau funcționalități pe sau prin platforma digitală (precum funcții analitice, publicitate și materiale video). Cei care instalează aceste cookies terțe pot recunoaște dispozitivul tău atât atunci când accesezi platforma noastră digitală, cât și atunci când vizitezi alte platforme digitale. 
Cookies folosite de acest website sunt de trei categorii. Cele din prima categorie sunt cookies strict necesare pentru funcționalitatea website-ului și nu pot fi dezactivate. Cookies din celelalte categorii sunt opționale – poți decide dacă să le permiți și îți poți seta preferințele aici. Îți poți schimba opțiunile în orice moment accesând secțiunea “Gestionează cookies” din orice pagină a website-ului.
                        Vezi notificarea de protecție a datelor aici.Acceptă toateGestionează preferințele taleCookies strict necesareMereu activeSunt strict necesare pentru funcționarea corectă a website-ului și a tuturor serviciilor oferite de aceasta. De exemplu, stocarea preferințelor tale în relație cu website-ul nostru, astfel încât să nu fie nevoie să le introduci la încărcarea fiecărei pagini. Aceste cookies sunt esențiale pentru operarea website-ului și a serviciilor sale, astfel încât refuzarea colectării lor nu este posibilă. În orice caz, dacă dorești refuzarea tuturor cookie-urilor, poți configura browser-ul tău pentru a refuza toate aceste tipuri de fișiere. În cazul acesta, este posibil ca website-ul să nu se afișeze corect, iar funcționalitățile sale să nu fie disponibile în totalitate.Detalii despre cookie-uri‎Cookies pentru evaluarea performanței  Cookies pentru evaluarea performanței Acestea ne permit să înțelegem modul în care vizitatorii folosesc și interacționează cu website-ul, precum și performanța acestuia. Ne permit să îmbunătățim modul în care funcționează platforma digitală. Aceste date sunt anonime, iar informația este redusă astfel încât să identifice exclusiv zona din care accesezi website-ul, iar apoi sunt agregate înainte de a fi folosite de noi. Poți alege să le accepți sau nu.Detalii despre cookie-uri‎Cookies de marketing (targetare)  Cookies de marketing (targetare) Acestea sunt folosite pentru a analiza modul în care folosești acest website și alte website-uri, astfel încât să îți livrăm, pe acest website sau pe alte website-uri, informații personalizate pe baza informațiilor analizate. Acestea includ atât publicitate online, cât și personalizarea conținutului comunicărilor noastre cu tine, astfel încât să fie cât mai relevante. De asemenea, acest lucru poate implica și agregarea acestor date pentru o înțelegere holistică a activității utilizatorilor. De exemplu: Partenerii noștri de Publicitate angajează terți pentru a urmări și analiza, utiliza și colecta informații statistice de la persoanele care vizitează website-ul. Poți alege să le accepți sau nu.Detalii despre cookie-uri‎Back Button Performance CookiesVendor Search  Search IconFilter IconClear checkbox label labelApply CancelConsent Leg.Interest checkbox label label checkbox label label checkbox label label33Acrosshost descriptionView CookiesNamecookie name Salvează setările</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;profiles-update cap_cookies cap_flexbox cap_flexwrap age-gate-hidden not_IE&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//html</value>
   </webElementXpaths>
</WebElementEntity>
