<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>path_GSETE UN MAGAZIN_path path-light</name>
   <tag></tag>
   <elementGuidId>4cc23026-1c2c-4e47-b06a-80c470fe6a19</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.header-icon.header-icon-profile.no-logged-icon-profile > svg > path.path.path-light</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>path path-light</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M13.62,12.92a6.25,6.25,0,1,0-5.24,0A8.5,8.5,0,0,0,2.5,21h1a7.5,7.5,0,0,1,15,0h1A8.5,8.5,0,0,0,13.62,12.92ZM5.75,7.25A5.25,5.25,0,1,1,11,12.5,5.25,5.25,0,0,1,5.75,7.25Z</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;header&quot;)/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;row-fluid&quot;]/div[@class=&quot;span12 header-inner&quot;]/a[@class=&quot;header-icon header-icon-profile  no-logged-icon-profile&quot;]/svg[1]/path[@class=&quot;path path-light&quot;]</value>
   </webElementProperties>
</WebElementEntity>
