<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_E-MAIL                                _f633d6</name>
   <tag></tag>
   <elementGuidId>f230a97a-6457-42ed-8884-fff85681c22c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>form[name=&quot;profile_form_contact&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='profile_form_contact']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>profile_form_contact</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>action</name>
      <type>Main</type>
      <value>https://preprod.iqos.ro/my-iqos</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>autocomplete</name>
      <type>Main</type>
      <value>off</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>cm-processed-form</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                
                
                                                    




    
                                    
                    E-MAIL *
                                            
                    
                                                        
                        
	
        //&lt;![CDATA[
            Tygh.tr(&quot;email_providers_ajax.waiting_text&quot;, &quot;În așteptarea ca serverul să valideze mesajele e-mail, așteptați&quot;);
            Tygh.tr(&quot;email_providers_ajax.blacklisted_email_error&quot;, &quot;Nu îți poți crea un cont cu această adresă de e-mail. Te rugăm să introduci alta.&quot;);
            Tygh.tr(&quot;email_providers_ajax.url&quot;, &quot;https://preprod.iqos.ro/index.php?dispatch=email_providers_ajax.validate_email&quot;);
        //]]>
	
    




    




                                                            


    

        



                                        
    
    
        
    
                                                    
    
    
        
    
        
    
    
                                                                
    
        
                                        
                
                                            PRENUME
                     *
                                    
                

                                                                                                                                                                                    
              
                
                                    
                                

            
                                

            

                                            
    
    
        
    
        
    
    
                                                                
    
        
                                        
                
                                            NUME
                     *
                                    
                

                                                                                                                                                                                    
              
                
                                    
                                

            
                                

            

                                            
    
    
        
    
        
    
    
                                                                
    
        
                                        
                
                                            DATA NAȘTERII
                     *
                                    
                

                                    
              
                                
                                                                                            
                    
        
                            01/01/1997
                    

            
                                    
                                                                                        Zi / Luna / An
                
            
                                

            

    








    /* Prefix phone number */
    .shipping-phone.-focus.input-container:before,
    .shipping-phone.-filled.input-container:before {
        content: &quot;07&quot;;
        height: 40px;
        position: absolute;
        display: block;
        line-height: 41px;
        padding-left: 12px;
    }
    .shipping-phone.-focus.-expanded.input-container:before,
    .shipping-phone.-filled.-expanded.input-container:before {
        height: 56px;
        line-height: 57px;
    }
    .shipping-phone.-focus.input-container input,
    .shipping-phone.-filled.input-container input {
        padding-left: 38px;
    }
    .user-info .s_phone:before, .user-info .b_phone:before {
        content: &quot;07&quot;;
    }






                
                                                                    
                            var address_switch = $('input:radio:checked', '.ty-address-switch');
                            $(&quot;#shipping_address_reset&quot;).on(&quot;click&quot;, function(e) {
                                setTimeout(function() {
                                    address_switch.click();
                                }, 50);
                            });
                        
                                                </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;general&quot;)/form[@class=&quot;cm-processed-form&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@name='profile_form_contact']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='general']/form</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Salvare'])[1]/following::form[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Anulare'])[1]/following::form[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
   </webElementXpaths>
</WebElementEntity>
