<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Call center website                    _abb231</name>
   <tag></tag>
   <elementGuidId>f705a290-bb77-40a9-b96f-199a8edfdcb1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main_column']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#main_column</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>main_column</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>main-wrap</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
                        
                        



    
    
        

        

    
    Call center website


        
        
        

        
                    
                                                                                        
                        
                    
                                                        
                        
                            Store: RO iQOS
                        
                    
                            
                

        
        
            
                
                    
                    
                    Go
                    
                
            

        
        

                            


        
            
                                    
                        
                        Quick Links
                        
                        
                                                            
                                    View website
                                
                            
                                                        
    IQOS Care plus dashboard

                        
                    
                                                                
                        
                            Administration
                            
                        
                        

                                                            
                                                                                                                    Scheduled tasks
                                                                                                        
                                                                                            
                                                                                                                                                        
                                                                                                                                                
                    
                                            
            
            

            
                
                                    
                                            
    
        
                                                EN
                                        
        
        
                            
                    
                                                    
                                                English                    
                
                            
                    
                                                    
                                                Romanian                    
                
                    
    


                                        

                                

                
                
                                

                

                
                
                    
                        
                            
                            
                        
                    

                    
                        
                            Signed in ascallcenter_ro@test.com
                        
                        
                        
                        Edit profile
                        Sign out
                        

                                            
                
                
                            
            

        
    

    
    
        
                            
                

                                                        
                        View website
                    
                                    
        
                            Dashboard
                                                
                    
                       Cases
                    
                    
                        
                                                        
                                Cases
                                View all Cases

                                                            
                        
                                                        
                                Case Brands
                                Manage Case Brands

                                                            
                        
                                                        
                                Cases Sentiments
                                

                                                                    
                                                                                   Manage
                                                                            
                                                            
                                            
                
                            
                    
                       Customers
                    
                    
                        
                                                        
                                Customers
                                List of store customers, registered users with a customer account.

                                                            
                        
                                                        
                                Contacts
                                List of store contacts, registered users with a contact account.

                                                            
                        
                                                        
                                Administrators
                                List of store administrators, registered users with an administrator account.

                                                            
                        
                                                        
                                E-mail provider black list
                                

                                                            
                        
                                                        
                                Terms &amp; Conditions
                                Create, approve and edit Terms &amp; Conditions

                                                            
                                            
                
                            
                    
                       Orders
                    
                    
                        
                                                        
                                View orders
                                View, process and print invoices slips for orders placed from your web site.

                                                            
                        
                                                        
                                Replacement orders
                                

                                                            
                        
                                                        
                                Return orders
                                

                                                            
                        
                                                        
                                Preorders
                                

                                                            
                        
                                                        
                                SEA orders
                                

                                                            
                        
                                                        
                                SEA Return Orders
                                

                                                            
                        
                                                        
                                SEA Replacement Order
                                

                                                            
                                            
                
                            
                    
                       Marketing
                    
                    
                        
                                                        
                                Bazaarvoice
                                Upload the csv file in order to generate a transaction xml file.

                                                            
                        
                                                        
                                Live Tracker
                                

                                                            
                                            
                
                            
                    
                       Website
                    
                    
                        
                                                            
                                                        
                                Anonymous QURE device families
                                Configuration of Anonymous QURE's device families

                                                            
                                            
                
                            
                    
                       Devices
                    
                    
                        
                                                        
                                Register
                                Register a device

                                                            
                        
                                                        
                                Registered Devices
                                View &amp; Search Registered Devices

                                                            
                        
                                                        
                                Return Device
                                Return a device

                                                            
                        
                                                        
                                Return History
                                View &amp; Search Latest Device Returns

                                                            
                        
                                                        
                                Diagnostics
                                View &amp; Search Diagnostics

                                                            
                        
                                                        
                                Trade In discount's table
                                List of discounts for each Trade In scenario

                                                            
                                            
                
                            
                    
                       iTRACK
                    
                    
                        
                                                        
                                iTrack XML
                                View The XML Returned By iTrack

                                                            
                                            
                
                        
            

                
    


            
            
            
                

                







        


//&lt;![CDATA[
// Init ajax callback (rebuild)
var menu_content = '';

//]]>




            
        
        
            
            

    
    Recently 
    
                            Product: Inlocuire Kit IQOS (3 DUO...
                    User: mihai test
                    Product: Inlocuire IQOS (3 DUO BLUE)...
                    Comanda: 11993 - 0 RON
                    Product: Înlocuire Holder (&quot;Stilou&quot;)...
                    Metoda de expediere: Store AFI
                    Comanda: 11989 - 0 RON
                    Product: Loyalty Kit IQOS 3 DUO Copper
                    Product: iQOACH - IQOS Kit White...
                



            

            
            
                
            
            

        
        
        
        
            Adding new issue

.restricted .onep-form .span4:first-child {display: none !important;}
.restricted .onep-form .span4:nth-child(2) {display: none !important;}
.restricted .onep-form .span4:nth-child(3) .control-group:nth-child(2) {display: none !important;}
.restricted .onep-form .span4:nth-child(3) .control-group:nth-child(3) {display: none !important;}
.restricted .onep-form .span4:nth-child(3) .control-group:nth-child(4) {display: none !important;}
.restricted .onep-form .span4:nth-child(3) {margin: 0 auto; float: none; text-align: center;}
.restricted .onep-form .span8 h4 {display: none !important;}
.restricted .admin-content-wrap .sidebar .sidebar-row .cm-processed-form {display: none !important;}


   $( &quot;li.disabled&quot; ).find( &quot;a&quot; ).addClass(&quot;AdminEmail&quot;);
   if ($('.AdminEmail:contains(&quot;@iqosstore.ro&quot;)').length > 0)
 {
   $( &quot;body&quot; ).addClass( &quot;restricted&quot; );
}

    
    
                    
                            


 
     Exit without saving
    


        
        
             Exit Trade-In
        




    //&lt;![CDATA[
    (function(_, $) {
        $.ceEvent('on', 'ce.form_create_issue', function(data, prefix, suffix) {
            if (data.trade_in &amp;&amp; $('#exit_without_saving').is(&quot;:hidden&quot;)) {
                $('#opener_exit_trade_in').removeClass('hidden');
            }
        });
    }(Tygh, Tygh.$));
     //]]>


    




    
        
                        
        
            
                                                            Identify caller
                                                                                Select activity
                                                
        
    



        
            





    

    
    
    
                
                    
                

     
            Profile edit
        CUSTOMER PROFILE
    
        
            
            
        
        
            Last Name
            Suntesic

            First Name
            Ivan

            Date Of Birth
            01/02/1990

            Ecom ID
            5067
        
        
            
            
            

            Care plus member
        No
    


        
        
            Phone Number
            0725333111

            E-Mail
            ivan.suntesic1996@yopmail.com

            Address
            00, BUCURESTI, Romania
            
            
            Communication
            N
        
        
            User Type
                Membru iQOS™


            Status
            Active

                            Profile Status
                Active
            
            Registration Date
            24/02/2020, 14:23
            
            
            

        
    
	
    	

    
    


    
        	                        
                        Sales Orders
        
                            
                        SEA orders
        
                            
                        Customer Service
        
                            
                        User groups
        
                            
                        Statistics
        
                            
                        Referral Program
        
                            More


    		                            
                    
		
					
			
				SEA orders
																
					
					            
    View




		
					24/02/2020, 14:49
					
		
					Order number
					8782
		
					Order status
					Shipped Total
		
					Metoda de plată
					Subscription - CreditCard
		
					Payment status
					-
		
					Order Total
					
        289 RON

		
					Nb of items
					1
		
					Coupon / Promotion
					
													-
											
					
						            
    View All




							
			
                
            		                            
                    
        
            Last SEA order
                    No data found
            
                
            		                            
                    
		
    	LAST CASE
    No data found

	
		
		
LAST DEVICE
    No data found

	
	
		
LAST DIAGNOSTIC
    No data found

	

                
            		            		                            
                        
            
                
            
                
                    User group
                    Status
                
            
                            
                    
                                                    160RON
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
                
                    

                        

                    
                
                            
                    
                                                    1st SR
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    1st SR - used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    2nd SR
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    2nd SR - used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    2nd Starter Kit
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    4th SR
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    4th SR - used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    50 RON Duo HEETS – used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    59RON-2.4+
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    59RON-2.4+-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    85 RON - New
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    99RON-2.4+
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    99RON-2.4+-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    AN_CODR0270.6
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    B2BConsumer
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    BF 15-17 Nov
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    BF 18 Nov - Ongoing
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    BF up to 14 Nov
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Black Friday 2019
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    BlackFriday
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    CarePlus
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_cancelled
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_cancelled_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_finished
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_finished_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_pause_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_start_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    cfal_stop_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Device offer- November 2020
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Digital Qoach
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_cancelled
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_cancelled_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_finished
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_finished_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_pause_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_start_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoi_stop_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_cancelled
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_cancelled_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_finished
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_finished_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_pause_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_start_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    dsoo_stop_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    DUO HEETS 260 RON - used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Ecomm inactives – 6 months – eligible
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Ecomm inactives – 6 months – used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Engaged-duopromo
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Engaged-duopromo-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Entrepreneur
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Exclusive Sales 2019
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Godson-discount DUOHEETS-50RON
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Godson-discount DUOHEETS-50RON-expired
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Godson-discount DUOHEETS-50RON-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Hello Spring
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Hello Summer
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    helloiqos
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Holder&amp;HEETS
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Holder60
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Holder60 – eligible
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Incearca IQOS: Lending
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    INLOCUIRE DUO
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS 2017
                                            
                    
                                                                                                    
                            
            
                        Active
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS 2017 2nd
                                            
                    
                                                                                                    
                            
            
                        Declined
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS Club
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON active – Device
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON active – HEETS
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON alumni – Device
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON visitor
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON – alumni – HEETS
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON – early payment – Device
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON – failed payment – Device
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON – failed payment – HEETS
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON – HEETS canceled
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON – HEETS paused
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON – HEETS – loyal
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS ON – multiple subscriptions – Device
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS Upgrade DR
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS Upgrade NDR
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    IQOS XL Starter Kit
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_NonPromo_Cancel
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_NonPromo_Finish
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_NonPromo_Pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_NonPromo_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_NonPromo_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_Promo_Cancel
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_Promo_Finish
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_Promo_Pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_Promo_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Engaged_Promo_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_NonPromo_Cancel
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_NonPromo_Finish
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_NonPromo_Pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_NonPromo_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_NonPromo_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_Promo_Cancel
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_Promo_Finish
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_Promo_Pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_Promo_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Med_Engaged_Promo_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_NonPromo_Cancel
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_NonPromo_Finish
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_NonPromo_Pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_NonPromo_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_NonPromo_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_Promo_Cancel
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_Promo_Finish
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_Promo_Pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_Promo_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Not_Engaged_Promo_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_NonPromo_Cancel
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_NonPromo_Finish
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_NonPromo_Pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_NonPromo_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_NonPromo_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_Promo_Cancel
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_Promo_Finish
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_Promo_Pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_Promo_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    J_Post_Onboarding_Promo_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lend and sale_FS_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lend and sale_Sale_FS_stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lendandsale51ron
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lendandsale51ron-expired
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lendandsale51ron-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lending start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lending stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lending2_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lending2_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lending_Start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Lending_Stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_cancelled
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_cancelled_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_finished
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_finished_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_pause_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_start_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lnoo_stop_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Loyalty - Tier 1
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Loyalty - Tier 2
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Loyalty - Tier 3
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Loyalty Gold
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Loyalty Kit Discount 51 RON
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Loyalty Platinum
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Loyalty Silver
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_cancelled
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_cancelled_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_finished
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_finished_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_pause_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_start_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    lroi_stop_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_cancelled
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_cancelled_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_finished
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_finished_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_pause_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_start_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoi_stop_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_cancelled
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_cancelled_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_finished
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_finished
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_finished_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_pause
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_pause_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_start
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_start_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_stop
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ltoo_stop_pre
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Medengaged- 3duo&amp;2.4+
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Medengaged- 3duo&amp;2.4+-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Medengaged-duopromo
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Medengaged-duopromo-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ME_30RonOff
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ME_30RonOff-expired
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ME_30RonOff-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ME_50RonOffHeets
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ME_50RonOffHeets-expired
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ME_50RonOffHeets-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    NE_20off1MixCRT
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    NE_20off1MixCRT-Expired
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    NE_20off1MixCRT-Used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    OPS
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    PM IQOS 2.4+
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Preorder1
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    PROFILING
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea 50 RON
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea 50 RON - used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea 50 RON- expired
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea2 50 RON
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea2 50 RON- expired
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea2 50 RON-used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea_1
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea_1B
                                            
                    
                                                                                                    
                            
            
                        Active
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea_1Sub
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea_2
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea_3
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea_3Club
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Promisiunea_4
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Prom_ONB_Canceled
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Prom_ONB_Finished
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Qonsultance - graduate
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    quiz - discount 10%
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    quiz - discount 10% - used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    quiz - discount 15%
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    quiz - discount 15% - used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    quiz - discount 20%
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    quiz - discount 20% - used
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    QURE Blacklisted
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    QURE Manual Blacklisted
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    QURE Testing
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Sah mat la fumat
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    SK Bronze
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    SKUserAccessories50
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    SM - Accessories
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    SM - Upgrade Kits
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    SM - Voucher 17 RON
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    SM - Voucher 17 RON - USED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    SM - Voucher 30 RON
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    SM - Voucher 30 RON - USED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Starter
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Starter Kit
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    Test Recomanda IQOS
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TestUpdate
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    testvladremove
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    test_85
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    tesUGptVladis
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS 2.4+ 49
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS 2.4+ 49 EXPIRED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS 2.4+ 49 USED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS DUO 199
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS DUO 199 EXPIRED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS DUO 199 USED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS DUO 249
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS DUO 249 EXPIRED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS DUO 249 USED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS MULTI 99
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS MULTI 99 EXPIRED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TR IQOS MULTI 99 USED
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    TradeIn
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    UGTEST
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    user group hostess limited
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                            
                    
                                                    ValentinesDay
                                            
                    
                                                                                                    
                            
            
                        Available
                            
        
                                    
                                                                                            Active
                                Pending
                                Available
                                Declined
                                                    
                                        
                                                
                    
                        
                        Notify customer
                    
                                                                

            
            


            
            
                    
            

                        

                    
                
                    
    

                
            		                            
                        
        
                            
    Visits statistic
    


                

                    
                        Registration date:
                        
                                                            24/02/2020 14:23
                                                    
                    

                    
                        First login:
                        
                                                            24/02/2020 14:23
                                                    
                    

                    
                        Last login:
                        
                                                            24/02/2020 16:21
                                                    
                    

                    
                        Number visits:
                        
                            2
                        
                    

                    
                        Number visits this year:
                        
                            0
                        
                    

                    
                        Number visits last 3 months:
                        
                            0
                        
                    

                    
                        Number visits this month:
                        
                            0
                        
                    

                    
                        Number visits this week:
                        
                            0
                        
                    

                    
                        Number visits today:
                        
                            0
                        
                    
                
            
                            
    Orders statistic
    


                
                    
                        Number of orders:
                        
                            2
                        
                    

                    
                        Number of orders by status:
                        
                            Shipped Total (2)
                        
                    

                    
                        Average shopping cart:
                        
                            
        359 RON

                        
                    

                    
                        Order total amount:
                        
                            
        718 RON

                        
                    

                    
                        Order total this year:
                        
                            
        0 RON

                        
                    

                    
                        Order total last 3 months:
                        
                            
        0 RON

                        
                    

                    
                        Order total this month:
                        
                            
        0 RON

                        
                    

                    
                        Order total this week:
                        
                            
        0 RON

                        
                    
                
            
            
                            
    Marketing indicators
    


                
                    
                        Is customer activity status:
                        
                            Pending
                        
                    

                    
                        Sleeping shopping cart content:
                        
                            - 
                        
                    

                    
                        Customer rank:
                        
                            1157 of 2716
                        
                    

                    
                        Last products purchased:
                        
                            Starter Kit IQOS 3 DUO Warm White
                        
                    

                    
                        Last category purchased:
                        
                            Starter Kit IQOS 3 Duo
                        
                    

                    
                        Last order date:
                        
                            24/02/2020
                        
                    

                    
                        Number of newsletter campaign received:
                        
                            0
                        
                    
                
                        

                
            		                            
                    
	Referral Program
			Empty
	
                
            		                            
                    
                
            			



//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
                    });
}(Tygh, Tygh.$));
//]]>

   
    
                                


 
     Profile checked
    


            
            //&lt;![CDATA[
            (function(_, $) {
                $(document).ready(function() {
                    $.scrollToElm($('#block_issues'));
                });
            }(Tygh, Tygh.$));
            //]]>
            
            
    


                
//&lt;![CDATA[
(function(_, $) {

    /* Do not put this code to document.ready, because it should be
       initialized first
    */
    $.ceRebuildStates('init', {
        default_country: 'RO',
        states: {&quot;&quot;:[{&quot;country_code&quot;:&quot;&quot;,&quot;code&quot;:&quot;CONSTANTA&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;}],&quot;AU&quot;:[{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;ACT&quot;,&quot;state&quot;:&quot;Australian Capital Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NSW&quot;,&quot;state&quot;:&quot;New South Wales&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northern Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;QLD&quot;,&quot;state&quot;:&quot;Queensland&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;South Australia&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;TAS&quot;,&quot;state&quot;:&quot;Tasmania&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;VIC&quot;,&quot;state&quot;:&quot;Victoria&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Western Australia&quot;}],&quot;BG&quot;:[{&quot;country_code&quot;:&quot;BG&quot;,&quot;code&quot;:&quot;SF&quot;,&quot;state&quot;:&quot;Sofia&quot;}],&quot;CA&quot;:[{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Alberta&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;British Columbia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;MB&quot;,&quot;state&quot;:&quot;Manitoba&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;New Brunswick&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NL&quot;,&quot;state&quot;:&quot;Newfoundland and Labrador&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northwest Territories&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NS&quot;,&quot;state&quot;:&quot;Nova Scotia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nunavut&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;ON&quot;,&quot;state&quot;:&quot;Ontario&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Prince Edward Island&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;QC&quot;,&quot;state&quot;:&quot;Quebec&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;SK&quot;,&quot;state&quot;:&quot;Saskatchewan&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;YT&quot;,&quot;state&quot;:&quot;Yukon&quot;}],&quot;CH&quot;:[{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Ext\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AI&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Int\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Argovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;B\u00e2le-Campagne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;B\u00e2le-Ville&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BE&quot;,&quot;state&quot;:&quot;Berne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Fribourg&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gen\u00e8ve&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;Glaris&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grisons&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;JU&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucerne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Neuch\u00e2tel&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NW&quot;,&quot;state&quot;:&quot;Nidwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;OW&quot;,&quot;state&quot;:&quot;Obwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Saint-Gall&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SH&quot;,&quot;state&quot;:&quot;Schaffhouse&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SZ&quot;,&quot;state&quot;:&quot;Schwytz&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soleure&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TI&quot;,&quot;state&quot;:&quot;Tessin&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TG&quot;,&quot;state&quot;:&quot;Thurgovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;UR&quot;,&quot;state&quot;:&quot;Uri&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Valais&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VD&quot;,&quot;state&quot;:&quot;Vaud&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZG&quot;,&quot;state&quot;:&quot;Zoug&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zurich&quot;}],&quot;DE&quot;:[{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAW&quot;,&quot;state&quot;:&quot;Baden-W\u00fcrttemberg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAY&quot;,&quot;state&quot;:&quot;Bayern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BER&quot;,&quot;state&quot;:&quot;Berlin&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRG&quot;,&quot;state&quot;:&quot;Branderburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRE&quot;,&quot;state&quot;:&quot;Bremen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HAM&quot;,&quot;state&quot;:&quot;Hamburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HES&quot;,&quot;state&quot;:&quot;Hessen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;MEC&quot;,&quot;state&quot;:&quot;Mecklenburg-Vorpommern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NDS&quot;,&quot;state&quot;:&quot;Niedersachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NRW&quot;,&quot;state&quot;:&quot;Nordrhein-Westfalen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;RHE&quot;,&quot;state&quot;:&quot;Rheinland-Pfalz&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saarland&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAS&quot;,&quot;state&quot;:&quot;Sachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAC&quot;,&quot;state&quot;:&quot;Sachsen-Anhalt&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SCN&quot;,&quot;state&quot;:&quot;Schleswig-Holstein&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;THE&quot;,&quot;state&quot;:&quot;Th\u00fcringen&quot;}],&quot;ES&quot;:[{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;C&quot;,&quot;state&quot;:&quot;A Coru\u00f1a&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;\u00c1lava&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Albacete&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;A&quot;,&quot;state&quot;:&quot;Alicante&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Almer\u00eda&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;O&quot;,&quot;state&quot;:&quot;Asturias&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;\u00c1vila&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Badajoz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PM&quot;,&quot;state&quot;:&quot;Baleares&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;Barcelona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Burgos&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CC&quot;,&quot;state&quot;:&quot;C\u00e1ceres&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;C\u00e1diz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;S&quot;,&quot;state&quot;:&quot;Cantabria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Castell\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Ceuta&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Ciudad Real&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;C\u00f3rdoba&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Cuenca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GI&quot;,&quot;state&quot;:&quot;Girona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Granada&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guadalajara&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Guip\u00fazcoa&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;H&quot;,&quot;state&quot;:&quot;Huelva&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;HU&quot;,&quot;state&quot;:&quot;Huesca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;J&quot;,&quot;state&quot;:&quot;Ja\u00e9n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;La Rioja&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GC&quot;,&quot;state&quot;:&quot;Las Palmas&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Le\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;L&quot;,&quot;state&quot;:&quot;Lleida&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lugo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;M&quot;,&quot;state&quot;:&quot;Madrid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;M\u00e1laga&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ML&quot;,&quot;state&quot;:&quot;Melilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MU&quot;,&quot;state&quot;:&quot;Murcia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Navarra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Ourense&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;P&quot;,&quot;state&quot;:&quot;Palencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Pontevedra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salamanca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TF&quot;,&quot;state&quot;:&quot;Santa Cruz de Tenerife&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Segovia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Sevilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;T&quot;,&quot;state&quot;:&quot;Tarragona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teruel&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Toledo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;V&quot;,&quot;state&quot;:&quot;Valencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Valladolid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Vizcaya&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ZA&quot;,&quot;state&quot;:&quot;Zamora&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;Z&quot;,&quot;state&quot;:&quot;Zaragoza&quot;}],&quot;FR&quot;:[{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;01&quot;,&quot;state&quot;:&quot;Ain&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;02&quot;,&quot;state&quot;:&quot;Aisne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;03&quot;,&quot;state&quot;:&quot;Allier&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;04&quot;,&quot;state&quot;:&quot;Alpes-de-Haute-Provence&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;06&quot;,&quot;state&quot;:&quot;Alpes-Maritimes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;07&quot;,&quot;state&quot;:&quot;Ard\u00e8che&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;08&quot;,&quot;state&quot;:&quot;Ardennes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;09&quot;,&quot;state&quot;:&quot;Ari\u00e8ge&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;10&quot;,&quot;state&quot;:&quot;Aube&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;11&quot;,&quot;state&quot;:&quot;Aude&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;12&quot;,&quot;state&quot;:&quot;Aveyron&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;67&quot;,&quot;state&quot;:&quot;Bas-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;13&quot;,&quot;state&quot;:&quot;Bouches-du-Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;14&quot;,&quot;state&quot;:&quot;Calvados&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;15&quot;,&quot;state&quot;:&quot;Cantal&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;16&quot;,&quot;state&quot;:&quot;Charente&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;17&quot;,&quot;state&quot;:&quot;Charente-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;18&quot;,&quot;state&quot;:&quot;Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;19&quot;,&quot;state&quot;:&quot;Corr\u00e8ze&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2A&quot;,&quot;state&quot;:&quot;Corse-du-Sud&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;21&quot;,&quot;state&quot;:&quot;C\u00f4te-d'Or&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;22&quot;,&quot;state&quot;:&quot;C\u00f4tes-d'Armor&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;23&quot;,&quot;state&quot;:&quot;Creuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;79&quot;,&quot;state&quot;:&quot;Deux-S\u00e8vres&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;24&quot;,&quot;state&quot;:&quot;Dordogne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;25&quot;,&quot;state&quot;:&quot;Doubs&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;26&quot;,&quot;state&quot;:&quot;Dr\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;91&quot;,&quot;state&quot;:&quot;Essonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;27&quot;,&quot;state&quot;:&quot;Eure&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;28&quot;,&quot;state&quot;:&quot;Eure-et-Loir&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;29&quot;,&quot;state&quot;:&quot;Finist\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;30&quot;,&quot;state&quot;:&quot;Gard&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;32&quot;,&quot;state&quot;:&quot;Gers&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;33&quot;,&quot;state&quot;:&quot;Gironde&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;68&quot;,&quot;state&quot;:&quot;Haut-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2B&quot;,&quot;state&quot;:&quot;Haute-Corse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;31&quot;,&quot;state&quot;:&quot;Haute-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;43&quot;,&quot;state&quot;:&quot;Haute-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;52&quot;,&quot;state&quot;:&quot;Haute-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;70&quot;,&quot;state&quot;:&quot;Haute-Sa\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;74&quot;,&quot;state&quot;:&quot;Haute-Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;87&quot;,&quot;state&quot;:&quot;Haute-Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;05&quot;,&quot;state&quot;:&quot;Hautes-Alpes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;65&quot;,&quot;state&quot;:&quot;Hautes-Pyr\u00e9n\u00e9es&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;92&quot;,&quot;state&quot;:&quot;Hauts-de-Seine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;34&quot;,&quot;state&quot;:&quot;H\u00e9rault&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;35&quot;,&quot;state&quot;:&quot;Ille-et-Vilaine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;36&quot;,&quot;state&quot;:&quot;Indre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;37&quot;,&quot;state&quot;:&quot;Indre-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;38&quot;,&quot;state&quot;:&quot;Is\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;39&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;40&quot;,&quot;state&quot;:&quot;Landes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;41&quot;,&quot;state&quot;:&quot;Loir-et-Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;42&quot;,&quot;state&quot;:&quot;Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;44&quot;,&quot;state&quot;:&quot;Loire-Atlantique&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;45&quot;,&quot;state&quot;:&quot;Loiret&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;46&quot;,&quot;state&quot;:&quot;Lot&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;47&quot;,&quot;state&quot;:&quot;Lot-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;48&quot;,&quot;state&quot;:&quot;Loz\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;49&quot;,&quot;state&quot;:&quot;Maine-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;50&quot;,&quot;state&quot;:&quot;Manche&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;51&quot;,&quot;state&quot;:&quot;Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;53&quot;,&quot;state&quot;:&quot;Mayenne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;54&quot;,&quot;state&quot;:&quot;Meurthe-et-Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;55&quot;,&quot;state&quot;:&quot;Meuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;56&quot;,&quot;state&quot;:&quot;Morbihan&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;57&quot;,&quot;state&quot;:&quot;Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;58&quot;,&quot;state&quot;:&quot;Ni\u00e8vre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;59&quot;,&quot;state&quot;:&quot;Nord&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;60&quot;,&quot;state&quot;:&quot;Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;61&quot;,&quot;state&quot;:&quot;Orne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;75&quot;,&quot;state&quot;:&quot;Paris&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;62&quot;,&quot;state&quot;:&quot;Pas-de-Calais&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;63&quot;,&quot;state&quot;:&quot;Puy-de-D\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;64&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Atlantiques&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;66&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Orientales&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;69&quot;,&quot;state&quot;:&quot;Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;71&quot;,&quot;state&quot;:&quot;Sa\u00f4ne-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;72&quot;,&quot;state&quot;:&quot;Sarthe&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;73&quot;,&quot;state&quot;:&quot;Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;77&quot;,&quot;state&quot;:&quot;Seine-et-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;76&quot;,&quot;state&quot;:&quot;Seine-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;93&quot;,&quot;state&quot;:&quot;Seine-Saint-Denis&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;80&quot;,&quot;state&quot;:&quot;Somme&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;81&quot;,&quot;state&quot;:&quot;Tarn&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;82&quot;,&quot;state&quot;:&quot;Tarn-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;90&quot;,&quot;state&quot;:&quot;Territoire de Belfort&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;95&quot;,&quot;state&quot;:&quot;Val-d'Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;94&quot;,&quot;state&quot;:&quot;Val-de-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;83&quot;,&quot;state&quot;:&quot;Var&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;84&quot;,&quot;state&quot;:&quot;Vaucluse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;85&quot;,&quot;state&quot;:&quot;Vend\u00e9e&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;86&quot;,&quot;state&quot;:&quot;Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;88&quot;,&quot;state&quot;:&quot;Vosges&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;89&quot;,&quot;state&quot;:&quot;Yonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;78&quot;,&quot;state&quot;:&quot;Yvelines&quot;}],&quot;GB&quot;:[{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABN&quot;,&quot;state&quot;:&quot;Aberdeen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABNS&quot;,&quot;state&quot;:&quot;Aberdeenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANG&quot;,&quot;state&quot;:&quot;Anglesey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AGS&quot;,&quot;state&quot;:&quot;Angus&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARY&quot;,&quot;state&quot;:&quot;Argyll and Bute&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AVN&quot;,&quot;state&quot;:&quot;Avon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BAN&quot;,&quot;state&quot;:&quot;Banffshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEDS&quot;,&quot;state&quot;:&quot;Bedfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BERKS&quot;,&quot;state&quot;:&quot;Berkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEW&quot;,&quot;state&quot;:&quot;Berwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BLA&quot;,&quot;state&quot;:&quot;Blaenau Gwent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BRI&quot;,&quot;state&quot;:&quot;Bridgend&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BSTL&quot;,&quot;state&quot;:&quot;Bristol&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BUCKS&quot;,&quot;state&quot;:&quot;Buckinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAE&quot;,&quot;state&quot;:&quot;Caerphilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAI&quot;,&quot;state&quot;:&quot;Caithness&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAMBS&quot;,&quot;state&quot;:&quot;Cambridgeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDF&quot;,&quot;state&quot;:&quot;Cardiff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CARM&quot;,&quot;state&quot;:&quot;Carmarthenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDGN&quot;,&quot;state&quot;:&quot;Ceredigion&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CHES&quot;,&quot;state&quot;:&quot;Cheshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLACK&quot;,&quot;state&quot;:&quot;Clackmannanshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLV&quot;,&quot;state&quot;:&quot;Cleveland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CWD&quot;,&quot;state&quot;:&quot;Clwyd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CON&quot;,&quot;state&quot;:&quot;Conwy&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CORN&quot;,&quot;state&quot;:&quot;Cornwall&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANT&quot;,&quot;state&quot;:&quot;County Antrim&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARM&quot;,&quot;state&quot;:&quot;County Armagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOW&quot;,&quot;state&quot;:&quot;County Down&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FER&quot;,&quot;state&quot;:&quot;County Fermanagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDY&quot;,&quot;state&quot;:&quot;County Londonderry&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TYR&quot;,&quot;state&quot;:&quot;County Tyrone&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CMA&quot;,&quot;state&quot;:&quot;Cumbria&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DNBG&quot;,&quot;state&quot;:&quot;Denbighshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DERBY&quot;,&quot;state&quot;:&quot;Derbyshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DVN&quot;,&quot;state&quot;:&quot;Devon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOR&quot;,&quot;state&quot;:&quot;Dorset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DGL&quot;,&quot;state&quot;:&quot;Dumfries and Galloway&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFS&quot;,&quot;state&quot;:&quot;Dumfries-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUND&quot;,&quot;state&quot;:&quot;Dundee&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DHM&quot;,&quot;state&quot;:&quot;Durham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFD&quot;,&quot;state&quot;:&quot;Dyfed&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYE&quot;,&quot;state&quot;:&quot;East Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUNBE&quot;,&quot;state&quot;:&quot;East Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LOTE&quot;,&quot;state&quot;:&quot;East Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RENE&quot;,&quot;state&quot;:&quot;East Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ERYS&quot;,&quot;state&quot;:&quot;East Riding of Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXE&quot;,&quot;state&quot;:&quot;East Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;EDIN&quot;,&quot;state&quot;:&quot;Edinburgh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ESX&quot;,&quot;state&quot;:&quot;Essex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FALK&quot;,&quot;state&quot;:&quot;Falkirk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FFE&quot;,&quot;state&quot;:&quot;Fife&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FLINT&quot;,&quot;state&quot;:&quot;Flintshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLAS&quot;,&quot;state&quot;:&quot;Glasgow&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLOS&quot;,&quot;state&quot;:&quot;Gloucestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDN&quot;,&quot;state&quot;:&quot;Greater London&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MCH&quot;,&quot;state&quot;:&quot;Greater Manchester&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GDD&quot;,&quot;state&quot;:&quot;Gwynedd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HANTS&quot;,&quot;state&quot;:&quot;Hampshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HWR&quot;,&quot;state&quot;:&quot;Herefordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HERTS&quot;,&quot;state&quot;:&quot;Hertfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HLD&quot;,&quot;state&quot;:&quot;Highlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HUM&quot;,&quot;state&quot;:&quot;Humberside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IVER&quot;,&quot;state&quot;:&quot;Inverclyde&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;INV&quot;,&quot;state&quot;:&quot;Inverness-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOW&quot;,&quot;state&quot;:&quot;Isle of Wight&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOS&quot;,&quot;state&quot;:&quot;Isles of Scilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KNT&quot;,&quot;state&quot;:&quot;Kent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KCD&quot;,&quot;state&quot;:&quot;Kincardineshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANCS&quot;,&quot;state&quot;:&quot;Lancashire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LEICS&quot;,&quot;state&quot;:&quot;Leicestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LINCS&quot;,&quot;state&quot;:&quot;Lincolnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MER&quot;,&quot;state&quot;:&quot;Merionethshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MSY&quot;,&quot;state&quot;:&quot;Merseyside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MERT&quot;,&quot;state&quot;:&quot;Merthyr Tydfil&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MDX&quot;,&quot;state&quot;:&quot;Middlesex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MLOT&quot;,&quot;state&quot;:&quot;Midlothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MMOUTH&quot;,&quot;state&quot;:&quot;Monmouthshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MORAY&quot;,&quot;state&quot;:&quot;Moray&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NAI&quot;,&quot;state&quot;:&quot;Nairnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NPRTAL&quot;,&quot;state&quot;:&quot;Neath Port Talbot&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NEWPT&quot;,&quot;state&quot;:&quot;Newport&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOR&quot;,&quot;state&quot;:&quot;Norfolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYN&quot;,&quot;state&quot;:&quot;North Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANN&quot;,&quot;state&quot;:&quot;North Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSN&quot;,&quot;state&quot;:&quot;North Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NHM&quot;,&quot;state&quot;:&quot;Northamptonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NLD&quot;,&quot;state&quot;:&quot;Northumberland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOT&quot;,&quot;state&quot;:&quot;Nottinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ORK&quot;,&quot;state&quot;:&quot;Orkney Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;OFE&quot;,&quot;state&quot;:&quot;Oxfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEE&quot;,&quot;state&quot;:&quot;Peebles-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEM&quot;,&quot;state&quot;:&quot;Pembrokeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PERTH&quot;,&quot;state&quot;:&quot;Perth and Kinross&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PWS&quot;,&quot;state&quot;:&quot;Powys&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;REN&quot;,&quot;state&quot;:&quot;Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RHON&quot;,&quot;state&quot;:&quot;Rhondda Cynon Taff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ROX&quot;,&quot;state&quot;:&quot;Roxburghshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RUT&quot;,&quot;state&quot;:&quot;Rutland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BOR&quot;,&quot;state&quot;:&quot;Scottish Borders&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SEL&quot;,&quot;state&quot;:&quot;Selkirkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SHET&quot;,&quot;state&quot;:&quot;Shetland Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Shropshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SOM&quot;,&quot;state&quot;:&quot;Somerset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYS&quot;,&quot;state&quot;:&quot;South Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANS&quot;,&quot;state&quot;:&quot;South Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SYK&quot;,&quot;state&quot;:&quot;South Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFD&quot;,&quot;state&quot;:&quot;Staffordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STIR&quot;,&quot;state&quot;:&quot;Stirling&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STI&quot;,&quot;state&quot;:&quot;Stirlingshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFK&quot;,&quot;state&quot;:&quot;Suffolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SRY&quot;,&quot;state&quot;:&quot;Surrey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SUT&quot;,&quot;state&quot;:&quot;Sutherland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SWAN&quot;,&quot;state&quot;:&quot;Swansea&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TORF&quot;,&quot;state&quot;:&quot;Torfaen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TWR&quot;,&quot;state&quot;:&quot;Tyne and Wear&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;VGLAM&quot;,&quot;state&quot;:&quot;Vale of Glamorgan&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WARKS&quot;,&quot;state&quot;:&quot;Warwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WDUN&quot;,&quot;state&quot;:&quot;West Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLOT&quot;,&quot;state&quot;:&quot;West Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WMD&quot;,&quot;state&quot;:&quot;West Midlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXW&quot;,&quot;state&quot;:&quot;West Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSW&quot;,&quot;state&quot;:&quot;West Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIL&quot;,&quot;state&quot;:&quot;Western Isles&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIG&quot;,&quot;state&quot;:&quot;Wigtownshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLT&quot;,&quot;state&quot;:&quot;Wiltshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WORCS&quot;,&quot;state&quot;:&quot;Worcestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WRX&quot;,&quot;state&quot;:&quot;Wrexham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YKS&quot;,&quot;state&quot;:&quot;Yorkshire&quot;}],&quot;IT&quot;:[{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Agrigento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alessandria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AN&quot;,&quot;state&quot;:&quot;Ancona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AO&quot;,&quot;state&quot;:&quot;Aosta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arezzo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AP&quot;,&quot;state&quot;:&quot;Ascoli Piceno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AT&quot;,&quot;state&quot;:&quot;Asti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;Avellino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Bari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;Belluno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;Benevento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BG&quot;,&quot;state&quot;:&quot;Bergamo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Biella&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BO&quot;,&quot;state&quot;:&quot;Bologna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;Bolzano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;Brescia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;Brindisi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;Cagliari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;Caltanissetta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CB&quot;,&quot;state&quot;:&quot;Campobasso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CI&quot;,&quot;state&quot;:&quot;Carbonia-Iglesias&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Caserta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Catania&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CZ&quot;,&quot;state&quot;:&quot;Catanzaro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CH&quot;,&quot;state&quot;:&quot;Chieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Como&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Cosenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Cremona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Crotone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CN&quot;,&quot;state&quot;:&quot;Cuneo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;EN&quot;,&quot;state&quot;:&quot;Enna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FE&quot;,&quot;state&quot;:&quot;Ferrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FI&quot;,&quot;state&quot;:&quot;Firenze&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FG&quot;,&quot;state&quot;:&quot;Foggia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FC&quot;,&quot;state&quot;:&quot;Forli-Cesena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Frosinone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Genova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GO&quot;,&quot;state&quot;:&quot;Gorizia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grosseto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IM&quot;,&quot;state&quot;:&quot;Imperia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;Isernia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AQ&quot;,&quot;state&quot;:&quot;L'Aquila&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SP&quot;,&quot;state&quot;:&quot;La Spezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LT&quot;,&quot;state&quot;:&quot;Latina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Lecce&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LC&quot;,&quot;state&quot;:&quot;Lecco&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Livorno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;Lodi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucca&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MC&quot;,&quot;state&quot;:&quot;Macerata&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Mantova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Massa-Carrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Matera&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Medio Campidano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Messina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Milano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Modena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Napoli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NO&quot;,&quot;state&quot;:&quot;Novara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nuoro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OG&quot;,&quot;state&quot;:&quot;Ogliastra&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;Olbia-Tempio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oristano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PD&quot;,&quot;state&quot;:&quot;Padova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Palermo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Parma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PV&quot;,&quot;state&quot;:&quot;Pavia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PG&quot;,&quot;state&quot;:&quot;Perugia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PU&quot;,&quot;state&quot;:&quot;Pesaro e Urbino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Pescara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PC&quot;,&quot;state&quot;:&quot;Piacenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PI&quot;,&quot;state&quot;:&quot;Pisa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PT&quot;,&quot;state&quot;:&quot;Pistoia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PN&quot;,&quot;state&quot;:&quot;Pordenone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PZ&quot;,&quot;state&quot;:&quot;Potenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Prato&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RG&quot;,&quot;state&quot;:&quot;Ragusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RA&quot;,&quot;state&quot;:&quot;Ravenna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RC&quot;,&quot;state&quot;:&quot;Reggio Calabria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RE&quot;,&quot;state&quot;:&quot;Reggio Emilia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RN&quot;,&quot;state&quot;:&quot;Rimini&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RM&quot;,&quot;state&quot;:&quot;Roma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RO&quot;,&quot;state&quot;:&quot;Rovigo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salerno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Sassari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;Savona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SI&quot;,&quot;state&quot;:&quot;Siena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SR&quot;,&quot;state&quot;:&quot;Siracusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Sondrio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Taranto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teramo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;Terni&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Torino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TP&quot;,&quot;state&quot;:&quot;Trapani&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Trento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TV&quot;,&quot;state&quot;:&quot;Treviso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TS&quot;,&quot;state&quot;:&quot;Trieste&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udine&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Varese&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VE&quot;,&quot;state&quot;:&quot;Venezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VB&quot;,&quot;state&quot;:&quot;Verbano-Cusio-Ossola&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VC&quot;,&quot;state&quot;:&quot;Vercelli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VR&quot;,&quot;state&quot;:&quot;Verona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VV&quot;,&quot;state&quot;:&quot;Vibo Valentia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Vicenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Viterbo&quot;}],&quot;JP&quot;:[{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AICHI&quot;,&quot;state&quot;:&quot;AICHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AKITA&quot;,&quot;state&quot;:&quot;AKITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AOMORI&quot;,&quot;state&quot;:&quot;AOMORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;CHIBA&quot;,&quot;state&quot;:&quot;CHIBA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;EHIME&quot;,&quot;state&quot;:&quot;EHIME&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUI&quot;,&quot;state&quot;:&quot;FUKUI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUOKA&quot;,&quot;state&quot;:&quot;FUKUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUSHIMA&quot;,&quot;state&quot;:&quot;FUKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GIFU&quot;,&quot;state&quot;:&quot;GIFU&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GUMMA&quot;,&quot;state&quot;:&quot;GUMMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HIROSHIMA&quot;,&quot;state&quot;:&quot;HIROSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HOKKAIDO&quot;,&quot;state&quot;:&quot;HOKKAIDO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HYOGO&quot;,&quot;state&quot;:&quot;HYOGO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IBARAKI&quot;,&quot;state&quot;:&quot;IBARAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;ISHIKAWA&quot;,&quot;state&quot;:&quot;ISHIKAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IWATE&quot;,&quot;state&quot;:&quot;IWATE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGAWA&quot;,&quot;state&quot;:&quot;KAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGOSHIMA&quot;,&quot;state&quot;:&quot;KAGOSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KANAGAWA&quot;,&quot;state&quot;:&quot;KANAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KOCHI&quot;,&quot;state&quot;:&quot;KOCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KUMAMOTO&quot;,&quot;state&quot;:&quot;KUMAMOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KYOTO&quot;,&quot;state&quot;:&quot;KYOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIE&quot;,&quot;state&quot;:&quot;MIE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAGI&quot;,&quot;state&quot;:&quot;MIYAGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAZAKI&quot;,&quot;state&quot;:&quot;MIYAZAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGANO&quot;,&quot;state&quot;:&quot;NAGANO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGASAKI&quot;,&quot;state&quot;:&quot;NAGASAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NARA&quot;,&quot;state&quot;:&quot;NARA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NIIGATA&quot;,&quot;state&quot;:&quot;NIIGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OITA&quot;,&quot;state&quot;:&quot;OITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKAYAMA&quot;,&quot;state&quot;:&quot;OKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKINAWA&quot;,&quot;state&quot;:&quot;OKINAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OSAKA&quot;,&quot;state&quot;:&quot;OSAKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAGA&quot;,&quot;state&quot;:&quot;SAGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAITAMA&quot;,&quot;state&quot;:&quot;SAITAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIGA&quot;,&quot;state&quot;:&quot;SHIGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIMANE&quot;,&quot;state&quot;:&quot;SHIMANE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIZUOKA&quot;,&quot;state&quot;:&quot;SHIZUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOCHIGI&quot;,&quot;state&quot;:&quot;TOCHIGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKUSHIMA&quot;,&quot;state&quot;:&quot;TOKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKYO&quot;,&quot;state&quot;:&quot;TOKYO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOTTORI&quot;,&quot;state&quot;:&quot;TOTTORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOYAMA&quot;,&quot;state&quot;:&quot;TOYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;WAKAYAMA&quot;,&quot;state&quot;:&quot;WAKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGATA&quot;,&quot;state&quot;:&quot;YAMAGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGUCHI&quot;,&quot;state&quot;:&quot;YAMAGUCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMANASHI&quot;,&quot;state&quot;:&quot;YAMANASHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4e09\u91cd\u770c&quot;,&quot;state&quot;:&quot;\u4e09\u91cd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4eac\u90fd\u5e9c&quot;,&quot;state&quot;:&quot;\u4eac\u90fd\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4f50\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u4f50\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5175\u5eab\u770c&quot;,&quot;state&quot;:&quot;\u5175\u5eab\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5317\u6d77\u9053&quot;,&quot;state&quot;:&quot;\u5317\u6d77\u9053&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5343\u8449\u770c&quot;,&quot;state&quot;:&quot;\u5343\u8449\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u57fc\u7389\u770c&quot;,&quot;state&quot;:&quot;\u57fc\u7389\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u5206\u770c&quot;,&quot;state&quot;:&quot;\u5927\u5206\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u962a\u5e9c&quot;,&quot;state&quot;:&quot;\u5927\u962a\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5948\u826f\u770c&quot;,&quot;state&quot;:&quot;\u5948\u826f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bcc\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5bcc\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u53e3\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u53e3\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u5f62\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u5f62\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u68a8\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u68a8\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c90\u961c\u770c&quot;,&quot;state&quot;:&quot;\u5c90\u961c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca1\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5ca1\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca9\u624b\u770c&quot;,&quot;state&quot;:&quot;\u5ca9\u624b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5cf6\u6839\u770c&quot;,&quot;state&quot;:&quot;\u5cf6\u6839\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5e83\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5e83\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5fb3\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5fb3\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u5a9b\u770c&quot;,&quot;state&quot;:&quot;\u611b\u5a9b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u611b\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u65b0\u6f5f\u770c&quot;,&quot;state&quot;:&quot;\u65b0\u6f5f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6771\u4eac\u90fd&quot;,&quot;state&quot;:&quot;\u6771\u4eac\u90fd&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6803\u6728\u770c&quot;,&quot;state&quot;:&quot;\u6803\u6728\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6c96\u7e04\u770c&quot;,&quot;state&quot;:&quot;\u6c96\u7e04\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6ecb\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u6ecb\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u718a\u672c\u770c&quot;,&quot;state&quot;:&quot;\u718a\u672c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u77f3\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u77f3\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u4e95\u770c&quot;,&quot;state&quot;:&quot;\u798f\u4e95\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u79cb\u7530\u770c&quot;,&quot;state&quot;:&quot;\u79cb\u7530\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u7fa4\u99ac\u770c&quot;,&quot;state&quot;:&quot;\u7fa4\u99ac\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u8328\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u8328\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u9577\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u91ce\u770c&quot;,&quot;state&quot;:&quot;\u9577\u91ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9752\u68ee\u770c&quot;,&quot;state&quot;:&quot;\u9752\u68ee\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9759\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u9759\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9999\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u9999\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ad8\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u9ad8\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ce5\u53d6\u770c&quot;,&quot;state&quot;:&quot;\u9ce5\u53d6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;}],&quot;NL&quot;:[{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;DR&quot;,&quot;state&quot;:&quot;Drenthe&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Flevoland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Friesland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gelderland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Groningen&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Limburg&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;Noord Brabant&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;Noord Holland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;OV&quot;,&quot;state&quot;:&quot;Overijssel&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utrecht&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZE&quot;,&quot;state&quot;:&quot;Zeeland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zuid Holland&quot;}],&quot;RO&quot;:[{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;ALBA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;ARAD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;ARGES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;BACAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BH&quot;,&quot;state&quot;:&quot;BIHOR&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;BISTRITA-NASAUD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BT&quot;,&quot;state&quot;:&quot;BOTOSANI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;BRAILA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BV&quot;,&quot;state&quot;:&quot;BRASOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;BUCURESTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;BUZAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;CALARASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;CARAS-SEVERIN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CJ&quot;,&quot;state&quot;:&quot;CLUJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CV&quot;,&quot;state&quot;:&quot;COVASNA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DB&quot;,&quot;state&quot;:&quot;DAMBOVITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DJ&quot;,&quot;state&quot;:&quot;DOLJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;GALATI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;GIURGIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GJ&quot;,&quot;state&quot;:&quot;GORJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HR&quot;,&quot;state&quot;:&quot;HARGHITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HD&quot;,&quot;state&quot;:&quot;HUNEDOARA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;IALOMITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;IASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IF&quot;,&quot;state&quot;:&quot;ILFOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MM&quot;,&quot;state&quot;:&quot;MARAMURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MH&quot;,&quot;state&quot;:&quot;MEHEDINTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;MURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;NEAMT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;OLT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;PH&quot;,&quot;state&quot;:&quot;PRAHOVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SJ&quot;,&quot;state&quot;:&quot;SALAJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SM&quot;,&quot;state&quot;:&quot;SATU MARE&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SB&quot;,&quot;state&quot;:&quot;SIBIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;SUCEAVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;TELEORMAN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TM&quot;,&quot;state&quot;:&quot;TIMIS&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TL&quot;,&quot;state&quot;:&quot;TULCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VL&quot;,&quot;state&quot;:&quot;VALCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;VASLUI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VN&quot;,&quot;state&quot;:&quot;VRANCEA&quot;}],&quot;RU&quot;:[{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ALT&quot;,&quot;state&quot;:&quot;Altajskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AMU&quot;,&quot;state&quot;:&quot;Amurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ARK&quot;,&quot;state&quot;:&quot;Arhangel'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AST&quot;,&quot;state&quot;:&quot;Astrahanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BEL&quot;,&quot;state&quot;:&quot;Belgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BRY&quot;,&quot;state&quot;:&quot;Brjanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Chechenskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHE&quot;,&quot;state&quot;:&quot;Cheljabinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHU&quot;,&quot;state&quot;:&quot;Chukotskij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Chuvashskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YEV&quot;,&quot;state&quot;:&quot;Evrejskaja avtonomnaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHA&quot;,&quot;state&quot;:&quot;Habarovskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHM&quot;,&quot;state&quot;:&quot;Hanty-Mansijskij avtonomnyj okrug - Jugra&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IRK&quot;,&quot;state&quot;:&quot;Irkutskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IVA&quot;,&quot;state&quot;:&quot;Ivanovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAN&quot;,&quot;state&quot;:&quot;Jamalo-Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAR&quot;,&quot;state&quot;:&quot;Jaroslavskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KB&quot;,&quot;state&quot;:&quot;Kabardino-Balkarskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGD&quot;,&quot;state&quot;:&quot;Kaliningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KLU&quot;,&quot;state&quot;:&quot;Kaluzhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KAM&quot;,&quot;state&quot;:&quot;Kamchatskiy kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KC&quot;,&quot;state&quot;:&quot;Karachaevo-Cherkesskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KEM&quot;,&quot;state&quot;:&quot;Kemerovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIR&quot;,&quot;state&quot;:&quot;Kirovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KOS&quot;,&quot;state&quot;:&quot;Kostromskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KDA&quot;,&quot;state&quot;:&quot;Krasnodarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIA&quot;,&quot;state&quot;:&quot;Krasnojarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGN&quot;,&quot;state&quot;:&quot;Kurganskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KRS&quot;,&quot;state&quot;:&quot;Kurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LEN&quot;,&quot;state&quot;:&quot;Leningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LIP&quot;,&quot;state&quot;:&quot;Lipeckaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MAG&quot;,&quot;state&quot;:&quot;Magadanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOS&quot;,&quot;state&quot;:&quot;Moskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOW&quot;,&quot;state&quot;:&quot;Moskva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MUR&quot;,&quot;state&quot;:&quot;Murmanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NEN&quot;,&quot;state&quot;:&quot;Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NIZ&quot;,&quot;state&quot;:&quot;Nizhegorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NGR&quot;,&quot;state&quot;:&quot;Novgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NVS&quot;,&quot;state&quot;:&quot;Novosibirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;OMS&quot;,&quot;state&quot;:&quot;Omskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORE&quot;,&quot;state&quot;:&quot;Orenburgskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORL&quot;,&quot;state&quot;:&quot;Orlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PNZ&quot;,&quot;state&quot;:&quot;Penzenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PER&quot;,&quot;state&quot;:&quot;Permskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PRI&quot;,&quot;state&quot;:&quot;Primorskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PSK&quot;,&quot;state&quot;:&quot;Pskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AD&quot;,&quot;state&quot;:&quot;Respublika Adygeja&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Respublika Altaj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Respublika Bashkortostan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Respublika Burjatija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;DA&quot;,&quot;state&quot;:&quot;Respublika Dagestan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KK&quot;,&quot;state&quot;:&quot;Respublika Hakasija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Respublika Ingushetija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KL&quot;,&quot;state&quot;:&quot;Respublika Kalmykija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Respublika Karelija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KO&quot;,&quot;state&quot;:&quot;Respublika Komi&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Respublika Marij Jel&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Respublika Mordovija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Respublika Saha (Jakutija)&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Respublika Severnaja Osetija-Alanija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Respublika Tatarstan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TY&quot;,&quot;state&quot;:&quot;Respublika Tyva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;RYA&quot;,&quot;state&quot;:&quot;Rjazanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ROS&quot;,&quot;state&quot;:&quot;Rostovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAK&quot;,&quot;state&quot;:&quot;Sahalinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAM&quot;,&quot;state&quot;:&quot;Samarskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Sankt-Peterburg&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saratovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SMO&quot;,&quot;state&quot;:&quot;Smolenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;STA&quot;,&quot;state&quot;:&quot;Stavropol'skij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SVE&quot;,&quot;state&quot;:&quot;Sverdlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TAM&quot;,&quot;state&quot;:&quot;Tambovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TYU&quot;,&quot;state&quot;:&quot;Tjumenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TOM&quot;,&quot;state&quot;:&quot;Tomskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TUL&quot;,&quot;state&quot;:&quot;Tul'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TVE&quot;,&quot;state&quot;:&quot;Tverskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udmurtskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ULY&quot;,&quot;state&quot;:&quot;Ul'janovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLA&quot;,&quot;state&quot;:&quot;Vladimirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VGG&quot;,&quot;state&quot;:&quot;Volgogradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLG&quot;,&quot;state&quot;:&quot;Vologodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VOR&quot;,&quot;state&quot;:&quot;Voronezhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ZAB&quot;,&quot;state&quot;:&quot;Zabaykal'skiy kraj&quot;}],&quot;US&quot;:[{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alabama&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AK&quot;,&quot;state&quot;:&quot;Alaska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AZ&quot;,&quot;state&quot;:&quot;Arizona&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arkansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;California&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Colorado&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Connecticut&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DE&quot;,&quot;state&quot;:&quot;Delaware&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DC&quot;,&quot;state&quot;:&quot;District of Columbia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Florida&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GA&quot;,&quot;state&quot;:&quot;Georgia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guam&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;HI&quot;,&quot;state&quot;:&quot;Hawaii&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ID&quot;,&quot;state&quot;:&quot;Idaho&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;Illinois&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Indiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IA&quot;,&quot;state&quot;:&quot;Iowa&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KS&quot;,&quot;state&quot;:&quot;Kansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KY&quot;,&quot;state&quot;:&quot;Kentucky&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;LA&quot;,&quot;state&quot;:&quot;Louisiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Maine&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MD&quot;,&quot;state&quot;:&quot;Maryland&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;Massachusetts&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Michigan&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Minnesota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Mississippi&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Missouri&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Montana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Nebraska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NV&quot;,&quot;state&quot;:&quot;Nevada&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;New Hampshire&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NJ&quot;,&quot;state&quot;:&quot;New Jersey&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NM&quot;,&quot;state&quot;:&quot;New Mexico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NY&quot;,&quot;state&quot;:&quot;New York&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NC&quot;,&quot;state&quot;:&quot;North Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ND&quot;,&quot;state&quot;:&quot;North Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MP&quot;,&quot;state&quot;:&quot;Northern Mariana Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OH&quot;,&quot;state&quot;:&quot;Ohio&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OK&quot;,&quot;state&quot;:&quot;Oklahoma&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oregon&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Pennsylvania&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Puerto Rico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rhode Island&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SC&quot;,&quot;state&quot;:&quot;South Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SD&quot;,&quot;state&quot;:&quot;South Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Tennessee&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TX&quot;,&quot;state&quot;:&quot;Texas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utah&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Vermont&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Virgin Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Washington&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WV&quot;,&quot;state&quot;:&quot;West Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WI&quot;,&quot;state&quot;:&quot;Wisconsin&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WY&quot;,&quot;state&quot;:&quot;Wyoming&quot;}]},

// [filosof]
        countries_with_codes: {&quot;RO&quot;:&quot;RO&quot;}
// [/filosof]
    });

    
    $.ceFormValidator('setZipcode', {
        US: {
            regexp: /^(\d{5})(-\d{4})?$/,
            format: '01342 (01342-5678)'
        },
        CA: {
            regexp: /^(\w{3} ?\w{3})$/,
            format: 'V1A OB1 (V1AOB1)'
        },
        RU: {
            regexp: /^(\d{6})?$/,
            format: '123456'
        }
    });
    

}(Tygh, Tygh.$));
//]]>

    




    
        Customer profile - Edit mode
    
            
            
            

                                
                    Adresă de e-mail:

            
    
                
                
                            
                    
    Status
    
                    Active

        
        
            Disabled
        
            



                                                                
                    
                    
                            
            
                Language
                
                
                                            English
                                            Romanian
                                    
                
            

            
                                
                



            
            Store
            
                    
                        RO iQOS
            
            
        
    

                    
                
    Contact information
    





    

            

                                    


    
        Title:
    

    
      
        
                    
            Mr.
                    
            Ms.
                

        

            

                                    


    
        First name:
    

    
      
        

            
        

        

            

                                    


    
        Last name:
    

    
      
        

            
        

        

            

                                    


    
        Birthday:
    

    
      
                        
    
    

    
    
    



    

    .ui-timepicker-div .ui-widget-header { margin-bottom: 8px; }
    .ui-timepicker-div dl { text-align: left; }
    .ui-timepicker-div dl dt { float: left; clear:left; padding: 0 0 0 5px; }
    .ui-timepicker-div dl dd { margin: 0 10px 10px 40%; }
    .ui-timepicker-div td { font-size: 90%; }
    .ui-tpicker-grid-label { background: none; border: none; margin: 0; padding: 0; }
    .ui-timepicker-div .ui_tpicker_unit_hide{ display: none; }

    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input { background: none; color: inherit; border: none; outline: none; border-bottom: solid 1px #555; width: 95%; }
    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input:focus { border-bottom-color: #aaa; }

    .ui-timepicker-rtl{ direction: rtl; }
    .ui-timepicker-rtl dl { text-align: right; padding: 0 5px 0 0; }
    .ui-timepicker-rtl dl dt{ float: right; clear: right; }
    .ui-timepicker-rtl dl dd { margin: 0 40% 10px 10px; }

    /* Shortened version style */
    .ui-timepicker-div.ui-timepicker-oneLine { padding-right: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time,
    .ui-timepicker-div.ui-timepicker-oneLine dt { display: none; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time_label { display: block; padding-top: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine dl { text-align: right; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd > div { display:inline-block; margin:0; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_minute:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_second:before { content:':'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_millisec:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_microsec:before { content:'.'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide,
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide:before{ display: none; }




//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
        // Keep variable name 'calendar_config' and its scope (global) for correct cloning with settings
        // (see js/tygh/node_cloning.js)
        calendar_config = {
            changeMonth: true,
            duration: 'fast',
            changeYear: true,
            numberOfMonths: 1,
            selectOtherMonths: true,
            showOtherMonths: true,
                                    firstDay: 1,
            dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            yearRange: '1902:2023',
            dateFormat: 'dd/mm/yy'
        };
        if ($('#elm_78').hasClass('cm-datetimepicker')) {
            $('#elm_78').datetimepicker(
                calendar_config
            );
        } else {
            $('#elm_78').datepicker(
                calendar_config
            );
        }
    });
}(Tygh, Tygh.$));
//]]>


        
        




            
                            

        


    

            

                                    


    
        County:
    

    
      

                
                    
                
                    - Select state -
                                                                        
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                            ALBAARADARGESBACAUBIHORBISTRITA-NASAUDBOTOSANIBRAILABRASOVBUCURESTIBUZAUCALARASICARAS-SEVERINCLUJCONSTANTACOVASNADAMBOVITADOLJGALATIGIURGIUGORJHARGHITAHUNEDOARAIALOMITAIASIILFOVMARAMURESMEHEDINTIMURESNEAMTOLTPRAHOVASALAJSATU MARESIBIUSUCEAVATELEORMANTIMISTULCEAVALCEAVASLUIVRANCEA

            
                

            

                                    


    
        City:
    

    
            
        

            

                                    


    
        District:
    

    
      
        

            
        

        

            

                                    


    
        Phone:
    

    
            
        

            

                                    


    
        Country:
    

    
      
                
            
            - Select country -
                        Afghanistan
                        Aland Islands
                        Albania
                        Algeria
                        American Samoa
                        Andorra
                        Angola
                        Anguilla
                        Antarctica
                        Antigua and Barbuda
                        Argentina
                        Armenia
                        Aruba
                        Asia-Pacific
                        Australia
                        Austria
                        Azerbaijan
                        Bahamas
                        Bahrain
                        Bangladesh
                        Barbados
                        Belarus
                        Belgium
                        Belize
                        Benin
                        Bermuda
                        Bhutan
                        Bolivia
                        Bosnia and Herzegowina
                        Botswana
                        Bouvet Island
                        Brazil
                        British Indian Ocean Territory
                        British Virgin Islands
                        Brunei Darussalam
                        Bulgaria
                        Burkina Faso
                        Burundi
                        Cambodia
                        Cameroon
                        Canada
                        Cape Verde
                        Cayman Islands
                        Central African Republic
                        Chad
                        Chile
                        China
                        Christmas Island
                        Cocos (Keeling) Islands
                        Colombia
                        Comoros
                        Congo
                        Cook Islands
                        Costa Rica
                        Cote D'ivoire
                        Croatia
                        Cuba
                        Curaçao
                        Cyprus
                        Czech Republic
                        Denmark
                        Djibouti
                        Dominica
                        Dominican Republic
                        East Timor
                        Ecuador
                        Egypt
                        El Salvador
                        Equatorial Guinea
                        Eritrea
                        Estonia
                        Ethiopia
                        Europe
                        Falkland Islands (Malvinas)
                        Faroe Islands
                        Fiji
                        Finland
                        France
                        France, Metropolitan
                        French Guiana
                        French Polynesia
                        French Southern Territories
                        Gabon
                        Gambia
                        Georgia
                        Germany
                        Ghana
                        Gibraltar
                        Greece
                        Greenland
                        Grenada
                        Guadeloupe
                        Guam
                        Guatemala
                        Guernsey
                        Guinea
                        Guinea-Bissau
                        Guyana
                        Haiti
                        Heard and McDonald Islands
                        Honduras
                        Hong Kong
                        Hungary
                        Iceland
                        India
                        Indonesia
                        Iraq
                        Ireland
                        Islamic Republic of Iran
                        Isle of Man
                        Israel
                        Italy
                        Jamaica
                        Japan
                        Jersey
                        Jordan
                        Kazakhstan
                        Kenya
                        Kiribati
                        Korea
                        Korea, Republic of
                        Kuwait
                        Kyrgyzstan
                        Laos
                        Latvia
                        Lebanon
                        Lesotho
                        Liberia
                        Libyan Arab Jamahiriya
                        Liechtenstein
                        Lithuania
                        Luxembourg
                        Macau
                        Macedonia
                        Madagascar
                        Malawi
                        Malaysia
                        Maldives
                        Mali
                        Malta
                        Marshall Islands
                        Martinique
                        Mauritania
                        Mauritius
                        Mayotte
                        Mexico
                        Micronesia
                        Moldova, Republic of
                        Monaco
                        Mongolia
                        Montenegro
                        Montserrat
                        Morocco
                        Mozambique
                        Myanmar
                        Namibia
                        Nauru
                        Nepal
                        Netherlands
                        New Caledonia
                        New Zealand
                        Nicaragua
                        Niger
                        Nigeria
                        Niue
                        Norfolk Island
                        Northern Mariana Islands
                        Norway
                        Oman
                        Pakistan
                        Palau
                        Palestine Authority
                        Panama
                        Papua New Guinea
                        Paraguay
                        Peru
                        Philippines
                        Pitcairn
                        Poland
                        Portugal
                        Puerto Rico
                        Qatar
                        Republic of Serbia
                        Reunion
                        Romania
                        Russian Federation
                        Rwanda
                        Saint Lucia
                        Samoa
                        San Marino
                        Sao Tome and Principe
                        Saudi Arabia
                        Senegal
                        Serbia
                        Seychelles
                        Sierra Leone
                        Singapore
                        Sint Maarten
                        Slovakia
                        Slovenia
                        Solomon Islands
                        Somalia
                        South Africa
                        Spain
                        Sri Lanka
                        St. Helena
                        St. Kitts and Nevis
                        St. Pierre and Miquelon
                        St. Vincent and the Grenadines
                        Sudan
                        Suriname
                        Svalbard and Jan Mayen Islands
                        Swaziland
                        Sweden
                        Switzerland
                        Syrian Arab Republic
                        Taiwan
                        Tajikistan
                        Tanzania, United Republic of
                        Thailand
                        Togo
                        Tokelau
                        Tonga
                        Trinidad and Tobago
                        Tunisia
                        Turkey
                        Turkmenistan
                        Turks and Caicos Islands
                        Tuvalu
                        Uganda
                        Ukraine
                        United Arab Emirates
                        United Kingdom (Great Britain)
                        United States
                        United States Virgin Islands
                        Uruguay
                        Uzbekistan
                        Vanuatu
                        Vatican City State
                        Venezuela
                        Viet Nam
                        Wallis And Futuna Islands
                        Western Sahara
                        Yemen
                        Zaire
                        Zambia
                        Zimbabwe
                        

        

        



            
                    
            
                                


 
     Save
    


                            


 
     Cancel
    


        
    



            
            
            
                                                                        
    
                
        
            
                Select activity
                
            
                        

    
    


    
        	                        
                        Inquiry
        
                            
                        Device
        
                            
                        Return Device
        
                            
                        Heat Stick Issue
        
                            
                            
                More
                        Orders
        
                        Twilio Video Room
        


                    
                                            
    
        
    
                        
                Add issue
        
            

            
            
            
            
            
                                                    
                
                        

            
            
                                    
                        
                            Inbound
                            Outbound
                        
                    
                
                                    
    
        Brand code
        
                
                            
            
    

    #None
    




    
            
            
                
            
        
        
        
            
                        
            
                Loading...
            
        
    
    



        
    
        
    

                    Brand description appears here
                
                
                    Product
                    
                        
                        
                    
                
                Product description appears here

                                    


            
            Subject Group
                        
                
                     Not Selected 
                                                                         Without Group 
                                                                                                 Product Issues Consumable 
                                                                                                 Critical Inquiry 
                                                                                                 Product Issues Device 
                                                                                                 Inquiry 
                                                                                                 Order Management 
                                                                                                 Program Support 
                                                            
            
        
    
    
        Subject Code
        
                
            
            
    

    #None
    




    
            
            
                
            
        
        
        
            
                        
            
                Loading...
            
        
    
    



        
    
        
    

                                Subject appears here

                
                
                    Production Code
                    
                        
                    
                

                
                    Codentify Code
                    
                        
                    
                

                
                    NCP Quantity
                    
                        
                    
                

                
                    Add Attachments
                    
                        








    
         
            
    
    Upload another fileLocalURL




(function(_, $) {
    $.extend(_, {
        post_max_size_bytes: '10485760',
        files_upload_max_size_bytes: '10485760',
        max_file_uploads: '20',

        post_max_size_mbytes: '10M',
        files_upload_max_size_mbytes: '10M'
    });

    _.tr({
        file_is_too_large: 'File is too large. Max uploading size is [size].'
    });
}(Tygh, Tygh.$));

                    
                

                
                
                
                
                
                
                
                
                

            

            
                
                                            
                            Contact Type
                            
                                
                                    --
                                                                            AQ - anonymous self-service qure
                                                                            TR - trade in service
                                                                            FC - 1800 telephone number
                                                                            LC - live chat
                                                                            EM - email
                                                                            FK - facebook
                                                                            O - outbound 
                                                                            IP - in person
                                                                            TW - twitter
                                                                            FT - phone via traveler support
                                                                            SM - sms
                                                                            FF - field force
                                                                            QR - self-service qure
                                                                    
                            
                        
                    
                                            
                            Response Type
                            
                                
                                                                            --
                                                                                    QE - Error Anonymous QURE result
                                                                                    AQ - Success Anonymous QURE result
                                                                                    FRA - Fraud attempt
                                                                                    TR - Trade In offer
                                                                                    VB - Verbal
                                                                                    CH - Live Chat
                                                                                    EM - Email
                                                                                    FK - Facebook
                                                                                    TW - Twitter
                                                                                    SM - SMS
                                                                                    NR - No Response
                                                                                    IP - In Person
                                                                                    CR - Call Center to handle
                                                                                    RA - Replacement done via Contact Service Center - Agent
                                                                                    RF - Replacement done via Flagship Store
                                                                                    RS - Replacement Service Points
                                                                                    RW - Replacement Denied (warranty expired)
                                                                                    RO - Replacement Denied (out of stock)
                                                                                    RI - Replacement not possible
                                                                                    BF - Callback - Follow up
                                                                                    BV - Callback - Voicemail
                                                                                    BO - Callback - OOO Hours
                                                                                    BA - Callback - Abandoners
                                                                                                            
                            
                        
                    
                    
                        CC Priority
                        
                            
                        
                    

                    
                        Sprinklr ID
                        
                            
                        
                    

                    
                    
                        Verbatim
                        
                            
                        
                    
                                                        


                            Add Sentiment Management
    
        
                        
            
                Pain Points
                
                    
                        --
                                                    Warranty Issue - Code B
                                                    Misusage Issue - Code C
                                                    Not Eligible for swap
                                                    Complaints about HEETS - Difficult to insert / Low Aerosol / Difficult to draw
                                                    Consumer doesn't like the taste
                                                    Complains about bad smell
                                                    Difficult to Clean
                                                    IQOS Kit received as a gift, consumer cannot register
                                                    IQOS Kit received as a gift, consumer cannot register
                                                    Issue with agent's/front facing personal`s attitude &amp; knowledge
                                            
                
            
            

            
                Solution Accepted
                
                    
                    
                
            

            
            
                
                    
                        
                            Available Solutions
                         
                        
                            Selected Solutions
                        
                    
                
                
                
                    
                        
                            
                                                                                                            On the spot replacement after L0 diagnostics if it is under warranty. Apologize for the incident. If it is repetitive, use a compensatory solution
                                                                                                                                                Educate the consumer on usage and cleaning. If there is eligibility for accidental damage coverage from IQOS CARE PLUS or subscription, replace.
                                                                                                                                                Offer discount in the next purchase or trade-in. If consumer is becoming a detractor, offer goodwill.
                                                                                                                                                Validate if the cleaning is made. If not, offer the cleaning service (if there is a close boutique) and highlight the importance. If it is related with device performance, offer a new cap. If it is about the specific faulty HEETs, replace them.
                                                                                                                                                Validate if the cleaning is made. If not, offer the cleaning service (if there is a close boutique) and highlight the importance. Offer different HEETs variants. Explain HNB technology.
                                                                                                                                                Validate if the cleaning is made. If not, offer the cleaning service (if there is a close boutique) and highlight the importance.  Explain HNB technology.Compare IQOS smell vs cigarette smell.
                                                                                                                                                Explain the importance to have optimal taste cleaning is necessary. Explain the consumer how to clean the device, introduce cleaning sticks.
                                                                                                                                                Ask for the consumer to get in touch with gift giver to unlink the device, offer to call on behalf. Explain why the registration was required in the first place. If de-registration is done, perform the registration of the owner.
                                                                                                                                                Deeply apologize and mention that the issue is going to be escalated. If consumer is becoming a detractor, offer goodwill.
                                                                                                                                                Try to understand the main reason, deeply apologize and mention that the issue is going to be escalated. If consumer is becoming a detractor, offer goodwill.
                                                                                                
                            
                                
                                
                            
                        
                        
                            
                            
                            
                        
                        
                            
                            
                        
                    
                
            

            
                
                    Cancel
                        


 
     Set
    


                
            
            
                //&lt;![CDATA[
                (function(_, $) {
                    $(document).ready(function() {
                        var issueId,
                            caseId,
                            submitted = false;

                        function updateSentimentCaseInfo(values) {
                            var needId = $(&quot;#inquiry_pain_point_select_0 option:selected&quot;).val();
                            var solutionAccepted = $(&quot;#inquiry_solution_accepted_0&quot;).prop('checked') ? 'Y' : 'N';

                            $.fn.updateSentiment(issueId, caseId, needId, values, solutionAccepted);
                        };

                        $('.inquiry_cm-map-save-location_0').unbind().click(function(event) {
                            if (submitted) {
                                var values = [];
                                var selectedSolutions = $('#inquiry_solutions_right_0').find('option');
                                selectedSolutions.each(function(){
                                    var value = $(this).val();
                                    values.push(value);
                                });
                                caseId = $('input[name=&quot;case_id&quot;]').val();
                                issueId = $('input[name=&quot;issue_id&quot;]').val();
                                submitted = caseId != 0 ? true : false;
                                updateSentimentCaseInfo(values);
                            }
                        });

                        $('#inquiry_submit_case_creation_0').unbind().click(function(event) {
                            submitted = true;
                        });

                        $('#inquiry_pain_point_select_0').change(function() {
                            if ($('#inquiry_solutions_right_0 option').length) {
                                Tygh.$('#inquiry_solutions_right_0').moveOptions('#inquiry_solutions_0');
                            }
                            var needId = $(&quot;#inquiry_pain_point_select_0 option:selected&quot;).val();
                            var solutions = $('#inquiry_solutions_0 option');
                            $(solutions).each(function(index, value) {
                                if ($(value).attr('need_id') == needId) {
                                    $(value).removeClass('hidden');
                                } else {
                                    $(value).addClass('hidden');
                                }
                            });
                        });

                        $('#inquiry_elm_sorces_I_0').unbind().click( function(event) {
                            $.fn.getBounds('inbound', &quot;inquiry_sentiment_manager_block_0&quot;, &quot;inquiry_&quot;);
                            $('#inquiry_sentiment_manager_opener_0').show();
                        });

                        $('#inquiry_elm_sorces_O_0').unbind().click( function(event) {
                                                            $.fn.getBounds('outbound',&quot;inquiry_sentiment_manager_block_0&quot;, &quot;inquiry_&quot;);
                                                    });
                    });

                }(Tygh, Tygh.$));
                //]]>
            

    



            
            
            
    

    
        
                


 
    



                    Reset
                

    //&lt;![CDATA[
    (function(_, $) {
                $.ceEvent('on', 'ce.formajaxpost_inquiry_create_issue_0', function(data) {
            var block_replace = $('#sd_block_replace_device');
            if (data.create_second_issue &amp;&amp; block_replace.length) {
                $.ceAjax('request', fn_url('case_management.replacement_procedure'), {
                    method: 'post',
                    result_ids: 'sd_block_replace_device',
                    callback: function (data) {
                        block_replace.show();
                        $.scrollToElm(block_replace);
                    }
                });
            }
        });
    }(Tygh, Tygh.$));
     //]]>

    
    
            


 
    



    
    
    
        //&lt;![CDATA[
        (function(_, $) {
            $(document).ready(function() {
                $('.dropdown-toggle').dropdown();
                
                                    // if it's a new case we get the consumer_user_id from the current page if it's not set already
                    $('form[name=inquiry_create_issue_0]').on('submit', function(e) {
                        let caseDataUserIdSubmitElem = $(this).find(&quot;input[name='case_data[consumer_user_id]']&quot;)
                        if (caseDataUserIdSubmitElem &amp;&amp; parseInt(caseDataUserIdSubmitElem.val()) === 0) {
                            $(&quot;input[name='case_data[consumer_user_id]']&quot;).each(function(index, elem) {
                                if (parseInt(elem.value) !== 0) {
                                    caseDataUserIdSubmitElem.val(elem.value);
                                    return false;
                                }
                            });
                        }
                    });
                
                $.ceEvent('on', 'ce.formajaxpost_inquiry_create_issue_0', function(data) {
                    if (data.create_issue) {
                        $('#exit_without_saving').hide();
                        $('#exit_issue_block_0').hide();
                        $('#create_opportunity').hide();
                        $('#inquiry_onep-issue_0__buttons').hide();
                        $('#inquiry_source_0').hide();
                        $('#inquiry_contact_type_control_group_0').hide();
                        $('#inquiry_onep-update-issue_0__buttons').show();
                        $('#onep-register_device_0__buttons').hide();

                        if (data.issue_code) {
                            $('#inquiry_issue_title_0').text('Issue ID: #' + data.issue_code);

                            $('input[name=&quot;issue_data[issue_code]&quot;]').val(data.issue_code);
                        }
                                                                        $('#onep-devicesinquiry__0__buttons').hide();
                        $('#content_deviceinquiry__0 .onep-device-top__radio').hide();
                        $('#sd_case_management_tabs_0 li').removeClass('cm-js');
                        $('#sd_case_management_tabs_0 li a').removeClass('cm-ajax').removeAttr('href');
                                                if (data.follow_up) {
                            $('#nav_follow_0').show();
                            $.scrollToElm($('#nav_follow_0'));
                        }
                        if (data.pickup_at_pos_email) {
                            $('#nav_pickup_at_pos_email_0').show();
                            $.scrollToElm($('#nav_pickup_at_pos_email_0'));
                        }
                        if (data.show_exit_without_saving_btn) {
                            $('#onep-exit_without_saving__0').show();
                        }
                        $.fn.sd_cmop_update_menu();

                        if (data.case_id &amp;&amp; data.issue_id) {
                            caseId = data.case_id;
                            issueId = data.issue_id;

                            $('input[name=&quot;case_id&quot;]').val(data.case_id);
                            $('input[name=&quot;issue_id&quot;]').val(data.issue_id);
                        }

                        if (data.opportunity_id) {
                            $('#opportunity_management_popup').data('caOpportunityId', data.opportunity_id);
                        }
                    }
                    $.ceEvent('trigger', 'ce.form_create_issue', [data, 'inquiry_', '_0']);
                });

                
                
                $('#inquiry_sprinklr_id_0').on('change', function (e, data) {
                    var el = $(this),
                        error_container = $('#inquiry_sprinklr_id_0_error_message'),
                        error_desc = '&lt;span id=&quot;inquiry_sprinklr_id_0_error_message&quot; class=&quot;help-inline&quot;>&lt;p class=&quot;form-input-hint&quot;>The Sprinklr ID is incorrect. Correct format is #00000, at least 5 digits after #.&lt;/p>&lt;/span>';

                    $.fn.sd_validate_sprinklr_id(el, error_container, error_desc);
                });

                            });

        }(Tygh, Tygh.$));
        //]]>
    



    

                                                                
    
        
    
                        
                Add issue
        
            

            
            
            
            
            
                                                    
                
                        

            
            
                                    
                        
                            Inbound
                            Outbound
                        
                    
                
                                    
    
        Brand code
        
                
                            
            
    

    #None
    




    
            
            
                
            
        
        
        
            
                        
            
                Loading...
            
        
    
    



        
    
        
    

                    Brand description appears here
                
                
                    Product
                    
                        
                        
                    
                
                Product description appears here

                                    


            
            Subject Group
                        
                
                     Not Selected 
                                                                         Without Group 
                                                                                                 Product Issues Consumable 
                                                                                                 Critical Inquiry 
                                                                                                 Product Issues Device 
                                                                                                 Inquiry 
                                                                                                 Order Management 
                                                                                                 Program Support 
                                                            
            
        
    
    
        Subject Code
        
                
            
            
    

    #None
    




    
            
            
                
            
        
        
        
            
                        
            
                Loading...
            
        
    
    



        
    
        
    

                                Subject appears here

                
                
                    Production Code
                    
                        
                    
                

                
                    Codentify Code
                    
                        
                    
                

                
                    NCP Quantity
                    
                        
                    
                

                
                    Add Attachments
                    
                        








    
         
            
    
    Upload another fileLocalURL




(function(_, $) {
    $.extend(_, {
        post_max_size_bytes: '10485760',
        files_upload_max_size_bytes: '10485760',
        max_file_uploads: '20',

        post_max_size_mbytes: '10M',
        files_upload_max_size_mbytes: '10M'
    });

    _.tr({
        file_is_too_large: 'File is too large. Max uploading size is [size].'
    });
}(Tygh, Tygh.$));

                    
                

                
                
                
                
                
                
                
                
                

            

            
                
                                            
                            Contact Type
                            
                                
                                    --
                                                                            AQ - anonymous self-service qure
                                                                            TR - trade in service
                                                                            FC - 1800 telephone number
                                                                            LC - live chat
                                                                            EM - email
                                                                            FK - facebook
                                                                            O - outbound 
                                                                            IP - in person
                                                                            TW - twitter
                                                                            FT - phone via traveler support
                                                                            SM - sms
                                                                            FF - field force
                                                                            QR - self-service qure
                                                                    
                            
                        
                    
                                            
                            Response Type
                            
                                
                                                                            --
                                                                                    QE - Error Anonymous QURE result
                                                                                    AQ - Success Anonymous QURE result
                                                                                    FRA - Fraud attempt
                                                                                    TR - Trade In offer
                                                                                    VB - Verbal
                                                                                    CH - Live Chat
                                                                                    EM - Email
                                                                                    FK - Facebook
                                                                                    TW - Twitter
                                                                                    SM - SMS
                                                                                    NR - No Response
                                                                                    IP - In Person
                                                                                    CR - Call Center to handle
                                                                                    RA - Replacement done via Contact Service Center - Agent
                                                                                    RF - Replacement done via Flagship Store
                                                                                    RS - Replacement Service Points
                                                                                    RW - Replacement Denied (warranty expired)
                                                                                    RO - Replacement Denied (out of stock)
                                                                                    RI - Replacement not possible
                                                                                    BF - Callback - Follow up
                                                                                    BV - Callback - Voicemail
                                                                                    BO - Callback - OOO Hours
                                                                                    BA - Callback - Abandoners
                                                                                                            
                            
                        
                    
                    
                        CC Priority
                        
                            
                        
                    

                    
                        Sprinklr ID
                        
                            
                        
                    

                    
                    
                        Verbatim
                        
                            
                        
                    
                                                        


                            Add Sentiment Management
    
        
                        
            
                Pain Points
                
                    
                        --
                                                    Warranty Issue - Code B
                                                    Misusage Issue - Code C
                                                    Not Eligible for swap
                                                    Complaints about HEETS - Difficult to insert / Low Aerosol / Difficult to draw
                                                    Consumer doesn't like the taste
                                                    Complains about bad smell
                                                    Difficult to Clean
                                                    IQOS Kit received as a gift, consumer cannot register
                                                    IQOS Kit received as a gift, consumer cannot register
                                                    Issue with agent's/front facing personal`s attitude &amp; knowledge
                                            
                
            
            

            
                Solution Accepted
                
                    
                    
                
            

            
            
                
                    
                        
                            Available Solutions
                         
                        
                            Selected Solutions
                        
                    
                
                
                
                    
                        
                            
                                                                                                            On the spot replacement after L0 diagnostics if it is under warranty. Apologize for the incident. If it is repetitive, use a compensatory solution
                                                                                                                                                Educate the consumer on usage and cleaning. If there is eligibility for accidental damage coverage from IQOS CARE PLUS or subscription, replace.
                                                                                                                                                Offer discount in the next purchase or trade-in. If consumer is becoming a detractor, offer goodwill.
                                                                                                                                                Validate if the cleaning is made. If not, offer the cleaning service (if there is a close boutique) and highlight the importance. If it is related with device performance, offer a new cap. If it is about the specific faulty HEETs, replace them.
                                                                                                                                                Validate if the cleaning is made. If not, offer the cleaning service (if there is a close boutique) and highlight the importance. Offer different HEETs variants. Explain HNB technology.
                                                                                                                                                Validate if the cleaning is made. If not, offer the cleaning service (if there is a close boutique) and highlight the importance.  Explain HNB technology.Compare IQOS smell vs cigarette smell.
                                                                                                                                                Explain the importance to have optimal taste cleaning is necessary. Explain the consumer how to clean the device, introduce cleaning sticks.
                                                                                                                                                Ask for the consumer to get in touch with gift giver to unlink the device, offer to call on behalf. Explain why the registration was required in the first place. If de-registration is done, perform the registration of the owner.
                                                                                                                                                Deeply apologize and mention that the issue is going to be escalated. If consumer is becoming a detractor, offer goodwill.
                                                                                                                                                Try to understand the main reason, deeply apologize and mention that the issue is going to be escalated. If consumer is becoming a detractor, offer goodwill.
                                                                                                
                            
                                
                                
                            
                        
                        
                            
                            
                            
                        
                        
                            
                            
                        
                    
                
            

            
                
                    Cancel
                        


 
     Set
    


                
            
            
                //&lt;![CDATA[
                (function(_, $) {
                    $(document).ready(function() {
                        var issueId,
                            caseId,
                            submitted = false;

                        function updateSentimentCaseInfo(values) {
                            var needId = $(&quot;#heat_stick_pain_point_select_0 option:selected&quot;).val();
                            var solutionAccepted = $(&quot;#heat_stick_solution_accepted_0&quot;).prop('checked') ? 'Y' : 'N';

                            $.fn.updateSentiment(issueId, caseId, needId, values, solutionAccepted);
                        };

                        $('.heat_stick_cm-map-save-location_0').unbind().click(function(event) {
                            if (submitted) {
                                var values = [];
                                var selectedSolutions = $('#heat_stick_solutions_right_0').find('option');
                                selectedSolutions.each(function(){
                                    var value = $(this).val();
                                    values.push(value);
                                });
                                caseId = $('input[name=&quot;case_id&quot;]').val();
                                issueId = $('input[name=&quot;issue_id&quot;]').val();
                                submitted = caseId != 0 ? true : false;
                                updateSentimentCaseInfo(values);
                            }
                        });

                        $('#heat_stick_submit_case_creation_0').unbind().click(function(event) {
                            submitted = true;
                        });

                        $('#heat_stick_pain_point_select_0').change(function() {
                            if ($('#heat_stick_solutions_right_0 option').length) {
                                Tygh.$('#heat_stick_solutions_right_0').moveOptions('#heat_stick_solutions_0');
                            }
                            var needId = $(&quot;#heat_stick_pain_point_select_0 option:selected&quot;).val();
                            var solutions = $('#heat_stick_solutions_0 option');
                            $(solutions).each(function(index, value) {
                                if ($(value).attr('need_id') == needId) {
                                    $(value).removeClass('hidden');
                                } else {
                                    $(value).addClass('hidden');
                                }
                            });
                        });

                        $('#heat_stick_elm_sorces_I_0').unbind().click( function(event) {
                            $.fn.getBounds('inbound', &quot;heat_stick_sentiment_manager_block_0&quot;, &quot;heat_stick_&quot;);
                            $('#heat_stick_sentiment_manager_opener_0').show();
                        });

                        $('#heat_stick_elm_sorces_O_0').unbind().click( function(event) {
                                                            $.fn.getBounds('outbound',&quot;heat_stick_sentiment_manager_block_0&quot;, &quot;heat_stick_&quot;);
                                                    });
                    });

                }(Tygh, Tygh.$));
                //]]>
            

    



            
            
            
    

    
        
                


 
    



                    Reset
                

    //&lt;![CDATA[
    (function(_, $) {
                $.ceEvent('on', 'ce.formajaxpost_heat_stick_create_issue_0', function(data) {
            var block_replace = $('#sd_block_replace_device');
            if (data.create_second_issue &amp;&amp; block_replace.length) {
                $.ceAjax('request', fn_url('case_management.replacement_procedure'), {
                    method: 'post',
                    result_ids: 'sd_block_replace_device',
                    callback: function (data) {
                        block_replace.show();
                        $.scrollToElm(block_replace);
                    }
                });
            }
        });
    }(Tygh, Tygh.$));
     //]]>

    
    
            


 
    



    
    
    
        //&lt;![CDATA[
        (function(_, $) {
            $(document).ready(function() {
                $('.dropdown-toggle').dropdown();
                
                                    // if it's a new case we get the consumer_user_id from the current page if it's not set already
                    $('form[name=heat_stick_create_issue_0]').on('submit', function(e) {
                        let caseDataUserIdSubmitElem = $(this).find(&quot;input[name='case_data[consumer_user_id]']&quot;)
                        if (caseDataUserIdSubmitElem &amp;&amp; parseInt(caseDataUserIdSubmitElem.val()) === 0) {
                            $(&quot;input[name='case_data[consumer_user_id]']&quot;).each(function(index, elem) {
                                if (parseInt(elem.value) !== 0) {
                                    caseDataUserIdSubmitElem.val(elem.value);
                                    return false;
                                }
                            });
                        }
                    });
                
                $.ceEvent('on', 'ce.formajaxpost_heat_stick_create_issue_0', function(data) {
                    if (data.create_issue) {
                        $('#exit_without_saving').hide();
                        $('#exit_issue_block_0').hide();
                        $('#create_opportunity').hide();
                        $('#heat_stick_onep-issue_0__buttons').hide();
                        $('#heat_stick_source_0').hide();
                        $('#heat_stick_contact_type_control_group_0').hide();
                        $('#heat_stick_onep-update-issue_0__buttons').show();
                        $('#onep-register_device_0__buttons').hide();

                        if (data.issue_code) {
                            $('#heat_stick_issue_title_0').text('Issue ID: #' + data.issue_code);

                            $('input[name=&quot;issue_data[issue_code]&quot;]').val(data.issue_code);
                        }
                                                                        $('#onep-devicesheat_stick__0__buttons').hide();
                        $('#content_deviceheat_stick__0 .onep-device-top__radio').hide();
                        $('#sd_case_management_tabs_0 li').removeClass('cm-js');
                        $('#sd_case_management_tabs_0 li a').removeClass('cm-ajax').removeAttr('href');
                                                if (data.follow_up) {
                            $('#nav_follow_0').show();
                            $.scrollToElm($('#nav_follow_0'));
                        }
                        if (data.pickup_at_pos_email) {
                            $('#nav_pickup_at_pos_email_0').show();
                            $.scrollToElm($('#nav_pickup_at_pos_email_0'));
                        }
                        if (data.show_exit_without_saving_btn) {
                            $('#onep-exit_without_saving__0').show();
                        }
                        $.fn.sd_cmop_update_menu();

                        if (data.case_id &amp;&amp; data.issue_id) {
                            caseId = data.case_id;
                            issueId = data.issue_id;

                            $('input[name=&quot;case_id&quot;]').val(data.case_id);
                            $('input[name=&quot;issue_id&quot;]').val(data.issue_id);
                        }

                        if (data.opportunity_id) {
                            $('#opportunity_management_popup').data('caOpportunityId', data.opportunity_id);
                        }
                    }
                    $.ceEvent('trigger', 'ce.form_create_issue', [data, 'heat_stick_', '_0']);
                });

                
                
                $('#heat_stick_sprinklr_id_0').on('change', function (e, data) {
                    var el = $(this),
                        error_container = $('#heat_stick_sprinklr_id_0_error_message'),
                        error_desc = '&lt;span id=&quot;heat_stick_sprinklr_id_0_error_message&quot; class=&quot;help-inline&quot;>&lt;p class=&quot;form-input-hint&quot;>The Sprinklr ID is incorrect. Correct format is #00000, at least 5 digits after #.&lt;/p>&lt;/span>';

                    $.fn.sd_validate_sprinklr_id(el, error_container, error_desc);
                });

                            });

        }(Tygh, Tygh.$));
        //]]>
    



    

                                                                
    
         
            
            
            
            
                Room Name
                
                Room Link
                
                
                
            
        
    




$(document).ajaxComplete(function () {
    document.getElementById(&quot;createVideoRoom&quot;).disabled = true;
    setTimeout(function() {
    document.getElementById(&quot;createVideoRoom&quot;).disabled = false;
    }, 60000); 
});



                                        
                                                                                
                                Orders
                            
                            

    
    


    
        	                        
                        Order on Behalf
        
                More


                                    
                                                                            
                                                                                                        
                            



//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
                    });
}(Tygh, Tygh.$));
//]]>

                                            
                    
                



    Find issued device
                            
            There is no linked device
            
                
                    Search devices
                                        
                        
                            
    
        Enter Device ID (Codentify)
        
            









    //&lt;![CDATA[
    (function(_, $) {
        $('.device-code-search_0').groupinputs();
    }(Tygh, Tygh.$));
    //]]>

        
    
            
            Retailer
            
                                
                    
                    
                        
                    
                    
                        






    
//&lt;![CDATA[
(function(_, $) {

    /* Do not put this code to document.ready, because it should be
       initialized first
    */
    $.ceRebuildStates('init', {
        default_country: 'RO',
        states: {&quot;&quot;:[{&quot;country_code&quot;:&quot;&quot;,&quot;code&quot;:&quot;CONSTANTA&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;}],&quot;AU&quot;:[{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;ACT&quot;,&quot;state&quot;:&quot;Australian Capital Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NSW&quot;,&quot;state&quot;:&quot;New South Wales&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northern Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;QLD&quot;,&quot;state&quot;:&quot;Queensland&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;South Australia&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;TAS&quot;,&quot;state&quot;:&quot;Tasmania&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;VIC&quot;,&quot;state&quot;:&quot;Victoria&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Western Australia&quot;}],&quot;BG&quot;:[{&quot;country_code&quot;:&quot;BG&quot;,&quot;code&quot;:&quot;SF&quot;,&quot;state&quot;:&quot;Sofia&quot;}],&quot;CA&quot;:[{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Alberta&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;British Columbia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;MB&quot;,&quot;state&quot;:&quot;Manitoba&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;New Brunswick&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NL&quot;,&quot;state&quot;:&quot;Newfoundland and Labrador&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northwest Territories&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NS&quot;,&quot;state&quot;:&quot;Nova Scotia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nunavut&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;ON&quot;,&quot;state&quot;:&quot;Ontario&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Prince Edward Island&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;QC&quot;,&quot;state&quot;:&quot;Quebec&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;SK&quot;,&quot;state&quot;:&quot;Saskatchewan&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;YT&quot;,&quot;state&quot;:&quot;Yukon&quot;}],&quot;CH&quot;:[{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Ext\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AI&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Int\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Argovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;B\u00e2le-Campagne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;B\u00e2le-Ville&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BE&quot;,&quot;state&quot;:&quot;Berne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Fribourg&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gen\u00e8ve&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;Glaris&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grisons&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;JU&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucerne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Neuch\u00e2tel&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NW&quot;,&quot;state&quot;:&quot;Nidwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;OW&quot;,&quot;state&quot;:&quot;Obwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Saint-Gall&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SH&quot;,&quot;state&quot;:&quot;Schaffhouse&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SZ&quot;,&quot;state&quot;:&quot;Schwytz&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soleure&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TI&quot;,&quot;state&quot;:&quot;Tessin&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TG&quot;,&quot;state&quot;:&quot;Thurgovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;UR&quot;,&quot;state&quot;:&quot;Uri&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Valais&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VD&quot;,&quot;state&quot;:&quot;Vaud&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZG&quot;,&quot;state&quot;:&quot;Zoug&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zurich&quot;}],&quot;DE&quot;:[{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAW&quot;,&quot;state&quot;:&quot;Baden-W\u00fcrttemberg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAY&quot;,&quot;state&quot;:&quot;Bayern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BER&quot;,&quot;state&quot;:&quot;Berlin&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRG&quot;,&quot;state&quot;:&quot;Branderburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRE&quot;,&quot;state&quot;:&quot;Bremen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HAM&quot;,&quot;state&quot;:&quot;Hamburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HES&quot;,&quot;state&quot;:&quot;Hessen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;MEC&quot;,&quot;state&quot;:&quot;Mecklenburg-Vorpommern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NDS&quot;,&quot;state&quot;:&quot;Niedersachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NRW&quot;,&quot;state&quot;:&quot;Nordrhein-Westfalen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;RHE&quot;,&quot;state&quot;:&quot;Rheinland-Pfalz&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saarland&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAS&quot;,&quot;state&quot;:&quot;Sachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAC&quot;,&quot;state&quot;:&quot;Sachsen-Anhalt&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SCN&quot;,&quot;state&quot;:&quot;Schleswig-Holstein&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;THE&quot;,&quot;state&quot;:&quot;Th\u00fcringen&quot;}],&quot;ES&quot;:[{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;C&quot;,&quot;state&quot;:&quot;A Coru\u00f1a&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;\u00c1lava&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Albacete&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;A&quot;,&quot;state&quot;:&quot;Alicante&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Almer\u00eda&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;O&quot;,&quot;state&quot;:&quot;Asturias&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;\u00c1vila&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Badajoz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PM&quot;,&quot;state&quot;:&quot;Baleares&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;Barcelona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Burgos&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CC&quot;,&quot;state&quot;:&quot;C\u00e1ceres&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;C\u00e1diz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;S&quot;,&quot;state&quot;:&quot;Cantabria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Castell\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Ceuta&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Ciudad Real&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;C\u00f3rdoba&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Cuenca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GI&quot;,&quot;state&quot;:&quot;Girona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Granada&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guadalajara&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Guip\u00fazcoa&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;H&quot;,&quot;state&quot;:&quot;Huelva&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;HU&quot;,&quot;state&quot;:&quot;Huesca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;J&quot;,&quot;state&quot;:&quot;Ja\u00e9n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;La Rioja&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GC&quot;,&quot;state&quot;:&quot;Las Palmas&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Le\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;L&quot;,&quot;state&quot;:&quot;Lleida&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lugo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;M&quot;,&quot;state&quot;:&quot;Madrid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;M\u00e1laga&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ML&quot;,&quot;state&quot;:&quot;Melilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MU&quot;,&quot;state&quot;:&quot;Murcia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Navarra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Ourense&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;P&quot;,&quot;state&quot;:&quot;Palencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Pontevedra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salamanca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TF&quot;,&quot;state&quot;:&quot;Santa Cruz de Tenerife&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Segovia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Sevilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;T&quot;,&quot;state&quot;:&quot;Tarragona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teruel&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Toledo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;V&quot;,&quot;state&quot;:&quot;Valencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Valladolid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Vizcaya&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ZA&quot;,&quot;state&quot;:&quot;Zamora&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;Z&quot;,&quot;state&quot;:&quot;Zaragoza&quot;}],&quot;FR&quot;:[{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;01&quot;,&quot;state&quot;:&quot;Ain&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;02&quot;,&quot;state&quot;:&quot;Aisne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;03&quot;,&quot;state&quot;:&quot;Allier&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;04&quot;,&quot;state&quot;:&quot;Alpes-de-Haute-Provence&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;06&quot;,&quot;state&quot;:&quot;Alpes-Maritimes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;07&quot;,&quot;state&quot;:&quot;Ard\u00e8che&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;08&quot;,&quot;state&quot;:&quot;Ardennes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;09&quot;,&quot;state&quot;:&quot;Ari\u00e8ge&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;10&quot;,&quot;state&quot;:&quot;Aube&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;11&quot;,&quot;state&quot;:&quot;Aude&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;12&quot;,&quot;state&quot;:&quot;Aveyron&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;67&quot;,&quot;state&quot;:&quot;Bas-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;13&quot;,&quot;state&quot;:&quot;Bouches-du-Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;14&quot;,&quot;state&quot;:&quot;Calvados&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;15&quot;,&quot;state&quot;:&quot;Cantal&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;16&quot;,&quot;state&quot;:&quot;Charente&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;17&quot;,&quot;state&quot;:&quot;Charente-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;18&quot;,&quot;state&quot;:&quot;Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;19&quot;,&quot;state&quot;:&quot;Corr\u00e8ze&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2A&quot;,&quot;state&quot;:&quot;Corse-du-Sud&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;21&quot;,&quot;state&quot;:&quot;C\u00f4te-d'Or&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;22&quot;,&quot;state&quot;:&quot;C\u00f4tes-d'Armor&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;23&quot;,&quot;state&quot;:&quot;Creuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;79&quot;,&quot;state&quot;:&quot;Deux-S\u00e8vres&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;24&quot;,&quot;state&quot;:&quot;Dordogne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;25&quot;,&quot;state&quot;:&quot;Doubs&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;26&quot;,&quot;state&quot;:&quot;Dr\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;91&quot;,&quot;state&quot;:&quot;Essonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;27&quot;,&quot;state&quot;:&quot;Eure&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;28&quot;,&quot;state&quot;:&quot;Eure-et-Loir&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;29&quot;,&quot;state&quot;:&quot;Finist\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;30&quot;,&quot;state&quot;:&quot;Gard&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;32&quot;,&quot;state&quot;:&quot;Gers&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;33&quot;,&quot;state&quot;:&quot;Gironde&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;68&quot;,&quot;state&quot;:&quot;Haut-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2B&quot;,&quot;state&quot;:&quot;Haute-Corse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;31&quot;,&quot;state&quot;:&quot;Haute-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;43&quot;,&quot;state&quot;:&quot;Haute-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;52&quot;,&quot;state&quot;:&quot;Haute-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;70&quot;,&quot;state&quot;:&quot;Haute-Sa\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;74&quot;,&quot;state&quot;:&quot;Haute-Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;87&quot;,&quot;state&quot;:&quot;Haute-Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;05&quot;,&quot;state&quot;:&quot;Hautes-Alpes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;65&quot;,&quot;state&quot;:&quot;Hautes-Pyr\u00e9n\u00e9es&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;92&quot;,&quot;state&quot;:&quot;Hauts-de-Seine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;34&quot;,&quot;state&quot;:&quot;H\u00e9rault&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;35&quot;,&quot;state&quot;:&quot;Ille-et-Vilaine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;36&quot;,&quot;state&quot;:&quot;Indre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;37&quot;,&quot;state&quot;:&quot;Indre-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;38&quot;,&quot;state&quot;:&quot;Is\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;39&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;40&quot;,&quot;state&quot;:&quot;Landes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;41&quot;,&quot;state&quot;:&quot;Loir-et-Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;42&quot;,&quot;state&quot;:&quot;Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;44&quot;,&quot;state&quot;:&quot;Loire-Atlantique&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;45&quot;,&quot;state&quot;:&quot;Loiret&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;46&quot;,&quot;state&quot;:&quot;Lot&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;47&quot;,&quot;state&quot;:&quot;Lot-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;48&quot;,&quot;state&quot;:&quot;Loz\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;49&quot;,&quot;state&quot;:&quot;Maine-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;50&quot;,&quot;state&quot;:&quot;Manche&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;51&quot;,&quot;state&quot;:&quot;Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;53&quot;,&quot;state&quot;:&quot;Mayenne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;54&quot;,&quot;state&quot;:&quot;Meurthe-et-Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;55&quot;,&quot;state&quot;:&quot;Meuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;56&quot;,&quot;state&quot;:&quot;Morbihan&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;57&quot;,&quot;state&quot;:&quot;Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;58&quot;,&quot;state&quot;:&quot;Ni\u00e8vre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;59&quot;,&quot;state&quot;:&quot;Nord&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;60&quot;,&quot;state&quot;:&quot;Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;61&quot;,&quot;state&quot;:&quot;Orne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;75&quot;,&quot;state&quot;:&quot;Paris&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;62&quot;,&quot;state&quot;:&quot;Pas-de-Calais&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;63&quot;,&quot;state&quot;:&quot;Puy-de-D\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;64&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Atlantiques&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;66&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Orientales&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;69&quot;,&quot;state&quot;:&quot;Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;71&quot;,&quot;state&quot;:&quot;Sa\u00f4ne-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;72&quot;,&quot;state&quot;:&quot;Sarthe&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;73&quot;,&quot;state&quot;:&quot;Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;77&quot;,&quot;state&quot;:&quot;Seine-et-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;76&quot;,&quot;state&quot;:&quot;Seine-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;93&quot;,&quot;state&quot;:&quot;Seine-Saint-Denis&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;80&quot;,&quot;state&quot;:&quot;Somme&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;81&quot;,&quot;state&quot;:&quot;Tarn&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;82&quot;,&quot;state&quot;:&quot;Tarn-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;90&quot;,&quot;state&quot;:&quot;Territoire de Belfort&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;95&quot;,&quot;state&quot;:&quot;Val-d'Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;94&quot;,&quot;state&quot;:&quot;Val-de-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;83&quot;,&quot;state&quot;:&quot;Var&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;84&quot;,&quot;state&quot;:&quot;Vaucluse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;85&quot;,&quot;state&quot;:&quot;Vend\u00e9e&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;86&quot;,&quot;state&quot;:&quot;Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;88&quot;,&quot;state&quot;:&quot;Vosges&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;89&quot;,&quot;state&quot;:&quot;Yonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;78&quot;,&quot;state&quot;:&quot;Yvelines&quot;}],&quot;GB&quot;:[{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABN&quot;,&quot;state&quot;:&quot;Aberdeen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABNS&quot;,&quot;state&quot;:&quot;Aberdeenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANG&quot;,&quot;state&quot;:&quot;Anglesey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AGS&quot;,&quot;state&quot;:&quot;Angus&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARY&quot;,&quot;state&quot;:&quot;Argyll and Bute&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AVN&quot;,&quot;state&quot;:&quot;Avon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BAN&quot;,&quot;state&quot;:&quot;Banffshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEDS&quot;,&quot;state&quot;:&quot;Bedfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BERKS&quot;,&quot;state&quot;:&quot;Berkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEW&quot;,&quot;state&quot;:&quot;Berwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BLA&quot;,&quot;state&quot;:&quot;Blaenau Gwent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BRI&quot;,&quot;state&quot;:&quot;Bridgend&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BSTL&quot;,&quot;state&quot;:&quot;Bristol&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BUCKS&quot;,&quot;state&quot;:&quot;Buckinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAE&quot;,&quot;state&quot;:&quot;Caerphilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAI&quot;,&quot;state&quot;:&quot;Caithness&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAMBS&quot;,&quot;state&quot;:&quot;Cambridgeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDF&quot;,&quot;state&quot;:&quot;Cardiff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CARM&quot;,&quot;state&quot;:&quot;Carmarthenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDGN&quot;,&quot;state&quot;:&quot;Ceredigion&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CHES&quot;,&quot;state&quot;:&quot;Cheshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLACK&quot;,&quot;state&quot;:&quot;Clackmannanshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLV&quot;,&quot;state&quot;:&quot;Cleveland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CWD&quot;,&quot;state&quot;:&quot;Clwyd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CON&quot;,&quot;state&quot;:&quot;Conwy&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CORN&quot;,&quot;state&quot;:&quot;Cornwall&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANT&quot;,&quot;state&quot;:&quot;County Antrim&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARM&quot;,&quot;state&quot;:&quot;County Armagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOW&quot;,&quot;state&quot;:&quot;County Down&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FER&quot;,&quot;state&quot;:&quot;County Fermanagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDY&quot;,&quot;state&quot;:&quot;County Londonderry&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TYR&quot;,&quot;state&quot;:&quot;County Tyrone&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CMA&quot;,&quot;state&quot;:&quot;Cumbria&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DNBG&quot;,&quot;state&quot;:&quot;Denbighshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DERBY&quot;,&quot;state&quot;:&quot;Derbyshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DVN&quot;,&quot;state&quot;:&quot;Devon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOR&quot;,&quot;state&quot;:&quot;Dorset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DGL&quot;,&quot;state&quot;:&quot;Dumfries and Galloway&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFS&quot;,&quot;state&quot;:&quot;Dumfries-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUND&quot;,&quot;state&quot;:&quot;Dundee&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DHM&quot;,&quot;state&quot;:&quot;Durham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFD&quot;,&quot;state&quot;:&quot;Dyfed&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYE&quot;,&quot;state&quot;:&quot;East Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUNBE&quot;,&quot;state&quot;:&quot;East Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LOTE&quot;,&quot;state&quot;:&quot;East Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RENE&quot;,&quot;state&quot;:&quot;East Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ERYS&quot;,&quot;state&quot;:&quot;East Riding of Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXE&quot;,&quot;state&quot;:&quot;East Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;EDIN&quot;,&quot;state&quot;:&quot;Edinburgh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ESX&quot;,&quot;state&quot;:&quot;Essex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FALK&quot;,&quot;state&quot;:&quot;Falkirk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FFE&quot;,&quot;state&quot;:&quot;Fife&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FLINT&quot;,&quot;state&quot;:&quot;Flintshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLAS&quot;,&quot;state&quot;:&quot;Glasgow&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLOS&quot;,&quot;state&quot;:&quot;Gloucestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDN&quot;,&quot;state&quot;:&quot;Greater London&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MCH&quot;,&quot;state&quot;:&quot;Greater Manchester&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GDD&quot;,&quot;state&quot;:&quot;Gwynedd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HANTS&quot;,&quot;state&quot;:&quot;Hampshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HWR&quot;,&quot;state&quot;:&quot;Herefordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HERTS&quot;,&quot;state&quot;:&quot;Hertfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HLD&quot;,&quot;state&quot;:&quot;Highlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HUM&quot;,&quot;state&quot;:&quot;Humberside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IVER&quot;,&quot;state&quot;:&quot;Inverclyde&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;INV&quot;,&quot;state&quot;:&quot;Inverness-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOW&quot;,&quot;state&quot;:&quot;Isle of Wight&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOS&quot;,&quot;state&quot;:&quot;Isles of Scilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KNT&quot;,&quot;state&quot;:&quot;Kent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KCD&quot;,&quot;state&quot;:&quot;Kincardineshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANCS&quot;,&quot;state&quot;:&quot;Lancashire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LEICS&quot;,&quot;state&quot;:&quot;Leicestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LINCS&quot;,&quot;state&quot;:&quot;Lincolnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MER&quot;,&quot;state&quot;:&quot;Merionethshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MSY&quot;,&quot;state&quot;:&quot;Merseyside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MERT&quot;,&quot;state&quot;:&quot;Merthyr Tydfil&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MDX&quot;,&quot;state&quot;:&quot;Middlesex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MLOT&quot;,&quot;state&quot;:&quot;Midlothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MMOUTH&quot;,&quot;state&quot;:&quot;Monmouthshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MORAY&quot;,&quot;state&quot;:&quot;Moray&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NAI&quot;,&quot;state&quot;:&quot;Nairnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NPRTAL&quot;,&quot;state&quot;:&quot;Neath Port Talbot&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NEWPT&quot;,&quot;state&quot;:&quot;Newport&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOR&quot;,&quot;state&quot;:&quot;Norfolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYN&quot;,&quot;state&quot;:&quot;North Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANN&quot;,&quot;state&quot;:&quot;North Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSN&quot;,&quot;state&quot;:&quot;North Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NHM&quot;,&quot;state&quot;:&quot;Northamptonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NLD&quot;,&quot;state&quot;:&quot;Northumberland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOT&quot;,&quot;state&quot;:&quot;Nottinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ORK&quot;,&quot;state&quot;:&quot;Orkney Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;OFE&quot;,&quot;state&quot;:&quot;Oxfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEE&quot;,&quot;state&quot;:&quot;Peebles-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEM&quot;,&quot;state&quot;:&quot;Pembrokeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PERTH&quot;,&quot;state&quot;:&quot;Perth and Kinross&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PWS&quot;,&quot;state&quot;:&quot;Powys&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;REN&quot;,&quot;state&quot;:&quot;Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RHON&quot;,&quot;state&quot;:&quot;Rhondda Cynon Taff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ROX&quot;,&quot;state&quot;:&quot;Roxburghshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RUT&quot;,&quot;state&quot;:&quot;Rutland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BOR&quot;,&quot;state&quot;:&quot;Scottish Borders&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SEL&quot;,&quot;state&quot;:&quot;Selkirkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SHET&quot;,&quot;state&quot;:&quot;Shetland Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Shropshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SOM&quot;,&quot;state&quot;:&quot;Somerset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYS&quot;,&quot;state&quot;:&quot;South Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANS&quot;,&quot;state&quot;:&quot;South Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SYK&quot;,&quot;state&quot;:&quot;South Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFD&quot;,&quot;state&quot;:&quot;Staffordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STIR&quot;,&quot;state&quot;:&quot;Stirling&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STI&quot;,&quot;state&quot;:&quot;Stirlingshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFK&quot;,&quot;state&quot;:&quot;Suffolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SRY&quot;,&quot;state&quot;:&quot;Surrey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SUT&quot;,&quot;state&quot;:&quot;Sutherland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SWAN&quot;,&quot;state&quot;:&quot;Swansea&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TORF&quot;,&quot;state&quot;:&quot;Torfaen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TWR&quot;,&quot;state&quot;:&quot;Tyne and Wear&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;VGLAM&quot;,&quot;state&quot;:&quot;Vale of Glamorgan&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WARKS&quot;,&quot;state&quot;:&quot;Warwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WDUN&quot;,&quot;state&quot;:&quot;West Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLOT&quot;,&quot;state&quot;:&quot;West Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WMD&quot;,&quot;state&quot;:&quot;West Midlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXW&quot;,&quot;state&quot;:&quot;West Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSW&quot;,&quot;state&quot;:&quot;West Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIL&quot;,&quot;state&quot;:&quot;Western Isles&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIG&quot;,&quot;state&quot;:&quot;Wigtownshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLT&quot;,&quot;state&quot;:&quot;Wiltshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WORCS&quot;,&quot;state&quot;:&quot;Worcestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WRX&quot;,&quot;state&quot;:&quot;Wrexham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YKS&quot;,&quot;state&quot;:&quot;Yorkshire&quot;}],&quot;IT&quot;:[{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Agrigento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alessandria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AN&quot;,&quot;state&quot;:&quot;Ancona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AO&quot;,&quot;state&quot;:&quot;Aosta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arezzo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AP&quot;,&quot;state&quot;:&quot;Ascoli Piceno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AT&quot;,&quot;state&quot;:&quot;Asti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;Avellino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Bari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;Belluno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;Benevento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BG&quot;,&quot;state&quot;:&quot;Bergamo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Biella&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BO&quot;,&quot;state&quot;:&quot;Bologna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;Bolzano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;Brescia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;Brindisi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;Cagliari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;Caltanissetta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CB&quot;,&quot;state&quot;:&quot;Campobasso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CI&quot;,&quot;state&quot;:&quot;Carbonia-Iglesias&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Caserta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Catania&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CZ&quot;,&quot;state&quot;:&quot;Catanzaro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CH&quot;,&quot;state&quot;:&quot;Chieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Como&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Cosenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Cremona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Crotone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CN&quot;,&quot;state&quot;:&quot;Cuneo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;EN&quot;,&quot;state&quot;:&quot;Enna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FE&quot;,&quot;state&quot;:&quot;Ferrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FI&quot;,&quot;state&quot;:&quot;Firenze&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FG&quot;,&quot;state&quot;:&quot;Foggia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FC&quot;,&quot;state&quot;:&quot;Forli-Cesena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Frosinone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Genova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GO&quot;,&quot;state&quot;:&quot;Gorizia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grosseto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IM&quot;,&quot;state&quot;:&quot;Imperia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;Isernia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AQ&quot;,&quot;state&quot;:&quot;L'Aquila&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SP&quot;,&quot;state&quot;:&quot;La Spezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LT&quot;,&quot;state&quot;:&quot;Latina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Lecce&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LC&quot;,&quot;state&quot;:&quot;Lecco&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Livorno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;Lodi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucca&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MC&quot;,&quot;state&quot;:&quot;Macerata&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Mantova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Massa-Carrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Matera&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Medio Campidano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Messina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Milano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Modena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Napoli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NO&quot;,&quot;state&quot;:&quot;Novara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nuoro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OG&quot;,&quot;state&quot;:&quot;Ogliastra&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;Olbia-Tempio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oristano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PD&quot;,&quot;state&quot;:&quot;Padova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Palermo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Parma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PV&quot;,&quot;state&quot;:&quot;Pavia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PG&quot;,&quot;state&quot;:&quot;Perugia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PU&quot;,&quot;state&quot;:&quot;Pesaro e Urbino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Pescara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PC&quot;,&quot;state&quot;:&quot;Piacenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PI&quot;,&quot;state&quot;:&quot;Pisa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PT&quot;,&quot;state&quot;:&quot;Pistoia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PN&quot;,&quot;state&quot;:&quot;Pordenone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PZ&quot;,&quot;state&quot;:&quot;Potenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Prato&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RG&quot;,&quot;state&quot;:&quot;Ragusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RA&quot;,&quot;state&quot;:&quot;Ravenna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RC&quot;,&quot;state&quot;:&quot;Reggio Calabria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RE&quot;,&quot;state&quot;:&quot;Reggio Emilia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RN&quot;,&quot;state&quot;:&quot;Rimini&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RM&quot;,&quot;state&quot;:&quot;Roma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RO&quot;,&quot;state&quot;:&quot;Rovigo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salerno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Sassari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;Savona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SI&quot;,&quot;state&quot;:&quot;Siena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SR&quot;,&quot;state&quot;:&quot;Siracusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Sondrio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Taranto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teramo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;Terni&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Torino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TP&quot;,&quot;state&quot;:&quot;Trapani&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Trento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TV&quot;,&quot;state&quot;:&quot;Treviso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TS&quot;,&quot;state&quot;:&quot;Trieste&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udine&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Varese&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VE&quot;,&quot;state&quot;:&quot;Venezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VB&quot;,&quot;state&quot;:&quot;Verbano-Cusio-Ossola&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VC&quot;,&quot;state&quot;:&quot;Vercelli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VR&quot;,&quot;state&quot;:&quot;Verona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VV&quot;,&quot;state&quot;:&quot;Vibo Valentia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Vicenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Viterbo&quot;}],&quot;JP&quot;:[{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AICHI&quot;,&quot;state&quot;:&quot;AICHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AKITA&quot;,&quot;state&quot;:&quot;AKITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AOMORI&quot;,&quot;state&quot;:&quot;AOMORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;CHIBA&quot;,&quot;state&quot;:&quot;CHIBA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;EHIME&quot;,&quot;state&quot;:&quot;EHIME&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUI&quot;,&quot;state&quot;:&quot;FUKUI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUOKA&quot;,&quot;state&quot;:&quot;FUKUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUSHIMA&quot;,&quot;state&quot;:&quot;FUKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GIFU&quot;,&quot;state&quot;:&quot;GIFU&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GUMMA&quot;,&quot;state&quot;:&quot;GUMMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HIROSHIMA&quot;,&quot;state&quot;:&quot;HIROSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HOKKAIDO&quot;,&quot;state&quot;:&quot;HOKKAIDO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HYOGO&quot;,&quot;state&quot;:&quot;HYOGO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IBARAKI&quot;,&quot;state&quot;:&quot;IBARAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;ISHIKAWA&quot;,&quot;state&quot;:&quot;ISHIKAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IWATE&quot;,&quot;state&quot;:&quot;IWATE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGAWA&quot;,&quot;state&quot;:&quot;KAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGOSHIMA&quot;,&quot;state&quot;:&quot;KAGOSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KANAGAWA&quot;,&quot;state&quot;:&quot;KANAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KOCHI&quot;,&quot;state&quot;:&quot;KOCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KUMAMOTO&quot;,&quot;state&quot;:&quot;KUMAMOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KYOTO&quot;,&quot;state&quot;:&quot;KYOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIE&quot;,&quot;state&quot;:&quot;MIE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAGI&quot;,&quot;state&quot;:&quot;MIYAGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAZAKI&quot;,&quot;state&quot;:&quot;MIYAZAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGANO&quot;,&quot;state&quot;:&quot;NAGANO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGASAKI&quot;,&quot;state&quot;:&quot;NAGASAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NARA&quot;,&quot;state&quot;:&quot;NARA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NIIGATA&quot;,&quot;state&quot;:&quot;NIIGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OITA&quot;,&quot;state&quot;:&quot;OITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKAYAMA&quot;,&quot;state&quot;:&quot;OKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKINAWA&quot;,&quot;state&quot;:&quot;OKINAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OSAKA&quot;,&quot;state&quot;:&quot;OSAKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAGA&quot;,&quot;state&quot;:&quot;SAGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAITAMA&quot;,&quot;state&quot;:&quot;SAITAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIGA&quot;,&quot;state&quot;:&quot;SHIGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIMANE&quot;,&quot;state&quot;:&quot;SHIMANE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIZUOKA&quot;,&quot;state&quot;:&quot;SHIZUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOCHIGI&quot;,&quot;state&quot;:&quot;TOCHIGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKUSHIMA&quot;,&quot;state&quot;:&quot;TOKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKYO&quot;,&quot;state&quot;:&quot;TOKYO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOTTORI&quot;,&quot;state&quot;:&quot;TOTTORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOYAMA&quot;,&quot;state&quot;:&quot;TOYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;WAKAYAMA&quot;,&quot;state&quot;:&quot;WAKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGATA&quot;,&quot;state&quot;:&quot;YAMAGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGUCHI&quot;,&quot;state&quot;:&quot;YAMAGUCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMANASHI&quot;,&quot;state&quot;:&quot;YAMANASHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4e09\u91cd\u770c&quot;,&quot;state&quot;:&quot;\u4e09\u91cd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4eac\u90fd\u5e9c&quot;,&quot;state&quot;:&quot;\u4eac\u90fd\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4f50\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u4f50\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5175\u5eab\u770c&quot;,&quot;state&quot;:&quot;\u5175\u5eab\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5317\u6d77\u9053&quot;,&quot;state&quot;:&quot;\u5317\u6d77\u9053&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5343\u8449\u770c&quot;,&quot;state&quot;:&quot;\u5343\u8449\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u57fc\u7389\u770c&quot;,&quot;state&quot;:&quot;\u57fc\u7389\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u5206\u770c&quot;,&quot;state&quot;:&quot;\u5927\u5206\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u962a\u5e9c&quot;,&quot;state&quot;:&quot;\u5927\u962a\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5948\u826f\u770c&quot;,&quot;state&quot;:&quot;\u5948\u826f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bcc\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5bcc\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u53e3\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u53e3\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u5f62\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u5f62\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u68a8\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u68a8\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c90\u961c\u770c&quot;,&quot;state&quot;:&quot;\u5c90\u961c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca1\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5ca1\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca9\u624b\u770c&quot;,&quot;state&quot;:&quot;\u5ca9\u624b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5cf6\u6839\u770c&quot;,&quot;state&quot;:&quot;\u5cf6\u6839\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5e83\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5e83\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5fb3\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5fb3\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u5a9b\u770c&quot;,&quot;state&quot;:&quot;\u611b\u5a9b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u611b\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u65b0\u6f5f\u770c&quot;,&quot;state&quot;:&quot;\u65b0\u6f5f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6771\u4eac\u90fd&quot;,&quot;state&quot;:&quot;\u6771\u4eac\u90fd&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6803\u6728\u770c&quot;,&quot;state&quot;:&quot;\u6803\u6728\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6c96\u7e04\u770c&quot;,&quot;state&quot;:&quot;\u6c96\u7e04\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6ecb\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u6ecb\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u718a\u672c\u770c&quot;,&quot;state&quot;:&quot;\u718a\u672c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u77f3\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u77f3\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u4e95\u770c&quot;,&quot;state&quot;:&quot;\u798f\u4e95\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u79cb\u7530\u770c&quot;,&quot;state&quot;:&quot;\u79cb\u7530\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u7fa4\u99ac\u770c&quot;,&quot;state&quot;:&quot;\u7fa4\u99ac\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u8328\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u8328\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u9577\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u91ce\u770c&quot;,&quot;state&quot;:&quot;\u9577\u91ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9752\u68ee\u770c&quot;,&quot;state&quot;:&quot;\u9752\u68ee\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9759\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u9759\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9999\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u9999\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ad8\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u9ad8\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ce5\u53d6\u770c&quot;,&quot;state&quot;:&quot;\u9ce5\u53d6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;}],&quot;NL&quot;:[{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;DR&quot;,&quot;state&quot;:&quot;Drenthe&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Flevoland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Friesland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gelderland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Groningen&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Limburg&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;Noord Brabant&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;Noord Holland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;OV&quot;,&quot;state&quot;:&quot;Overijssel&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utrecht&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZE&quot;,&quot;state&quot;:&quot;Zeeland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zuid Holland&quot;}],&quot;RO&quot;:[{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;ALBA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;ARAD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;ARGES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;BACAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BH&quot;,&quot;state&quot;:&quot;BIHOR&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;BISTRITA-NASAUD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BT&quot;,&quot;state&quot;:&quot;BOTOSANI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;BRAILA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BV&quot;,&quot;state&quot;:&quot;BRASOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;BUCURESTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;BUZAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;CALARASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;CARAS-SEVERIN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CJ&quot;,&quot;state&quot;:&quot;CLUJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CV&quot;,&quot;state&quot;:&quot;COVASNA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DB&quot;,&quot;state&quot;:&quot;DAMBOVITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DJ&quot;,&quot;state&quot;:&quot;DOLJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;GALATI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;GIURGIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GJ&quot;,&quot;state&quot;:&quot;GORJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HR&quot;,&quot;state&quot;:&quot;HARGHITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HD&quot;,&quot;state&quot;:&quot;HUNEDOARA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;IALOMITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;IASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IF&quot;,&quot;state&quot;:&quot;ILFOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MM&quot;,&quot;state&quot;:&quot;MARAMURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MH&quot;,&quot;state&quot;:&quot;MEHEDINTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;MURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;NEAMT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;OLT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;PH&quot;,&quot;state&quot;:&quot;PRAHOVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SJ&quot;,&quot;state&quot;:&quot;SALAJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SM&quot;,&quot;state&quot;:&quot;SATU MARE&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SB&quot;,&quot;state&quot;:&quot;SIBIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;SUCEAVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;TELEORMAN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TM&quot;,&quot;state&quot;:&quot;TIMIS&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TL&quot;,&quot;state&quot;:&quot;TULCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VL&quot;,&quot;state&quot;:&quot;VALCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;VASLUI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VN&quot;,&quot;state&quot;:&quot;VRANCEA&quot;}],&quot;RU&quot;:[{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ALT&quot;,&quot;state&quot;:&quot;Altajskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AMU&quot;,&quot;state&quot;:&quot;Amurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ARK&quot;,&quot;state&quot;:&quot;Arhangel'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AST&quot;,&quot;state&quot;:&quot;Astrahanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BEL&quot;,&quot;state&quot;:&quot;Belgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BRY&quot;,&quot;state&quot;:&quot;Brjanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Chechenskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHE&quot;,&quot;state&quot;:&quot;Cheljabinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHU&quot;,&quot;state&quot;:&quot;Chukotskij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Chuvashskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YEV&quot;,&quot;state&quot;:&quot;Evrejskaja avtonomnaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHA&quot;,&quot;state&quot;:&quot;Habarovskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHM&quot;,&quot;state&quot;:&quot;Hanty-Mansijskij avtonomnyj okrug - Jugra&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IRK&quot;,&quot;state&quot;:&quot;Irkutskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IVA&quot;,&quot;state&quot;:&quot;Ivanovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAN&quot;,&quot;state&quot;:&quot;Jamalo-Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAR&quot;,&quot;state&quot;:&quot;Jaroslavskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KB&quot;,&quot;state&quot;:&quot;Kabardino-Balkarskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGD&quot;,&quot;state&quot;:&quot;Kaliningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KLU&quot;,&quot;state&quot;:&quot;Kaluzhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KAM&quot;,&quot;state&quot;:&quot;Kamchatskiy kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KC&quot;,&quot;state&quot;:&quot;Karachaevo-Cherkesskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KEM&quot;,&quot;state&quot;:&quot;Kemerovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIR&quot;,&quot;state&quot;:&quot;Kirovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KOS&quot;,&quot;state&quot;:&quot;Kostromskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KDA&quot;,&quot;state&quot;:&quot;Krasnodarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIA&quot;,&quot;state&quot;:&quot;Krasnojarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGN&quot;,&quot;state&quot;:&quot;Kurganskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KRS&quot;,&quot;state&quot;:&quot;Kurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LEN&quot;,&quot;state&quot;:&quot;Leningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LIP&quot;,&quot;state&quot;:&quot;Lipeckaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MAG&quot;,&quot;state&quot;:&quot;Magadanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOS&quot;,&quot;state&quot;:&quot;Moskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOW&quot;,&quot;state&quot;:&quot;Moskva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MUR&quot;,&quot;state&quot;:&quot;Murmanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NEN&quot;,&quot;state&quot;:&quot;Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NIZ&quot;,&quot;state&quot;:&quot;Nizhegorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NGR&quot;,&quot;state&quot;:&quot;Novgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NVS&quot;,&quot;state&quot;:&quot;Novosibirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;OMS&quot;,&quot;state&quot;:&quot;Omskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORE&quot;,&quot;state&quot;:&quot;Orenburgskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORL&quot;,&quot;state&quot;:&quot;Orlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PNZ&quot;,&quot;state&quot;:&quot;Penzenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PER&quot;,&quot;state&quot;:&quot;Permskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PRI&quot;,&quot;state&quot;:&quot;Primorskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PSK&quot;,&quot;state&quot;:&quot;Pskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AD&quot;,&quot;state&quot;:&quot;Respublika Adygeja&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Respublika Altaj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Respublika Bashkortostan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Respublika Burjatija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;DA&quot;,&quot;state&quot;:&quot;Respublika Dagestan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KK&quot;,&quot;state&quot;:&quot;Respublika Hakasija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Respublika Ingushetija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KL&quot;,&quot;state&quot;:&quot;Respublika Kalmykija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Respublika Karelija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KO&quot;,&quot;state&quot;:&quot;Respublika Komi&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Respublika Marij Jel&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Respublika Mordovija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Respublika Saha (Jakutija)&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Respublika Severnaja Osetija-Alanija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Respublika Tatarstan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TY&quot;,&quot;state&quot;:&quot;Respublika Tyva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;RYA&quot;,&quot;state&quot;:&quot;Rjazanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ROS&quot;,&quot;state&quot;:&quot;Rostovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAK&quot;,&quot;state&quot;:&quot;Sahalinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAM&quot;,&quot;state&quot;:&quot;Samarskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Sankt-Peterburg&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saratovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SMO&quot;,&quot;state&quot;:&quot;Smolenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;STA&quot;,&quot;state&quot;:&quot;Stavropol'skij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SVE&quot;,&quot;state&quot;:&quot;Sverdlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TAM&quot;,&quot;state&quot;:&quot;Tambovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TYU&quot;,&quot;state&quot;:&quot;Tjumenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TOM&quot;,&quot;state&quot;:&quot;Tomskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TUL&quot;,&quot;state&quot;:&quot;Tul'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TVE&quot;,&quot;state&quot;:&quot;Tverskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udmurtskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ULY&quot;,&quot;state&quot;:&quot;Ul'janovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLA&quot;,&quot;state&quot;:&quot;Vladimirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VGG&quot;,&quot;state&quot;:&quot;Volgogradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLG&quot;,&quot;state&quot;:&quot;Vologodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VOR&quot;,&quot;state&quot;:&quot;Voronezhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ZAB&quot;,&quot;state&quot;:&quot;Zabaykal'skiy kraj&quot;}],&quot;US&quot;:[{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alabama&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AK&quot;,&quot;state&quot;:&quot;Alaska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AZ&quot;,&quot;state&quot;:&quot;Arizona&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arkansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;California&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Colorado&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Connecticut&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DE&quot;,&quot;state&quot;:&quot;Delaware&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DC&quot;,&quot;state&quot;:&quot;District of Columbia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Florida&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GA&quot;,&quot;state&quot;:&quot;Georgia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guam&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;HI&quot;,&quot;state&quot;:&quot;Hawaii&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ID&quot;,&quot;state&quot;:&quot;Idaho&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;Illinois&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Indiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IA&quot;,&quot;state&quot;:&quot;Iowa&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KS&quot;,&quot;state&quot;:&quot;Kansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KY&quot;,&quot;state&quot;:&quot;Kentucky&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;LA&quot;,&quot;state&quot;:&quot;Louisiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Maine&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MD&quot;,&quot;state&quot;:&quot;Maryland&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;Massachusetts&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Michigan&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Minnesota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Mississippi&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Missouri&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Montana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Nebraska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NV&quot;,&quot;state&quot;:&quot;Nevada&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;New Hampshire&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NJ&quot;,&quot;state&quot;:&quot;New Jersey&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NM&quot;,&quot;state&quot;:&quot;New Mexico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NY&quot;,&quot;state&quot;:&quot;New York&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NC&quot;,&quot;state&quot;:&quot;North Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ND&quot;,&quot;state&quot;:&quot;North Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MP&quot;,&quot;state&quot;:&quot;Northern Mariana Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OH&quot;,&quot;state&quot;:&quot;Ohio&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OK&quot;,&quot;state&quot;:&quot;Oklahoma&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oregon&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Pennsylvania&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Puerto Rico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rhode Island&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SC&quot;,&quot;state&quot;:&quot;South Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SD&quot;,&quot;state&quot;:&quot;South Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Tennessee&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TX&quot;,&quot;state&quot;:&quot;Texas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utah&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Vermont&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Virgin Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Washington&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WV&quot;,&quot;state&quot;:&quot;West Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WI&quot;,&quot;state&quot;:&quot;Wisconsin&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WY&quot;,&quot;state&quot;:&quot;Wyoming&quot;}]},

// [filosof]
        countries_with_codes: {&quot;RO&quot;:&quot;RO&quot;}
// [/filosof]
    });

    
    $.ceFormValidator('setZipcode', {
        US: {
            regexp: /^(\d{5})(-\d{4})?$/,
            format: '01342 (01342-5678)'
        },
        CA: {
            regexp: /^(\w{3} ?\w{3})$/,
            format: 'V1A OB1 (V1AOB1)'
        },
        RU: {
            regexp: /^(\d{6})?$/,
            format: '123456'
        }
    });
    

}(Tygh, Tygh.$));
//]]>

    




    
                
                
                


 
     Select



    

               
            ,  
        {user_name}({email})
        

       
    
    
    

                    
                
            
        
        
        Purchase Date
        
                
    
    

    
    
    



    

    .ui-timepicker-div .ui-widget-header { margin-bottom: 8px; }
    .ui-timepicker-div dl { text-align: left; }
    .ui-timepicker-div dl dt { float: left; clear:left; padding: 0 0 0 5px; }
    .ui-timepicker-div dl dd { margin: 0 10px 10px 40%; }
    .ui-timepicker-div td { font-size: 90%; }
    .ui-tpicker-grid-label { background: none; border: none; margin: 0; padding: 0; }
    .ui-timepicker-div .ui_tpicker_unit_hide{ display: none; }

    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input { background: none; color: inherit; border: none; outline: none; border-bottom: solid 1px #555; width: 95%; }
    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input:focus { border-bottom-color: #aaa; }

    .ui-timepicker-rtl{ direction: rtl; }
    .ui-timepicker-rtl dl { text-align: right; padding: 0 5px 0 0; }
    .ui-timepicker-rtl dl dt{ float: right; clear: right; }
    .ui-timepicker-rtl dl dd { margin: 0 40% 10px 10px; }

    /* Shortened version style */
    .ui-timepicker-div.ui-timepicker-oneLine { padding-right: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time,
    .ui-timepicker-div.ui-timepicker-oneLine dt { display: none; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time_label { display: block; padding-top: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine dl { text-align: right; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd > div { display:inline-block; margin:0; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_minute:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_second:before { content:':'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_millisec:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_microsec:before { content:'.'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide,
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide:before{ display: none; }




//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
        // Keep variable name 'calendar_config' and its scope (global) for correct cloning with settings
        // (see js/tygh/node_cloning.js)
        calendar_config = {
            changeMonth: true,
            duration: 'fast',
            changeYear: true,
            numberOfMonths: 1,
            selectOtherMonths: true,
            showOtherMonths: true,
                        maxDate:'+0D',            firstDay: 1,
            dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            yearRange: '2015:2023',
            dateFormat: 'dd/mm/yy'
        };
        if ($('#search-purchase-date_0').hasClass('cm-datetimepicker')) {
            $('#search-purchase-date_0').datetimepicker(
                calendar_config
            ).attr('readonly', 'readonly');
        } else {
            $('#search-purchase-date_0').datepicker(
                calendar_config
            ).attr('readonly', 'readonly');
        }
    });
}(Tygh, Tygh.$));
//]]>


        
    
    
            


 
    



        Reset
    

                        
                        
                            
                                Where to find the code?
                                
                            
                        
                    
                    
    
                    
                        or
                            


 
     Register New
    


                    
                                            
                        
                            
                                

                                    


 
    



                            
                        
                                    
            
        
        
        Register New
        
            
                
    
    
    
    
        
            Enter Device ID (Codentify)
            
                









    //&lt;![CDATA[
    (function(_, $) {
        $('.device-code-select_device_register_0').groupinputs();
    }(Tygh, Tygh.$));
    //]]>

            
        
                    
                Retailer
                
                                        
                        
                        
                            
                        
                        
                            






    
//&lt;![CDATA[
(function(_, $) {

    /* Do not put this code to document.ready, because it should be
       initialized first
    */
    $.ceRebuildStates('init', {
        default_country: 'RO',
        states: {&quot;&quot;:[{&quot;country_code&quot;:&quot;&quot;,&quot;code&quot;:&quot;CONSTANTA&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;}],&quot;AU&quot;:[{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;ACT&quot;,&quot;state&quot;:&quot;Australian Capital Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NSW&quot;,&quot;state&quot;:&quot;New South Wales&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northern Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;QLD&quot;,&quot;state&quot;:&quot;Queensland&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;South Australia&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;TAS&quot;,&quot;state&quot;:&quot;Tasmania&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;VIC&quot;,&quot;state&quot;:&quot;Victoria&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Western Australia&quot;}],&quot;BG&quot;:[{&quot;country_code&quot;:&quot;BG&quot;,&quot;code&quot;:&quot;SF&quot;,&quot;state&quot;:&quot;Sofia&quot;}],&quot;CA&quot;:[{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Alberta&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;British Columbia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;MB&quot;,&quot;state&quot;:&quot;Manitoba&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;New Brunswick&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NL&quot;,&quot;state&quot;:&quot;Newfoundland and Labrador&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northwest Territories&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NS&quot;,&quot;state&quot;:&quot;Nova Scotia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nunavut&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;ON&quot;,&quot;state&quot;:&quot;Ontario&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Prince Edward Island&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;QC&quot;,&quot;state&quot;:&quot;Quebec&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;SK&quot;,&quot;state&quot;:&quot;Saskatchewan&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;YT&quot;,&quot;state&quot;:&quot;Yukon&quot;}],&quot;CH&quot;:[{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Ext\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AI&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Int\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Argovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;B\u00e2le-Campagne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;B\u00e2le-Ville&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BE&quot;,&quot;state&quot;:&quot;Berne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Fribourg&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gen\u00e8ve&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;Glaris&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grisons&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;JU&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucerne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Neuch\u00e2tel&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NW&quot;,&quot;state&quot;:&quot;Nidwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;OW&quot;,&quot;state&quot;:&quot;Obwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Saint-Gall&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SH&quot;,&quot;state&quot;:&quot;Schaffhouse&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SZ&quot;,&quot;state&quot;:&quot;Schwytz&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soleure&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TI&quot;,&quot;state&quot;:&quot;Tessin&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TG&quot;,&quot;state&quot;:&quot;Thurgovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;UR&quot;,&quot;state&quot;:&quot;Uri&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Valais&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VD&quot;,&quot;state&quot;:&quot;Vaud&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZG&quot;,&quot;state&quot;:&quot;Zoug&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zurich&quot;}],&quot;DE&quot;:[{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAW&quot;,&quot;state&quot;:&quot;Baden-W\u00fcrttemberg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAY&quot;,&quot;state&quot;:&quot;Bayern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BER&quot;,&quot;state&quot;:&quot;Berlin&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRG&quot;,&quot;state&quot;:&quot;Branderburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRE&quot;,&quot;state&quot;:&quot;Bremen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HAM&quot;,&quot;state&quot;:&quot;Hamburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HES&quot;,&quot;state&quot;:&quot;Hessen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;MEC&quot;,&quot;state&quot;:&quot;Mecklenburg-Vorpommern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NDS&quot;,&quot;state&quot;:&quot;Niedersachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NRW&quot;,&quot;state&quot;:&quot;Nordrhein-Westfalen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;RHE&quot;,&quot;state&quot;:&quot;Rheinland-Pfalz&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saarland&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAS&quot;,&quot;state&quot;:&quot;Sachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAC&quot;,&quot;state&quot;:&quot;Sachsen-Anhalt&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SCN&quot;,&quot;state&quot;:&quot;Schleswig-Holstein&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;THE&quot;,&quot;state&quot;:&quot;Th\u00fcringen&quot;}],&quot;ES&quot;:[{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;C&quot;,&quot;state&quot;:&quot;A Coru\u00f1a&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;\u00c1lava&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Albacete&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;A&quot;,&quot;state&quot;:&quot;Alicante&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Almer\u00eda&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;O&quot;,&quot;state&quot;:&quot;Asturias&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;\u00c1vila&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Badajoz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PM&quot;,&quot;state&quot;:&quot;Baleares&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;Barcelona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Burgos&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CC&quot;,&quot;state&quot;:&quot;C\u00e1ceres&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;C\u00e1diz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;S&quot;,&quot;state&quot;:&quot;Cantabria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Castell\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Ceuta&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Ciudad Real&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;C\u00f3rdoba&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Cuenca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GI&quot;,&quot;state&quot;:&quot;Girona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Granada&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guadalajara&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Guip\u00fazcoa&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;H&quot;,&quot;state&quot;:&quot;Huelva&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;HU&quot;,&quot;state&quot;:&quot;Huesca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;J&quot;,&quot;state&quot;:&quot;Ja\u00e9n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;La Rioja&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GC&quot;,&quot;state&quot;:&quot;Las Palmas&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Le\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;L&quot;,&quot;state&quot;:&quot;Lleida&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lugo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;M&quot;,&quot;state&quot;:&quot;Madrid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;M\u00e1laga&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ML&quot;,&quot;state&quot;:&quot;Melilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MU&quot;,&quot;state&quot;:&quot;Murcia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Navarra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Ourense&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;P&quot;,&quot;state&quot;:&quot;Palencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Pontevedra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salamanca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TF&quot;,&quot;state&quot;:&quot;Santa Cruz de Tenerife&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Segovia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Sevilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;T&quot;,&quot;state&quot;:&quot;Tarragona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teruel&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Toledo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;V&quot;,&quot;state&quot;:&quot;Valencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Valladolid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Vizcaya&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ZA&quot;,&quot;state&quot;:&quot;Zamora&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;Z&quot;,&quot;state&quot;:&quot;Zaragoza&quot;}],&quot;FR&quot;:[{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;01&quot;,&quot;state&quot;:&quot;Ain&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;02&quot;,&quot;state&quot;:&quot;Aisne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;03&quot;,&quot;state&quot;:&quot;Allier&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;04&quot;,&quot;state&quot;:&quot;Alpes-de-Haute-Provence&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;06&quot;,&quot;state&quot;:&quot;Alpes-Maritimes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;07&quot;,&quot;state&quot;:&quot;Ard\u00e8che&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;08&quot;,&quot;state&quot;:&quot;Ardennes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;09&quot;,&quot;state&quot;:&quot;Ari\u00e8ge&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;10&quot;,&quot;state&quot;:&quot;Aube&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;11&quot;,&quot;state&quot;:&quot;Aude&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;12&quot;,&quot;state&quot;:&quot;Aveyron&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;67&quot;,&quot;state&quot;:&quot;Bas-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;13&quot;,&quot;state&quot;:&quot;Bouches-du-Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;14&quot;,&quot;state&quot;:&quot;Calvados&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;15&quot;,&quot;state&quot;:&quot;Cantal&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;16&quot;,&quot;state&quot;:&quot;Charente&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;17&quot;,&quot;state&quot;:&quot;Charente-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;18&quot;,&quot;state&quot;:&quot;Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;19&quot;,&quot;state&quot;:&quot;Corr\u00e8ze&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2A&quot;,&quot;state&quot;:&quot;Corse-du-Sud&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;21&quot;,&quot;state&quot;:&quot;C\u00f4te-d'Or&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;22&quot;,&quot;state&quot;:&quot;C\u00f4tes-d'Armor&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;23&quot;,&quot;state&quot;:&quot;Creuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;79&quot;,&quot;state&quot;:&quot;Deux-S\u00e8vres&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;24&quot;,&quot;state&quot;:&quot;Dordogne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;25&quot;,&quot;state&quot;:&quot;Doubs&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;26&quot;,&quot;state&quot;:&quot;Dr\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;91&quot;,&quot;state&quot;:&quot;Essonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;27&quot;,&quot;state&quot;:&quot;Eure&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;28&quot;,&quot;state&quot;:&quot;Eure-et-Loir&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;29&quot;,&quot;state&quot;:&quot;Finist\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;30&quot;,&quot;state&quot;:&quot;Gard&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;32&quot;,&quot;state&quot;:&quot;Gers&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;33&quot;,&quot;state&quot;:&quot;Gironde&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;68&quot;,&quot;state&quot;:&quot;Haut-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2B&quot;,&quot;state&quot;:&quot;Haute-Corse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;31&quot;,&quot;state&quot;:&quot;Haute-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;43&quot;,&quot;state&quot;:&quot;Haute-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;52&quot;,&quot;state&quot;:&quot;Haute-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;70&quot;,&quot;state&quot;:&quot;Haute-Sa\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;74&quot;,&quot;state&quot;:&quot;Haute-Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;87&quot;,&quot;state&quot;:&quot;Haute-Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;05&quot;,&quot;state&quot;:&quot;Hautes-Alpes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;65&quot;,&quot;state&quot;:&quot;Hautes-Pyr\u00e9n\u00e9es&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;92&quot;,&quot;state&quot;:&quot;Hauts-de-Seine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;34&quot;,&quot;state&quot;:&quot;H\u00e9rault&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;35&quot;,&quot;state&quot;:&quot;Ille-et-Vilaine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;36&quot;,&quot;state&quot;:&quot;Indre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;37&quot;,&quot;state&quot;:&quot;Indre-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;38&quot;,&quot;state&quot;:&quot;Is\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;39&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;40&quot;,&quot;state&quot;:&quot;Landes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;41&quot;,&quot;state&quot;:&quot;Loir-et-Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;42&quot;,&quot;state&quot;:&quot;Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;44&quot;,&quot;state&quot;:&quot;Loire-Atlantique&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;45&quot;,&quot;state&quot;:&quot;Loiret&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;46&quot;,&quot;state&quot;:&quot;Lot&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;47&quot;,&quot;state&quot;:&quot;Lot-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;48&quot;,&quot;state&quot;:&quot;Loz\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;49&quot;,&quot;state&quot;:&quot;Maine-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;50&quot;,&quot;state&quot;:&quot;Manche&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;51&quot;,&quot;state&quot;:&quot;Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;53&quot;,&quot;state&quot;:&quot;Mayenne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;54&quot;,&quot;state&quot;:&quot;Meurthe-et-Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;55&quot;,&quot;state&quot;:&quot;Meuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;56&quot;,&quot;state&quot;:&quot;Morbihan&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;57&quot;,&quot;state&quot;:&quot;Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;58&quot;,&quot;state&quot;:&quot;Ni\u00e8vre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;59&quot;,&quot;state&quot;:&quot;Nord&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;60&quot;,&quot;state&quot;:&quot;Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;61&quot;,&quot;state&quot;:&quot;Orne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;75&quot;,&quot;state&quot;:&quot;Paris&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;62&quot;,&quot;state&quot;:&quot;Pas-de-Calais&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;63&quot;,&quot;state&quot;:&quot;Puy-de-D\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;64&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Atlantiques&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;66&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Orientales&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;69&quot;,&quot;state&quot;:&quot;Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;71&quot;,&quot;state&quot;:&quot;Sa\u00f4ne-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;72&quot;,&quot;state&quot;:&quot;Sarthe&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;73&quot;,&quot;state&quot;:&quot;Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;77&quot;,&quot;state&quot;:&quot;Seine-et-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;76&quot;,&quot;state&quot;:&quot;Seine-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;93&quot;,&quot;state&quot;:&quot;Seine-Saint-Denis&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;80&quot;,&quot;state&quot;:&quot;Somme&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;81&quot;,&quot;state&quot;:&quot;Tarn&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;82&quot;,&quot;state&quot;:&quot;Tarn-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;90&quot;,&quot;state&quot;:&quot;Territoire de Belfort&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;95&quot;,&quot;state&quot;:&quot;Val-d'Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;94&quot;,&quot;state&quot;:&quot;Val-de-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;83&quot;,&quot;state&quot;:&quot;Var&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;84&quot;,&quot;state&quot;:&quot;Vaucluse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;85&quot;,&quot;state&quot;:&quot;Vend\u00e9e&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;86&quot;,&quot;state&quot;:&quot;Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;88&quot;,&quot;state&quot;:&quot;Vosges&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;89&quot;,&quot;state&quot;:&quot;Yonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;78&quot;,&quot;state&quot;:&quot;Yvelines&quot;}],&quot;GB&quot;:[{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABN&quot;,&quot;state&quot;:&quot;Aberdeen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABNS&quot;,&quot;state&quot;:&quot;Aberdeenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANG&quot;,&quot;state&quot;:&quot;Anglesey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AGS&quot;,&quot;state&quot;:&quot;Angus&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARY&quot;,&quot;state&quot;:&quot;Argyll and Bute&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AVN&quot;,&quot;state&quot;:&quot;Avon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BAN&quot;,&quot;state&quot;:&quot;Banffshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEDS&quot;,&quot;state&quot;:&quot;Bedfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BERKS&quot;,&quot;state&quot;:&quot;Berkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEW&quot;,&quot;state&quot;:&quot;Berwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BLA&quot;,&quot;state&quot;:&quot;Blaenau Gwent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BRI&quot;,&quot;state&quot;:&quot;Bridgend&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BSTL&quot;,&quot;state&quot;:&quot;Bristol&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BUCKS&quot;,&quot;state&quot;:&quot;Buckinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAE&quot;,&quot;state&quot;:&quot;Caerphilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAI&quot;,&quot;state&quot;:&quot;Caithness&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAMBS&quot;,&quot;state&quot;:&quot;Cambridgeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDF&quot;,&quot;state&quot;:&quot;Cardiff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CARM&quot;,&quot;state&quot;:&quot;Carmarthenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDGN&quot;,&quot;state&quot;:&quot;Ceredigion&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CHES&quot;,&quot;state&quot;:&quot;Cheshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLACK&quot;,&quot;state&quot;:&quot;Clackmannanshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLV&quot;,&quot;state&quot;:&quot;Cleveland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CWD&quot;,&quot;state&quot;:&quot;Clwyd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CON&quot;,&quot;state&quot;:&quot;Conwy&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CORN&quot;,&quot;state&quot;:&quot;Cornwall&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANT&quot;,&quot;state&quot;:&quot;County Antrim&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARM&quot;,&quot;state&quot;:&quot;County Armagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOW&quot;,&quot;state&quot;:&quot;County Down&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FER&quot;,&quot;state&quot;:&quot;County Fermanagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDY&quot;,&quot;state&quot;:&quot;County Londonderry&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TYR&quot;,&quot;state&quot;:&quot;County Tyrone&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CMA&quot;,&quot;state&quot;:&quot;Cumbria&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DNBG&quot;,&quot;state&quot;:&quot;Denbighshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DERBY&quot;,&quot;state&quot;:&quot;Derbyshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DVN&quot;,&quot;state&quot;:&quot;Devon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOR&quot;,&quot;state&quot;:&quot;Dorset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DGL&quot;,&quot;state&quot;:&quot;Dumfries and Galloway&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFS&quot;,&quot;state&quot;:&quot;Dumfries-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUND&quot;,&quot;state&quot;:&quot;Dundee&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DHM&quot;,&quot;state&quot;:&quot;Durham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFD&quot;,&quot;state&quot;:&quot;Dyfed&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYE&quot;,&quot;state&quot;:&quot;East Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUNBE&quot;,&quot;state&quot;:&quot;East Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LOTE&quot;,&quot;state&quot;:&quot;East Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RENE&quot;,&quot;state&quot;:&quot;East Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ERYS&quot;,&quot;state&quot;:&quot;East Riding of Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXE&quot;,&quot;state&quot;:&quot;East Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;EDIN&quot;,&quot;state&quot;:&quot;Edinburgh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ESX&quot;,&quot;state&quot;:&quot;Essex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FALK&quot;,&quot;state&quot;:&quot;Falkirk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FFE&quot;,&quot;state&quot;:&quot;Fife&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FLINT&quot;,&quot;state&quot;:&quot;Flintshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLAS&quot;,&quot;state&quot;:&quot;Glasgow&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLOS&quot;,&quot;state&quot;:&quot;Gloucestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDN&quot;,&quot;state&quot;:&quot;Greater London&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MCH&quot;,&quot;state&quot;:&quot;Greater Manchester&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GDD&quot;,&quot;state&quot;:&quot;Gwynedd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HANTS&quot;,&quot;state&quot;:&quot;Hampshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HWR&quot;,&quot;state&quot;:&quot;Herefordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HERTS&quot;,&quot;state&quot;:&quot;Hertfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HLD&quot;,&quot;state&quot;:&quot;Highlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HUM&quot;,&quot;state&quot;:&quot;Humberside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IVER&quot;,&quot;state&quot;:&quot;Inverclyde&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;INV&quot;,&quot;state&quot;:&quot;Inverness-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOW&quot;,&quot;state&quot;:&quot;Isle of Wight&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOS&quot;,&quot;state&quot;:&quot;Isles of Scilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KNT&quot;,&quot;state&quot;:&quot;Kent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KCD&quot;,&quot;state&quot;:&quot;Kincardineshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANCS&quot;,&quot;state&quot;:&quot;Lancashire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LEICS&quot;,&quot;state&quot;:&quot;Leicestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LINCS&quot;,&quot;state&quot;:&quot;Lincolnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MER&quot;,&quot;state&quot;:&quot;Merionethshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MSY&quot;,&quot;state&quot;:&quot;Merseyside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MERT&quot;,&quot;state&quot;:&quot;Merthyr Tydfil&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MDX&quot;,&quot;state&quot;:&quot;Middlesex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MLOT&quot;,&quot;state&quot;:&quot;Midlothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MMOUTH&quot;,&quot;state&quot;:&quot;Monmouthshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MORAY&quot;,&quot;state&quot;:&quot;Moray&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NAI&quot;,&quot;state&quot;:&quot;Nairnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NPRTAL&quot;,&quot;state&quot;:&quot;Neath Port Talbot&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NEWPT&quot;,&quot;state&quot;:&quot;Newport&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOR&quot;,&quot;state&quot;:&quot;Norfolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYN&quot;,&quot;state&quot;:&quot;North Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANN&quot;,&quot;state&quot;:&quot;North Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSN&quot;,&quot;state&quot;:&quot;North Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NHM&quot;,&quot;state&quot;:&quot;Northamptonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NLD&quot;,&quot;state&quot;:&quot;Northumberland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOT&quot;,&quot;state&quot;:&quot;Nottinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ORK&quot;,&quot;state&quot;:&quot;Orkney Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;OFE&quot;,&quot;state&quot;:&quot;Oxfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEE&quot;,&quot;state&quot;:&quot;Peebles-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEM&quot;,&quot;state&quot;:&quot;Pembrokeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PERTH&quot;,&quot;state&quot;:&quot;Perth and Kinross&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PWS&quot;,&quot;state&quot;:&quot;Powys&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;REN&quot;,&quot;state&quot;:&quot;Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RHON&quot;,&quot;state&quot;:&quot;Rhondda Cynon Taff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ROX&quot;,&quot;state&quot;:&quot;Roxburghshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RUT&quot;,&quot;state&quot;:&quot;Rutland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BOR&quot;,&quot;state&quot;:&quot;Scottish Borders&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SEL&quot;,&quot;state&quot;:&quot;Selkirkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SHET&quot;,&quot;state&quot;:&quot;Shetland Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Shropshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SOM&quot;,&quot;state&quot;:&quot;Somerset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYS&quot;,&quot;state&quot;:&quot;South Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANS&quot;,&quot;state&quot;:&quot;South Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SYK&quot;,&quot;state&quot;:&quot;South Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFD&quot;,&quot;state&quot;:&quot;Staffordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STIR&quot;,&quot;state&quot;:&quot;Stirling&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STI&quot;,&quot;state&quot;:&quot;Stirlingshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFK&quot;,&quot;state&quot;:&quot;Suffolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SRY&quot;,&quot;state&quot;:&quot;Surrey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SUT&quot;,&quot;state&quot;:&quot;Sutherland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SWAN&quot;,&quot;state&quot;:&quot;Swansea&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TORF&quot;,&quot;state&quot;:&quot;Torfaen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TWR&quot;,&quot;state&quot;:&quot;Tyne and Wear&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;VGLAM&quot;,&quot;state&quot;:&quot;Vale of Glamorgan&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WARKS&quot;,&quot;state&quot;:&quot;Warwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WDUN&quot;,&quot;state&quot;:&quot;West Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLOT&quot;,&quot;state&quot;:&quot;West Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WMD&quot;,&quot;state&quot;:&quot;West Midlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXW&quot;,&quot;state&quot;:&quot;West Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSW&quot;,&quot;state&quot;:&quot;West Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIL&quot;,&quot;state&quot;:&quot;Western Isles&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIG&quot;,&quot;state&quot;:&quot;Wigtownshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLT&quot;,&quot;state&quot;:&quot;Wiltshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WORCS&quot;,&quot;state&quot;:&quot;Worcestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WRX&quot;,&quot;state&quot;:&quot;Wrexham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YKS&quot;,&quot;state&quot;:&quot;Yorkshire&quot;}],&quot;IT&quot;:[{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Agrigento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alessandria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AN&quot;,&quot;state&quot;:&quot;Ancona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AO&quot;,&quot;state&quot;:&quot;Aosta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arezzo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AP&quot;,&quot;state&quot;:&quot;Ascoli Piceno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AT&quot;,&quot;state&quot;:&quot;Asti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;Avellino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Bari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;Belluno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;Benevento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BG&quot;,&quot;state&quot;:&quot;Bergamo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Biella&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BO&quot;,&quot;state&quot;:&quot;Bologna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;Bolzano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;Brescia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;Brindisi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;Cagliari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;Caltanissetta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CB&quot;,&quot;state&quot;:&quot;Campobasso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CI&quot;,&quot;state&quot;:&quot;Carbonia-Iglesias&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Caserta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Catania&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CZ&quot;,&quot;state&quot;:&quot;Catanzaro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CH&quot;,&quot;state&quot;:&quot;Chieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Como&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Cosenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Cremona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Crotone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CN&quot;,&quot;state&quot;:&quot;Cuneo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;EN&quot;,&quot;state&quot;:&quot;Enna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FE&quot;,&quot;state&quot;:&quot;Ferrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FI&quot;,&quot;state&quot;:&quot;Firenze&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FG&quot;,&quot;state&quot;:&quot;Foggia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FC&quot;,&quot;state&quot;:&quot;Forli-Cesena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Frosinone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Genova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GO&quot;,&quot;state&quot;:&quot;Gorizia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grosseto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IM&quot;,&quot;state&quot;:&quot;Imperia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;Isernia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AQ&quot;,&quot;state&quot;:&quot;L'Aquila&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SP&quot;,&quot;state&quot;:&quot;La Spezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LT&quot;,&quot;state&quot;:&quot;Latina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Lecce&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LC&quot;,&quot;state&quot;:&quot;Lecco&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Livorno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;Lodi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucca&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MC&quot;,&quot;state&quot;:&quot;Macerata&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Mantova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Massa-Carrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Matera&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Medio Campidano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Messina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Milano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Modena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Napoli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NO&quot;,&quot;state&quot;:&quot;Novara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nuoro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OG&quot;,&quot;state&quot;:&quot;Ogliastra&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;Olbia-Tempio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oristano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PD&quot;,&quot;state&quot;:&quot;Padova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Palermo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Parma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PV&quot;,&quot;state&quot;:&quot;Pavia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PG&quot;,&quot;state&quot;:&quot;Perugia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PU&quot;,&quot;state&quot;:&quot;Pesaro e Urbino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Pescara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PC&quot;,&quot;state&quot;:&quot;Piacenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PI&quot;,&quot;state&quot;:&quot;Pisa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PT&quot;,&quot;state&quot;:&quot;Pistoia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PN&quot;,&quot;state&quot;:&quot;Pordenone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PZ&quot;,&quot;state&quot;:&quot;Potenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Prato&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RG&quot;,&quot;state&quot;:&quot;Ragusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RA&quot;,&quot;state&quot;:&quot;Ravenna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RC&quot;,&quot;state&quot;:&quot;Reggio Calabria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RE&quot;,&quot;state&quot;:&quot;Reggio Emilia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RN&quot;,&quot;state&quot;:&quot;Rimini&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RM&quot;,&quot;state&quot;:&quot;Roma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RO&quot;,&quot;state&quot;:&quot;Rovigo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salerno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Sassari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;Savona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SI&quot;,&quot;state&quot;:&quot;Siena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SR&quot;,&quot;state&quot;:&quot;Siracusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Sondrio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Taranto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teramo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;Terni&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Torino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TP&quot;,&quot;state&quot;:&quot;Trapani&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Trento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TV&quot;,&quot;state&quot;:&quot;Treviso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TS&quot;,&quot;state&quot;:&quot;Trieste&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udine&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Varese&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VE&quot;,&quot;state&quot;:&quot;Venezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VB&quot;,&quot;state&quot;:&quot;Verbano-Cusio-Ossola&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VC&quot;,&quot;state&quot;:&quot;Vercelli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VR&quot;,&quot;state&quot;:&quot;Verona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VV&quot;,&quot;state&quot;:&quot;Vibo Valentia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Vicenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Viterbo&quot;}],&quot;JP&quot;:[{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AICHI&quot;,&quot;state&quot;:&quot;AICHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AKITA&quot;,&quot;state&quot;:&quot;AKITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AOMORI&quot;,&quot;state&quot;:&quot;AOMORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;CHIBA&quot;,&quot;state&quot;:&quot;CHIBA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;EHIME&quot;,&quot;state&quot;:&quot;EHIME&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUI&quot;,&quot;state&quot;:&quot;FUKUI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUOKA&quot;,&quot;state&quot;:&quot;FUKUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUSHIMA&quot;,&quot;state&quot;:&quot;FUKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GIFU&quot;,&quot;state&quot;:&quot;GIFU&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GUMMA&quot;,&quot;state&quot;:&quot;GUMMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HIROSHIMA&quot;,&quot;state&quot;:&quot;HIROSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HOKKAIDO&quot;,&quot;state&quot;:&quot;HOKKAIDO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HYOGO&quot;,&quot;state&quot;:&quot;HYOGO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IBARAKI&quot;,&quot;state&quot;:&quot;IBARAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;ISHIKAWA&quot;,&quot;state&quot;:&quot;ISHIKAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IWATE&quot;,&quot;state&quot;:&quot;IWATE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGAWA&quot;,&quot;state&quot;:&quot;KAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGOSHIMA&quot;,&quot;state&quot;:&quot;KAGOSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KANAGAWA&quot;,&quot;state&quot;:&quot;KANAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KOCHI&quot;,&quot;state&quot;:&quot;KOCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KUMAMOTO&quot;,&quot;state&quot;:&quot;KUMAMOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KYOTO&quot;,&quot;state&quot;:&quot;KYOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIE&quot;,&quot;state&quot;:&quot;MIE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAGI&quot;,&quot;state&quot;:&quot;MIYAGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAZAKI&quot;,&quot;state&quot;:&quot;MIYAZAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGANO&quot;,&quot;state&quot;:&quot;NAGANO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGASAKI&quot;,&quot;state&quot;:&quot;NAGASAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NARA&quot;,&quot;state&quot;:&quot;NARA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NIIGATA&quot;,&quot;state&quot;:&quot;NIIGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OITA&quot;,&quot;state&quot;:&quot;OITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKAYAMA&quot;,&quot;state&quot;:&quot;OKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKINAWA&quot;,&quot;state&quot;:&quot;OKINAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OSAKA&quot;,&quot;state&quot;:&quot;OSAKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAGA&quot;,&quot;state&quot;:&quot;SAGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAITAMA&quot;,&quot;state&quot;:&quot;SAITAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIGA&quot;,&quot;state&quot;:&quot;SHIGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIMANE&quot;,&quot;state&quot;:&quot;SHIMANE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIZUOKA&quot;,&quot;state&quot;:&quot;SHIZUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOCHIGI&quot;,&quot;state&quot;:&quot;TOCHIGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKUSHIMA&quot;,&quot;state&quot;:&quot;TOKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKYO&quot;,&quot;state&quot;:&quot;TOKYO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOTTORI&quot;,&quot;state&quot;:&quot;TOTTORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOYAMA&quot;,&quot;state&quot;:&quot;TOYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;WAKAYAMA&quot;,&quot;state&quot;:&quot;WAKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGATA&quot;,&quot;state&quot;:&quot;YAMAGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGUCHI&quot;,&quot;state&quot;:&quot;YAMAGUCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMANASHI&quot;,&quot;state&quot;:&quot;YAMANASHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4e09\u91cd\u770c&quot;,&quot;state&quot;:&quot;\u4e09\u91cd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4eac\u90fd\u5e9c&quot;,&quot;state&quot;:&quot;\u4eac\u90fd\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4f50\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u4f50\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5175\u5eab\u770c&quot;,&quot;state&quot;:&quot;\u5175\u5eab\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5317\u6d77\u9053&quot;,&quot;state&quot;:&quot;\u5317\u6d77\u9053&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5343\u8449\u770c&quot;,&quot;state&quot;:&quot;\u5343\u8449\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u57fc\u7389\u770c&quot;,&quot;state&quot;:&quot;\u57fc\u7389\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u5206\u770c&quot;,&quot;state&quot;:&quot;\u5927\u5206\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u962a\u5e9c&quot;,&quot;state&quot;:&quot;\u5927\u962a\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5948\u826f\u770c&quot;,&quot;state&quot;:&quot;\u5948\u826f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bcc\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5bcc\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u53e3\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u53e3\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u5f62\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u5f62\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u68a8\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u68a8\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c90\u961c\u770c&quot;,&quot;state&quot;:&quot;\u5c90\u961c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca1\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5ca1\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca9\u624b\u770c&quot;,&quot;state&quot;:&quot;\u5ca9\u624b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5cf6\u6839\u770c&quot;,&quot;state&quot;:&quot;\u5cf6\u6839\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5e83\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5e83\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5fb3\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5fb3\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u5a9b\u770c&quot;,&quot;state&quot;:&quot;\u611b\u5a9b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u611b\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u65b0\u6f5f\u770c&quot;,&quot;state&quot;:&quot;\u65b0\u6f5f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6771\u4eac\u90fd&quot;,&quot;state&quot;:&quot;\u6771\u4eac\u90fd&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6803\u6728\u770c&quot;,&quot;state&quot;:&quot;\u6803\u6728\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6c96\u7e04\u770c&quot;,&quot;state&quot;:&quot;\u6c96\u7e04\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6ecb\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u6ecb\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u718a\u672c\u770c&quot;,&quot;state&quot;:&quot;\u718a\u672c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u77f3\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u77f3\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u4e95\u770c&quot;,&quot;state&quot;:&quot;\u798f\u4e95\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u79cb\u7530\u770c&quot;,&quot;state&quot;:&quot;\u79cb\u7530\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u7fa4\u99ac\u770c&quot;,&quot;state&quot;:&quot;\u7fa4\u99ac\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u8328\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u8328\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u9577\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u91ce\u770c&quot;,&quot;state&quot;:&quot;\u9577\u91ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9752\u68ee\u770c&quot;,&quot;state&quot;:&quot;\u9752\u68ee\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9759\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u9759\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9999\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u9999\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ad8\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u9ad8\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ce5\u53d6\u770c&quot;,&quot;state&quot;:&quot;\u9ce5\u53d6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;}],&quot;NL&quot;:[{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;DR&quot;,&quot;state&quot;:&quot;Drenthe&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Flevoland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Friesland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gelderland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Groningen&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Limburg&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;Noord Brabant&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;Noord Holland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;OV&quot;,&quot;state&quot;:&quot;Overijssel&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utrecht&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZE&quot;,&quot;state&quot;:&quot;Zeeland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zuid Holland&quot;}],&quot;RO&quot;:[{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;ALBA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;ARAD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;ARGES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;BACAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BH&quot;,&quot;state&quot;:&quot;BIHOR&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;BISTRITA-NASAUD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BT&quot;,&quot;state&quot;:&quot;BOTOSANI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;BRAILA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BV&quot;,&quot;state&quot;:&quot;BRASOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;BUCURESTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;BUZAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;CALARASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;CARAS-SEVERIN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CJ&quot;,&quot;state&quot;:&quot;CLUJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CV&quot;,&quot;state&quot;:&quot;COVASNA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DB&quot;,&quot;state&quot;:&quot;DAMBOVITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DJ&quot;,&quot;state&quot;:&quot;DOLJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;GALATI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;GIURGIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GJ&quot;,&quot;state&quot;:&quot;GORJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HR&quot;,&quot;state&quot;:&quot;HARGHITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HD&quot;,&quot;state&quot;:&quot;HUNEDOARA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;IALOMITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;IASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IF&quot;,&quot;state&quot;:&quot;ILFOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MM&quot;,&quot;state&quot;:&quot;MARAMURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MH&quot;,&quot;state&quot;:&quot;MEHEDINTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;MURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;NEAMT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;OLT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;PH&quot;,&quot;state&quot;:&quot;PRAHOVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SJ&quot;,&quot;state&quot;:&quot;SALAJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SM&quot;,&quot;state&quot;:&quot;SATU MARE&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SB&quot;,&quot;state&quot;:&quot;SIBIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;SUCEAVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;TELEORMAN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TM&quot;,&quot;state&quot;:&quot;TIMIS&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TL&quot;,&quot;state&quot;:&quot;TULCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VL&quot;,&quot;state&quot;:&quot;VALCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;VASLUI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VN&quot;,&quot;state&quot;:&quot;VRANCEA&quot;}],&quot;RU&quot;:[{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ALT&quot;,&quot;state&quot;:&quot;Altajskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AMU&quot;,&quot;state&quot;:&quot;Amurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ARK&quot;,&quot;state&quot;:&quot;Arhangel'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AST&quot;,&quot;state&quot;:&quot;Astrahanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BEL&quot;,&quot;state&quot;:&quot;Belgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BRY&quot;,&quot;state&quot;:&quot;Brjanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Chechenskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHE&quot;,&quot;state&quot;:&quot;Cheljabinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHU&quot;,&quot;state&quot;:&quot;Chukotskij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Chuvashskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YEV&quot;,&quot;state&quot;:&quot;Evrejskaja avtonomnaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHA&quot;,&quot;state&quot;:&quot;Habarovskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHM&quot;,&quot;state&quot;:&quot;Hanty-Mansijskij avtonomnyj okrug - Jugra&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IRK&quot;,&quot;state&quot;:&quot;Irkutskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IVA&quot;,&quot;state&quot;:&quot;Ivanovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAN&quot;,&quot;state&quot;:&quot;Jamalo-Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAR&quot;,&quot;state&quot;:&quot;Jaroslavskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KB&quot;,&quot;state&quot;:&quot;Kabardino-Balkarskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGD&quot;,&quot;state&quot;:&quot;Kaliningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KLU&quot;,&quot;state&quot;:&quot;Kaluzhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KAM&quot;,&quot;state&quot;:&quot;Kamchatskiy kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KC&quot;,&quot;state&quot;:&quot;Karachaevo-Cherkesskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KEM&quot;,&quot;state&quot;:&quot;Kemerovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIR&quot;,&quot;state&quot;:&quot;Kirovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KOS&quot;,&quot;state&quot;:&quot;Kostromskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KDA&quot;,&quot;state&quot;:&quot;Krasnodarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIA&quot;,&quot;state&quot;:&quot;Krasnojarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGN&quot;,&quot;state&quot;:&quot;Kurganskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KRS&quot;,&quot;state&quot;:&quot;Kurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LEN&quot;,&quot;state&quot;:&quot;Leningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LIP&quot;,&quot;state&quot;:&quot;Lipeckaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MAG&quot;,&quot;state&quot;:&quot;Magadanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOS&quot;,&quot;state&quot;:&quot;Moskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOW&quot;,&quot;state&quot;:&quot;Moskva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MUR&quot;,&quot;state&quot;:&quot;Murmanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NEN&quot;,&quot;state&quot;:&quot;Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NIZ&quot;,&quot;state&quot;:&quot;Nizhegorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NGR&quot;,&quot;state&quot;:&quot;Novgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NVS&quot;,&quot;state&quot;:&quot;Novosibirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;OMS&quot;,&quot;state&quot;:&quot;Omskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORE&quot;,&quot;state&quot;:&quot;Orenburgskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORL&quot;,&quot;state&quot;:&quot;Orlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PNZ&quot;,&quot;state&quot;:&quot;Penzenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PER&quot;,&quot;state&quot;:&quot;Permskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PRI&quot;,&quot;state&quot;:&quot;Primorskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PSK&quot;,&quot;state&quot;:&quot;Pskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AD&quot;,&quot;state&quot;:&quot;Respublika Adygeja&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Respublika Altaj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Respublika Bashkortostan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Respublika Burjatija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;DA&quot;,&quot;state&quot;:&quot;Respublika Dagestan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KK&quot;,&quot;state&quot;:&quot;Respublika Hakasija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Respublika Ingushetija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KL&quot;,&quot;state&quot;:&quot;Respublika Kalmykija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Respublika Karelija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KO&quot;,&quot;state&quot;:&quot;Respublika Komi&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Respublika Marij Jel&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Respublika Mordovija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Respublika Saha (Jakutija)&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Respublika Severnaja Osetija-Alanija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Respublika Tatarstan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TY&quot;,&quot;state&quot;:&quot;Respublika Tyva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;RYA&quot;,&quot;state&quot;:&quot;Rjazanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ROS&quot;,&quot;state&quot;:&quot;Rostovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAK&quot;,&quot;state&quot;:&quot;Sahalinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAM&quot;,&quot;state&quot;:&quot;Samarskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Sankt-Peterburg&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saratovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SMO&quot;,&quot;state&quot;:&quot;Smolenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;STA&quot;,&quot;state&quot;:&quot;Stavropol'skij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SVE&quot;,&quot;state&quot;:&quot;Sverdlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TAM&quot;,&quot;state&quot;:&quot;Tambovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TYU&quot;,&quot;state&quot;:&quot;Tjumenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TOM&quot;,&quot;state&quot;:&quot;Tomskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TUL&quot;,&quot;state&quot;:&quot;Tul'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TVE&quot;,&quot;state&quot;:&quot;Tverskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udmurtskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ULY&quot;,&quot;state&quot;:&quot;Ul'janovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLA&quot;,&quot;state&quot;:&quot;Vladimirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VGG&quot;,&quot;state&quot;:&quot;Volgogradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLG&quot;,&quot;state&quot;:&quot;Vologodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VOR&quot;,&quot;state&quot;:&quot;Voronezhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ZAB&quot;,&quot;state&quot;:&quot;Zabaykal'skiy kraj&quot;}],&quot;US&quot;:[{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alabama&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AK&quot;,&quot;state&quot;:&quot;Alaska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AZ&quot;,&quot;state&quot;:&quot;Arizona&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arkansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;California&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Colorado&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Connecticut&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DE&quot;,&quot;state&quot;:&quot;Delaware&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DC&quot;,&quot;state&quot;:&quot;District of Columbia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Florida&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GA&quot;,&quot;state&quot;:&quot;Georgia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guam&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;HI&quot;,&quot;state&quot;:&quot;Hawaii&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ID&quot;,&quot;state&quot;:&quot;Idaho&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;Illinois&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Indiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IA&quot;,&quot;state&quot;:&quot;Iowa&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KS&quot;,&quot;state&quot;:&quot;Kansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KY&quot;,&quot;state&quot;:&quot;Kentucky&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;LA&quot;,&quot;state&quot;:&quot;Louisiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Maine&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MD&quot;,&quot;state&quot;:&quot;Maryland&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;Massachusetts&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Michigan&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Minnesota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Mississippi&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Missouri&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Montana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Nebraska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NV&quot;,&quot;state&quot;:&quot;Nevada&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;New Hampshire&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NJ&quot;,&quot;state&quot;:&quot;New Jersey&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NM&quot;,&quot;state&quot;:&quot;New Mexico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NY&quot;,&quot;state&quot;:&quot;New York&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NC&quot;,&quot;state&quot;:&quot;North Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ND&quot;,&quot;state&quot;:&quot;North Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MP&quot;,&quot;state&quot;:&quot;Northern Mariana Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OH&quot;,&quot;state&quot;:&quot;Ohio&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OK&quot;,&quot;state&quot;:&quot;Oklahoma&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oregon&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Pennsylvania&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Puerto Rico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rhode Island&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SC&quot;,&quot;state&quot;:&quot;South Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SD&quot;,&quot;state&quot;:&quot;South Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Tennessee&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TX&quot;,&quot;state&quot;:&quot;Texas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utah&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Vermont&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Virgin Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Washington&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WV&quot;,&quot;state&quot;:&quot;West Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WI&quot;,&quot;state&quot;:&quot;Wisconsin&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WY&quot;,&quot;state&quot;:&quot;Wyoming&quot;}]},

// [filosof]
        countries_with_codes: {&quot;RO&quot;:&quot;RO&quot;}
// [/filosof]
    });

    
    $.ceFormValidator('setZipcode', {
        US: {
            regexp: /^(\d{5})(-\d{4})?$/,
            format: '01342 (01342-5678)'
        },
        CA: {
            regexp: /^(\w{3} ?\w{3})$/,
            format: 'V1A OB1 (V1AOB1)'
        },
        RU: {
            regexp: /^(\d{6})?$/,
            format: '123456'
        }
    });
    

}(Tygh, Tygh.$));
//]]>

    




    
                
                
                


 
     Select



    

               
            ,  
        {user_name}({email})
        

       
    
    
    

                        
                    
                
            
                
            Purchase Date
            
                    
    
    

    
    
    



    

    .ui-timepicker-div .ui-widget-header { margin-bottom: 8px; }
    .ui-timepicker-div dl { text-align: left; }
    .ui-timepicker-div dl dt { float: left; clear:left; padding: 0 0 0 5px; }
    .ui-timepicker-div dl dd { margin: 0 10px 10px 40%; }
    .ui-timepicker-div td { font-size: 90%; }
    .ui-tpicker-grid-label { background: none; border: none; margin: 0; padding: 0; }
    .ui-timepicker-div .ui_tpicker_unit_hide{ display: none; }

    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input { background: none; color: inherit; border: none; outline: none; border-bottom: solid 1px #555; width: 95%; }
    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input:focus { border-bottom-color: #aaa; }

    .ui-timepicker-rtl{ direction: rtl; }
    .ui-timepicker-rtl dl { text-align: right; padding: 0 5px 0 0; }
    .ui-timepicker-rtl dl dt{ float: right; clear: right; }
    .ui-timepicker-rtl dl dd { margin: 0 40% 10px 10px; }

    /* Shortened version style */
    .ui-timepicker-div.ui-timepicker-oneLine { padding-right: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time,
    .ui-timepicker-div.ui-timepicker-oneLine dt { display: none; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time_label { display: block; padding-top: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine dl { text-align: right; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd > div { display:inline-block; margin:0; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_minute:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_second:before { content:':'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_millisec:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_microsec:before { content:'.'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide,
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide:before{ display: none; }




//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
        // Keep variable name 'calendar_config' and its scope (global) for correct cloning with settings
        // (see js/tygh/node_cloning.js)
        calendar_config = {
            changeMonth: true,
            duration: 'fast',
            changeYear: true,
            numberOfMonths: 1,
            selectOtherMonths: true,
            showOtherMonths: true,
                        maxDate:'+0D',            firstDay: 1,
            dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            yearRange: '2015:2023',
            dateFormat: 'dd/mm/yy'
        };
        if ($('#select_device_register_purchase_date_0').hasClass('cm-datetimepicker')) {
            $('#select_device_register_purchase_date_0').datetimepicker(
                calendar_config
            ).attr('readonly', 'readonly');
        } else {
            $('#select_device_register_purchase_date_0').datepicker(
                calendar_config
            ).attr('readonly', 'readonly');
        }
    });
}(Tygh, Tygh.$));
//]]>


            
        

            

    
        Promotion
        
            
                
                    Promotional Code
                
                
                    

                    
                    Valid code and display bonuses

                    
                    
                    
                
            
            or
            
                Select Promotion Name
                
                        


 
     Select Promotion



                
            

            
	            
	                
	                    Campaign Name
	                
	                
				
				 
				
					
	                    Code status
	                
					
				
                
                    Bonuses
                
                
            

            Validate Promotion
        
    
    
	    
	        Payment Informations
	        
	            
	                Sale price (Discount included)
	            
	            
			
			
            	
	                Product bonuses
	            
	            
	        
	    
	



    
            


 
    



        Reset
    


            
            
                
                    Where to find the code?
                    
                
            
        
        
            or
                


 
     Search devices
    


        
    

        
        
        
            Return Device
        
                

    
    


    
        	                        
                        Return Kit
        
                            
                        Return Component
        
                            
                        Trade-In
        
                            
                        Return Accessories
        
                More


                
                
                                                



    Find issued device
                            
            There is no linked device
            
                
                    Search devices
                                        
                        
                            
    
        Enter Device ID (Codentify)
        
            









    //&lt;![CDATA[
    (function(_, $) {
        $('.device-code-search_0').groupinputs();
    }(Tygh, Tygh.$));
    //]]>

        
    
            
            Retailer
            
                                
                    
                    
                        
                    
                    
                        






    
//&lt;![CDATA[
(function(_, $) {

    /* Do not put this code to document.ready, because it should be
       initialized first
    */
    $.ceRebuildStates('init', {
        default_country: 'RO',
        states: {&quot;&quot;:[{&quot;country_code&quot;:&quot;&quot;,&quot;code&quot;:&quot;CONSTANTA&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;}],&quot;AU&quot;:[{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;ACT&quot;,&quot;state&quot;:&quot;Australian Capital Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NSW&quot;,&quot;state&quot;:&quot;New South Wales&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northern Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;QLD&quot;,&quot;state&quot;:&quot;Queensland&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;South Australia&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;TAS&quot;,&quot;state&quot;:&quot;Tasmania&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;VIC&quot;,&quot;state&quot;:&quot;Victoria&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Western Australia&quot;}],&quot;BG&quot;:[{&quot;country_code&quot;:&quot;BG&quot;,&quot;code&quot;:&quot;SF&quot;,&quot;state&quot;:&quot;Sofia&quot;}],&quot;CA&quot;:[{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Alberta&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;British Columbia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;MB&quot;,&quot;state&quot;:&quot;Manitoba&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;New Brunswick&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NL&quot;,&quot;state&quot;:&quot;Newfoundland and Labrador&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northwest Territories&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NS&quot;,&quot;state&quot;:&quot;Nova Scotia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nunavut&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;ON&quot;,&quot;state&quot;:&quot;Ontario&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Prince Edward Island&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;QC&quot;,&quot;state&quot;:&quot;Quebec&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;SK&quot;,&quot;state&quot;:&quot;Saskatchewan&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;YT&quot;,&quot;state&quot;:&quot;Yukon&quot;}],&quot;CH&quot;:[{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Ext\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AI&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Int\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Argovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;B\u00e2le-Campagne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;B\u00e2le-Ville&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BE&quot;,&quot;state&quot;:&quot;Berne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Fribourg&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gen\u00e8ve&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;Glaris&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grisons&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;JU&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucerne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Neuch\u00e2tel&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NW&quot;,&quot;state&quot;:&quot;Nidwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;OW&quot;,&quot;state&quot;:&quot;Obwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Saint-Gall&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SH&quot;,&quot;state&quot;:&quot;Schaffhouse&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SZ&quot;,&quot;state&quot;:&quot;Schwytz&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soleure&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TI&quot;,&quot;state&quot;:&quot;Tessin&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TG&quot;,&quot;state&quot;:&quot;Thurgovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;UR&quot;,&quot;state&quot;:&quot;Uri&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Valais&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VD&quot;,&quot;state&quot;:&quot;Vaud&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZG&quot;,&quot;state&quot;:&quot;Zoug&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zurich&quot;}],&quot;DE&quot;:[{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAW&quot;,&quot;state&quot;:&quot;Baden-W\u00fcrttemberg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAY&quot;,&quot;state&quot;:&quot;Bayern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BER&quot;,&quot;state&quot;:&quot;Berlin&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRG&quot;,&quot;state&quot;:&quot;Branderburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRE&quot;,&quot;state&quot;:&quot;Bremen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HAM&quot;,&quot;state&quot;:&quot;Hamburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HES&quot;,&quot;state&quot;:&quot;Hessen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;MEC&quot;,&quot;state&quot;:&quot;Mecklenburg-Vorpommern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NDS&quot;,&quot;state&quot;:&quot;Niedersachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NRW&quot;,&quot;state&quot;:&quot;Nordrhein-Westfalen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;RHE&quot;,&quot;state&quot;:&quot;Rheinland-Pfalz&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saarland&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAS&quot;,&quot;state&quot;:&quot;Sachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAC&quot;,&quot;state&quot;:&quot;Sachsen-Anhalt&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SCN&quot;,&quot;state&quot;:&quot;Schleswig-Holstein&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;THE&quot;,&quot;state&quot;:&quot;Th\u00fcringen&quot;}],&quot;ES&quot;:[{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;C&quot;,&quot;state&quot;:&quot;A Coru\u00f1a&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;\u00c1lava&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Albacete&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;A&quot;,&quot;state&quot;:&quot;Alicante&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Almer\u00eda&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;O&quot;,&quot;state&quot;:&quot;Asturias&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;\u00c1vila&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Badajoz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PM&quot;,&quot;state&quot;:&quot;Baleares&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;Barcelona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Burgos&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CC&quot;,&quot;state&quot;:&quot;C\u00e1ceres&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;C\u00e1diz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;S&quot;,&quot;state&quot;:&quot;Cantabria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Castell\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Ceuta&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Ciudad Real&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;C\u00f3rdoba&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Cuenca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GI&quot;,&quot;state&quot;:&quot;Girona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Granada&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guadalajara&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Guip\u00fazcoa&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;H&quot;,&quot;state&quot;:&quot;Huelva&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;HU&quot;,&quot;state&quot;:&quot;Huesca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;J&quot;,&quot;state&quot;:&quot;Ja\u00e9n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;La Rioja&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GC&quot;,&quot;state&quot;:&quot;Las Palmas&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Le\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;L&quot;,&quot;state&quot;:&quot;Lleida&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lugo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;M&quot;,&quot;state&quot;:&quot;Madrid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;M\u00e1laga&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ML&quot;,&quot;state&quot;:&quot;Melilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MU&quot;,&quot;state&quot;:&quot;Murcia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Navarra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Ourense&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;P&quot;,&quot;state&quot;:&quot;Palencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Pontevedra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salamanca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TF&quot;,&quot;state&quot;:&quot;Santa Cruz de Tenerife&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Segovia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Sevilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;T&quot;,&quot;state&quot;:&quot;Tarragona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teruel&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Toledo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;V&quot;,&quot;state&quot;:&quot;Valencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Valladolid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Vizcaya&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ZA&quot;,&quot;state&quot;:&quot;Zamora&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;Z&quot;,&quot;state&quot;:&quot;Zaragoza&quot;}],&quot;FR&quot;:[{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;01&quot;,&quot;state&quot;:&quot;Ain&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;02&quot;,&quot;state&quot;:&quot;Aisne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;03&quot;,&quot;state&quot;:&quot;Allier&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;04&quot;,&quot;state&quot;:&quot;Alpes-de-Haute-Provence&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;06&quot;,&quot;state&quot;:&quot;Alpes-Maritimes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;07&quot;,&quot;state&quot;:&quot;Ard\u00e8che&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;08&quot;,&quot;state&quot;:&quot;Ardennes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;09&quot;,&quot;state&quot;:&quot;Ari\u00e8ge&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;10&quot;,&quot;state&quot;:&quot;Aube&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;11&quot;,&quot;state&quot;:&quot;Aude&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;12&quot;,&quot;state&quot;:&quot;Aveyron&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;67&quot;,&quot;state&quot;:&quot;Bas-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;13&quot;,&quot;state&quot;:&quot;Bouches-du-Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;14&quot;,&quot;state&quot;:&quot;Calvados&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;15&quot;,&quot;state&quot;:&quot;Cantal&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;16&quot;,&quot;state&quot;:&quot;Charente&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;17&quot;,&quot;state&quot;:&quot;Charente-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;18&quot;,&quot;state&quot;:&quot;Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;19&quot;,&quot;state&quot;:&quot;Corr\u00e8ze&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2A&quot;,&quot;state&quot;:&quot;Corse-du-Sud&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;21&quot;,&quot;state&quot;:&quot;C\u00f4te-d'Or&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;22&quot;,&quot;state&quot;:&quot;C\u00f4tes-d'Armor&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;23&quot;,&quot;state&quot;:&quot;Creuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;79&quot;,&quot;state&quot;:&quot;Deux-S\u00e8vres&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;24&quot;,&quot;state&quot;:&quot;Dordogne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;25&quot;,&quot;state&quot;:&quot;Doubs&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;26&quot;,&quot;state&quot;:&quot;Dr\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;91&quot;,&quot;state&quot;:&quot;Essonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;27&quot;,&quot;state&quot;:&quot;Eure&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;28&quot;,&quot;state&quot;:&quot;Eure-et-Loir&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;29&quot;,&quot;state&quot;:&quot;Finist\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;30&quot;,&quot;state&quot;:&quot;Gard&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;32&quot;,&quot;state&quot;:&quot;Gers&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;33&quot;,&quot;state&quot;:&quot;Gironde&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;68&quot;,&quot;state&quot;:&quot;Haut-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2B&quot;,&quot;state&quot;:&quot;Haute-Corse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;31&quot;,&quot;state&quot;:&quot;Haute-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;43&quot;,&quot;state&quot;:&quot;Haute-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;52&quot;,&quot;state&quot;:&quot;Haute-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;70&quot;,&quot;state&quot;:&quot;Haute-Sa\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;74&quot;,&quot;state&quot;:&quot;Haute-Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;87&quot;,&quot;state&quot;:&quot;Haute-Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;05&quot;,&quot;state&quot;:&quot;Hautes-Alpes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;65&quot;,&quot;state&quot;:&quot;Hautes-Pyr\u00e9n\u00e9es&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;92&quot;,&quot;state&quot;:&quot;Hauts-de-Seine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;34&quot;,&quot;state&quot;:&quot;H\u00e9rault&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;35&quot;,&quot;state&quot;:&quot;Ille-et-Vilaine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;36&quot;,&quot;state&quot;:&quot;Indre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;37&quot;,&quot;state&quot;:&quot;Indre-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;38&quot;,&quot;state&quot;:&quot;Is\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;39&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;40&quot;,&quot;state&quot;:&quot;Landes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;41&quot;,&quot;state&quot;:&quot;Loir-et-Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;42&quot;,&quot;state&quot;:&quot;Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;44&quot;,&quot;state&quot;:&quot;Loire-Atlantique&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;45&quot;,&quot;state&quot;:&quot;Loiret&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;46&quot;,&quot;state&quot;:&quot;Lot&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;47&quot;,&quot;state&quot;:&quot;Lot-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;48&quot;,&quot;state&quot;:&quot;Loz\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;49&quot;,&quot;state&quot;:&quot;Maine-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;50&quot;,&quot;state&quot;:&quot;Manche&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;51&quot;,&quot;state&quot;:&quot;Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;53&quot;,&quot;state&quot;:&quot;Mayenne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;54&quot;,&quot;state&quot;:&quot;Meurthe-et-Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;55&quot;,&quot;state&quot;:&quot;Meuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;56&quot;,&quot;state&quot;:&quot;Morbihan&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;57&quot;,&quot;state&quot;:&quot;Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;58&quot;,&quot;state&quot;:&quot;Ni\u00e8vre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;59&quot;,&quot;state&quot;:&quot;Nord&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;60&quot;,&quot;state&quot;:&quot;Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;61&quot;,&quot;state&quot;:&quot;Orne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;75&quot;,&quot;state&quot;:&quot;Paris&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;62&quot;,&quot;state&quot;:&quot;Pas-de-Calais&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;63&quot;,&quot;state&quot;:&quot;Puy-de-D\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;64&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Atlantiques&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;66&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Orientales&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;69&quot;,&quot;state&quot;:&quot;Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;71&quot;,&quot;state&quot;:&quot;Sa\u00f4ne-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;72&quot;,&quot;state&quot;:&quot;Sarthe&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;73&quot;,&quot;state&quot;:&quot;Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;77&quot;,&quot;state&quot;:&quot;Seine-et-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;76&quot;,&quot;state&quot;:&quot;Seine-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;93&quot;,&quot;state&quot;:&quot;Seine-Saint-Denis&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;80&quot;,&quot;state&quot;:&quot;Somme&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;81&quot;,&quot;state&quot;:&quot;Tarn&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;82&quot;,&quot;state&quot;:&quot;Tarn-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;90&quot;,&quot;state&quot;:&quot;Territoire de Belfort&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;95&quot;,&quot;state&quot;:&quot;Val-d'Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;94&quot;,&quot;state&quot;:&quot;Val-de-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;83&quot;,&quot;state&quot;:&quot;Var&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;84&quot;,&quot;state&quot;:&quot;Vaucluse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;85&quot;,&quot;state&quot;:&quot;Vend\u00e9e&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;86&quot;,&quot;state&quot;:&quot;Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;88&quot;,&quot;state&quot;:&quot;Vosges&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;89&quot;,&quot;state&quot;:&quot;Yonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;78&quot;,&quot;state&quot;:&quot;Yvelines&quot;}],&quot;GB&quot;:[{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABN&quot;,&quot;state&quot;:&quot;Aberdeen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABNS&quot;,&quot;state&quot;:&quot;Aberdeenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANG&quot;,&quot;state&quot;:&quot;Anglesey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AGS&quot;,&quot;state&quot;:&quot;Angus&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARY&quot;,&quot;state&quot;:&quot;Argyll and Bute&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AVN&quot;,&quot;state&quot;:&quot;Avon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BAN&quot;,&quot;state&quot;:&quot;Banffshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEDS&quot;,&quot;state&quot;:&quot;Bedfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BERKS&quot;,&quot;state&quot;:&quot;Berkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEW&quot;,&quot;state&quot;:&quot;Berwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BLA&quot;,&quot;state&quot;:&quot;Blaenau Gwent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BRI&quot;,&quot;state&quot;:&quot;Bridgend&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BSTL&quot;,&quot;state&quot;:&quot;Bristol&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BUCKS&quot;,&quot;state&quot;:&quot;Buckinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAE&quot;,&quot;state&quot;:&quot;Caerphilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAI&quot;,&quot;state&quot;:&quot;Caithness&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAMBS&quot;,&quot;state&quot;:&quot;Cambridgeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDF&quot;,&quot;state&quot;:&quot;Cardiff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CARM&quot;,&quot;state&quot;:&quot;Carmarthenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDGN&quot;,&quot;state&quot;:&quot;Ceredigion&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CHES&quot;,&quot;state&quot;:&quot;Cheshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLACK&quot;,&quot;state&quot;:&quot;Clackmannanshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLV&quot;,&quot;state&quot;:&quot;Cleveland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CWD&quot;,&quot;state&quot;:&quot;Clwyd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CON&quot;,&quot;state&quot;:&quot;Conwy&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CORN&quot;,&quot;state&quot;:&quot;Cornwall&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANT&quot;,&quot;state&quot;:&quot;County Antrim&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARM&quot;,&quot;state&quot;:&quot;County Armagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOW&quot;,&quot;state&quot;:&quot;County Down&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FER&quot;,&quot;state&quot;:&quot;County Fermanagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDY&quot;,&quot;state&quot;:&quot;County Londonderry&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TYR&quot;,&quot;state&quot;:&quot;County Tyrone&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CMA&quot;,&quot;state&quot;:&quot;Cumbria&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DNBG&quot;,&quot;state&quot;:&quot;Denbighshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DERBY&quot;,&quot;state&quot;:&quot;Derbyshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DVN&quot;,&quot;state&quot;:&quot;Devon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOR&quot;,&quot;state&quot;:&quot;Dorset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DGL&quot;,&quot;state&quot;:&quot;Dumfries and Galloway&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFS&quot;,&quot;state&quot;:&quot;Dumfries-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUND&quot;,&quot;state&quot;:&quot;Dundee&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DHM&quot;,&quot;state&quot;:&quot;Durham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFD&quot;,&quot;state&quot;:&quot;Dyfed&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYE&quot;,&quot;state&quot;:&quot;East Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUNBE&quot;,&quot;state&quot;:&quot;East Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LOTE&quot;,&quot;state&quot;:&quot;East Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RENE&quot;,&quot;state&quot;:&quot;East Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ERYS&quot;,&quot;state&quot;:&quot;East Riding of Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXE&quot;,&quot;state&quot;:&quot;East Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;EDIN&quot;,&quot;state&quot;:&quot;Edinburgh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ESX&quot;,&quot;state&quot;:&quot;Essex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FALK&quot;,&quot;state&quot;:&quot;Falkirk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FFE&quot;,&quot;state&quot;:&quot;Fife&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FLINT&quot;,&quot;state&quot;:&quot;Flintshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLAS&quot;,&quot;state&quot;:&quot;Glasgow&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLOS&quot;,&quot;state&quot;:&quot;Gloucestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDN&quot;,&quot;state&quot;:&quot;Greater London&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MCH&quot;,&quot;state&quot;:&quot;Greater Manchester&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GDD&quot;,&quot;state&quot;:&quot;Gwynedd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HANTS&quot;,&quot;state&quot;:&quot;Hampshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HWR&quot;,&quot;state&quot;:&quot;Herefordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HERTS&quot;,&quot;state&quot;:&quot;Hertfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HLD&quot;,&quot;state&quot;:&quot;Highlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HUM&quot;,&quot;state&quot;:&quot;Humberside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IVER&quot;,&quot;state&quot;:&quot;Inverclyde&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;INV&quot;,&quot;state&quot;:&quot;Inverness-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOW&quot;,&quot;state&quot;:&quot;Isle of Wight&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOS&quot;,&quot;state&quot;:&quot;Isles of Scilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KNT&quot;,&quot;state&quot;:&quot;Kent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KCD&quot;,&quot;state&quot;:&quot;Kincardineshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANCS&quot;,&quot;state&quot;:&quot;Lancashire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LEICS&quot;,&quot;state&quot;:&quot;Leicestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LINCS&quot;,&quot;state&quot;:&quot;Lincolnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MER&quot;,&quot;state&quot;:&quot;Merionethshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MSY&quot;,&quot;state&quot;:&quot;Merseyside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MERT&quot;,&quot;state&quot;:&quot;Merthyr Tydfil&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MDX&quot;,&quot;state&quot;:&quot;Middlesex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MLOT&quot;,&quot;state&quot;:&quot;Midlothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MMOUTH&quot;,&quot;state&quot;:&quot;Monmouthshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MORAY&quot;,&quot;state&quot;:&quot;Moray&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NAI&quot;,&quot;state&quot;:&quot;Nairnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NPRTAL&quot;,&quot;state&quot;:&quot;Neath Port Talbot&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NEWPT&quot;,&quot;state&quot;:&quot;Newport&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOR&quot;,&quot;state&quot;:&quot;Norfolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYN&quot;,&quot;state&quot;:&quot;North Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANN&quot;,&quot;state&quot;:&quot;North Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSN&quot;,&quot;state&quot;:&quot;North Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NHM&quot;,&quot;state&quot;:&quot;Northamptonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NLD&quot;,&quot;state&quot;:&quot;Northumberland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOT&quot;,&quot;state&quot;:&quot;Nottinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ORK&quot;,&quot;state&quot;:&quot;Orkney Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;OFE&quot;,&quot;state&quot;:&quot;Oxfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEE&quot;,&quot;state&quot;:&quot;Peebles-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEM&quot;,&quot;state&quot;:&quot;Pembrokeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PERTH&quot;,&quot;state&quot;:&quot;Perth and Kinross&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PWS&quot;,&quot;state&quot;:&quot;Powys&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;REN&quot;,&quot;state&quot;:&quot;Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RHON&quot;,&quot;state&quot;:&quot;Rhondda Cynon Taff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ROX&quot;,&quot;state&quot;:&quot;Roxburghshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RUT&quot;,&quot;state&quot;:&quot;Rutland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BOR&quot;,&quot;state&quot;:&quot;Scottish Borders&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SEL&quot;,&quot;state&quot;:&quot;Selkirkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SHET&quot;,&quot;state&quot;:&quot;Shetland Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Shropshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SOM&quot;,&quot;state&quot;:&quot;Somerset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYS&quot;,&quot;state&quot;:&quot;South Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANS&quot;,&quot;state&quot;:&quot;South Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SYK&quot;,&quot;state&quot;:&quot;South Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFD&quot;,&quot;state&quot;:&quot;Staffordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STIR&quot;,&quot;state&quot;:&quot;Stirling&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STI&quot;,&quot;state&quot;:&quot;Stirlingshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFK&quot;,&quot;state&quot;:&quot;Suffolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SRY&quot;,&quot;state&quot;:&quot;Surrey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SUT&quot;,&quot;state&quot;:&quot;Sutherland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SWAN&quot;,&quot;state&quot;:&quot;Swansea&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TORF&quot;,&quot;state&quot;:&quot;Torfaen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TWR&quot;,&quot;state&quot;:&quot;Tyne and Wear&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;VGLAM&quot;,&quot;state&quot;:&quot;Vale of Glamorgan&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WARKS&quot;,&quot;state&quot;:&quot;Warwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WDUN&quot;,&quot;state&quot;:&quot;West Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLOT&quot;,&quot;state&quot;:&quot;West Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WMD&quot;,&quot;state&quot;:&quot;West Midlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXW&quot;,&quot;state&quot;:&quot;West Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSW&quot;,&quot;state&quot;:&quot;West Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIL&quot;,&quot;state&quot;:&quot;Western Isles&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIG&quot;,&quot;state&quot;:&quot;Wigtownshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLT&quot;,&quot;state&quot;:&quot;Wiltshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WORCS&quot;,&quot;state&quot;:&quot;Worcestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WRX&quot;,&quot;state&quot;:&quot;Wrexham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YKS&quot;,&quot;state&quot;:&quot;Yorkshire&quot;}],&quot;IT&quot;:[{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Agrigento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alessandria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AN&quot;,&quot;state&quot;:&quot;Ancona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AO&quot;,&quot;state&quot;:&quot;Aosta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arezzo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AP&quot;,&quot;state&quot;:&quot;Ascoli Piceno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AT&quot;,&quot;state&quot;:&quot;Asti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;Avellino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Bari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;Belluno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;Benevento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BG&quot;,&quot;state&quot;:&quot;Bergamo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Biella&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BO&quot;,&quot;state&quot;:&quot;Bologna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;Bolzano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;Brescia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;Brindisi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;Cagliari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;Caltanissetta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CB&quot;,&quot;state&quot;:&quot;Campobasso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CI&quot;,&quot;state&quot;:&quot;Carbonia-Iglesias&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Caserta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Catania&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CZ&quot;,&quot;state&quot;:&quot;Catanzaro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CH&quot;,&quot;state&quot;:&quot;Chieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Como&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Cosenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Cremona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Crotone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CN&quot;,&quot;state&quot;:&quot;Cuneo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;EN&quot;,&quot;state&quot;:&quot;Enna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FE&quot;,&quot;state&quot;:&quot;Ferrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FI&quot;,&quot;state&quot;:&quot;Firenze&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FG&quot;,&quot;state&quot;:&quot;Foggia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FC&quot;,&quot;state&quot;:&quot;Forli-Cesena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Frosinone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Genova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GO&quot;,&quot;state&quot;:&quot;Gorizia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grosseto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IM&quot;,&quot;state&quot;:&quot;Imperia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;Isernia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AQ&quot;,&quot;state&quot;:&quot;L'Aquila&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SP&quot;,&quot;state&quot;:&quot;La Spezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LT&quot;,&quot;state&quot;:&quot;Latina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Lecce&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LC&quot;,&quot;state&quot;:&quot;Lecco&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Livorno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;Lodi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucca&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MC&quot;,&quot;state&quot;:&quot;Macerata&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Mantova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Massa-Carrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Matera&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Medio Campidano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Messina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Milano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Modena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Napoli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NO&quot;,&quot;state&quot;:&quot;Novara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nuoro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OG&quot;,&quot;state&quot;:&quot;Ogliastra&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;Olbia-Tempio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oristano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PD&quot;,&quot;state&quot;:&quot;Padova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Palermo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Parma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PV&quot;,&quot;state&quot;:&quot;Pavia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PG&quot;,&quot;state&quot;:&quot;Perugia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PU&quot;,&quot;state&quot;:&quot;Pesaro e Urbino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Pescara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PC&quot;,&quot;state&quot;:&quot;Piacenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PI&quot;,&quot;state&quot;:&quot;Pisa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PT&quot;,&quot;state&quot;:&quot;Pistoia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PN&quot;,&quot;state&quot;:&quot;Pordenone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PZ&quot;,&quot;state&quot;:&quot;Potenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Prato&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RG&quot;,&quot;state&quot;:&quot;Ragusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RA&quot;,&quot;state&quot;:&quot;Ravenna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RC&quot;,&quot;state&quot;:&quot;Reggio Calabria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RE&quot;,&quot;state&quot;:&quot;Reggio Emilia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RN&quot;,&quot;state&quot;:&quot;Rimini&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RM&quot;,&quot;state&quot;:&quot;Roma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RO&quot;,&quot;state&quot;:&quot;Rovigo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salerno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Sassari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;Savona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SI&quot;,&quot;state&quot;:&quot;Siena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SR&quot;,&quot;state&quot;:&quot;Siracusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Sondrio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Taranto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teramo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;Terni&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Torino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TP&quot;,&quot;state&quot;:&quot;Trapani&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Trento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TV&quot;,&quot;state&quot;:&quot;Treviso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TS&quot;,&quot;state&quot;:&quot;Trieste&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udine&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Varese&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VE&quot;,&quot;state&quot;:&quot;Venezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VB&quot;,&quot;state&quot;:&quot;Verbano-Cusio-Ossola&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VC&quot;,&quot;state&quot;:&quot;Vercelli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VR&quot;,&quot;state&quot;:&quot;Verona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VV&quot;,&quot;state&quot;:&quot;Vibo Valentia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Vicenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Viterbo&quot;}],&quot;JP&quot;:[{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AICHI&quot;,&quot;state&quot;:&quot;AICHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AKITA&quot;,&quot;state&quot;:&quot;AKITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AOMORI&quot;,&quot;state&quot;:&quot;AOMORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;CHIBA&quot;,&quot;state&quot;:&quot;CHIBA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;EHIME&quot;,&quot;state&quot;:&quot;EHIME&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUI&quot;,&quot;state&quot;:&quot;FUKUI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUOKA&quot;,&quot;state&quot;:&quot;FUKUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUSHIMA&quot;,&quot;state&quot;:&quot;FUKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GIFU&quot;,&quot;state&quot;:&quot;GIFU&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GUMMA&quot;,&quot;state&quot;:&quot;GUMMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HIROSHIMA&quot;,&quot;state&quot;:&quot;HIROSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HOKKAIDO&quot;,&quot;state&quot;:&quot;HOKKAIDO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HYOGO&quot;,&quot;state&quot;:&quot;HYOGO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IBARAKI&quot;,&quot;state&quot;:&quot;IBARAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;ISHIKAWA&quot;,&quot;state&quot;:&quot;ISHIKAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IWATE&quot;,&quot;state&quot;:&quot;IWATE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGAWA&quot;,&quot;state&quot;:&quot;KAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGOSHIMA&quot;,&quot;state&quot;:&quot;KAGOSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KANAGAWA&quot;,&quot;state&quot;:&quot;KANAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KOCHI&quot;,&quot;state&quot;:&quot;KOCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KUMAMOTO&quot;,&quot;state&quot;:&quot;KUMAMOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KYOTO&quot;,&quot;state&quot;:&quot;KYOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIE&quot;,&quot;state&quot;:&quot;MIE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAGI&quot;,&quot;state&quot;:&quot;MIYAGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAZAKI&quot;,&quot;state&quot;:&quot;MIYAZAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGANO&quot;,&quot;state&quot;:&quot;NAGANO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGASAKI&quot;,&quot;state&quot;:&quot;NAGASAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NARA&quot;,&quot;state&quot;:&quot;NARA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NIIGATA&quot;,&quot;state&quot;:&quot;NIIGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OITA&quot;,&quot;state&quot;:&quot;OITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKAYAMA&quot;,&quot;state&quot;:&quot;OKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKINAWA&quot;,&quot;state&quot;:&quot;OKINAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OSAKA&quot;,&quot;state&quot;:&quot;OSAKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAGA&quot;,&quot;state&quot;:&quot;SAGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAITAMA&quot;,&quot;state&quot;:&quot;SAITAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIGA&quot;,&quot;state&quot;:&quot;SHIGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIMANE&quot;,&quot;state&quot;:&quot;SHIMANE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIZUOKA&quot;,&quot;state&quot;:&quot;SHIZUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOCHIGI&quot;,&quot;state&quot;:&quot;TOCHIGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKUSHIMA&quot;,&quot;state&quot;:&quot;TOKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKYO&quot;,&quot;state&quot;:&quot;TOKYO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOTTORI&quot;,&quot;state&quot;:&quot;TOTTORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOYAMA&quot;,&quot;state&quot;:&quot;TOYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;WAKAYAMA&quot;,&quot;state&quot;:&quot;WAKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGATA&quot;,&quot;state&quot;:&quot;YAMAGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGUCHI&quot;,&quot;state&quot;:&quot;YAMAGUCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMANASHI&quot;,&quot;state&quot;:&quot;YAMANASHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4e09\u91cd\u770c&quot;,&quot;state&quot;:&quot;\u4e09\u91cd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4eac\u90fd\u5e9c&quot;,&quot;state&quot;:&quot;\u4eac\u90fd\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4f50\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u4f50\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5175\u5eab\u770c&quot;,&quot;state&quot;:&quot;\u5175\u5eab\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5317\u6d77\u9053&quot;,&quot;state&quot;:&quot;\u5317\u6d77\u9053&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5343\u8449\u770c&quot;,&quot;state&quot;:&quot;\u5343\u8449\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u57fc\u7389\u770c&quot;,&quot;state&quot;:&quot;\u57fc\u7389\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u5206\u770c&quot;,&quot;state&quot;:&quot;\u5927\u5206\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u962a\u5e9c&quot;,&quot;state&quot;:&quot;\u5927\u962a\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5948\u826f\u770c&quot;,&quot;state&quot;:&quot;\u5948\u826f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bcc\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5bcc\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u53e3\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u53e3\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u5f62\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u5f62\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u68a8\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u68a8\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c90\u961c\u770c&quot;,&quot;state&quot;:&quot;\u5c90\u961c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca1\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5ca1\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca9\u624b\u770c&quot;,&quot;state&quot;:&quot;\u5ca9\u624b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5cf6\u6839\u770c&quot;,&quot;state&quot;:&quot;\u5cf6\u6839\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5e83\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5e83\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5fb3\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5fb3\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u5a9b\u770c&quot;,&quot;state&quot;:&quot;\u611b\u5a9b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u611b\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u65b0\u6f5f\u770c&quot;,&quot;state&quot;:&quot;\u65b0\u6f5f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6771\u4eac\u90fd&quot;,&quot;state&quot;:&quot;\u6771\u4eac\u90fd&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6803\u6728\u770c&quot;,&quot;state&quot;:&quot;\u6803\u6728\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6c96\u7e04\u770c&quot;,&quot;state&quot;:&quot;\u6c96\u7e04\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6ecb\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u6ecb\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u718a\u672c\u770c&quot;,&quot;state&quot;:&quot;\u718a\u672c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u77f3\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u77f3\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u4e95\u770c&quot;,&quot;state&quot;:&quot;\u798f\u4e95\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u79cb\u7530\u770c&quot;,&quot;state&quot;:&quot;\u79cb\u7530\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u7fa4\u99ac\u770c&quot;,&quot;state&quot;:&quot;\u7fa4\u99ac\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u8328\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u8328\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u9577\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u91ce\u770c&quot;,&quot;state&quot;:&quot;\u9577\u91ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9752\u68ee\u770c&quot;,&quot;state&quot;:&quot;\u9752\u68ee\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9759\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u9759\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9999\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u9999\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ad8\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u9ad8\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ce5\u53d6\u770c&quot;,&quot;state&quot;:&quot;\u9ce5\u53d6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;}],&quot;NL&quot;:[{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;DR&quot;,&quot;state&quot;:&quot;Drenthe&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Flevoland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Friesland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gelderland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Groningen&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Limburg&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;Noord Brabant&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;Noord Holland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;OV&quot;,&quot;state&quot;:&quot;Overijssel&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utrecht&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZE&quot;,&quot;state&quot;:&quot;Zeeland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zuid Holland&quot;}],&quot;RO&quot;:[{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;ALBA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;ARAD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;ARGES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;BACAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BH&quot;,&quot;state&quot;:&quot;BIHOR&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;BISTRITA-NASAUD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BT&quot;,&quot;state&quot;:&quot;BOTOSANI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;BRAILA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BV&quot;,&quot;state&quot;:&quot;BRASOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;BUCURESTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;BUZAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;CALARASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;CARAS-SEVERIN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CJ&quot;,&quot;state&quot;:&quot;CLUJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CV&quot;,&quot;state&quot;:&quot;COVASNA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DB&quot;,&quot;state&quot;:&quot;DAMBOVITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DJ&quot;,&quot;state&quot;:&quot;DOLJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;GALATI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;GIURGIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GJ&quot;,&quot;state&quot;:&quot;GORJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HR&quot;,&quot;state&quot;:&quot;HARGHITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HD&quot;,&quot;state&quot;:&quot;HUNEDOARA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;IALOMITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;IASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IF&quot;,&quot;state&quot;:&quot;ILFOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MM&quot;,&quot;state&quot;:&quot;MARAMURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MH&quot;,&quot;state&quot;:&quot;MEHEDINTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;MURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;NEAMT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;OLT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;PH&quot;,&quot;state&quot;:&quot;PRAHOVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SJ&quot;,&quot;state&quot;:&quot;SALAJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SM&quot;,&quot;state&quot;:&quot;SATU MARE&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SB&quot;,&quot;state&quot;:&quot;SIBIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;SUCEAVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;TELEORMAN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TM&quot;,&quot;state&quot;:&quot;TIMIS&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TL&quot;,&quot;state&quot;:&quot;TULCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VL&quot;,&quot;state&quot;:&quot;VALCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;VASLUI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VN&quot;,&quot;state&quot;:&quot;VRANCEA&quot;}],&quot;RU&quot;:[{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ALT&quot;,&quot;state&quot;:&quot;Altajskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AMU&quot;,&quot;state&quot;:&quot;Amurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ARK&quot;,&quot;state&quot;:&quot;Arhangel'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AST&quot;,&quot;state&quot;:&quot;Astrahanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BEL&quot;,&quot;state&quot;:&quot;Belgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BRY&quot;,&quot;state&quot;:&quot;Brjanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Chechenskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHE&quot;,&quot;state&quot;:&quot;Cheljabinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHU&quot;,&quot;state&quot;:&quot;Chukotskij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Chuvashskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YEV&quot;,&quot;state&quot;:&quot;Evrejskaja avtonomnaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHA&quot;,&quot;state&quot;:&quot;Habarovskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHM&quot;,&quot;state&quot;:&quot;Hanty-Mansijskij avtonomnyj okrug - Jugra&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IRK&quot;,&quot;state&quot;:&quot;Irkutskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IVA&quot;,&quot;state&quot;:&quot;Ivanovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAN&quot;,&quot;state&quot;:&quot;Jamalo-Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAR&quot;,&quot;state&quot;:&quot;Jaroslavskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KB&quot;,&quot;state&quot;:&quot;Kabardino-Balkarskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGD&quot;,&quot;state&quot;:&quot;Kaliningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KLU&quot;,&quot;state&quot;:&quot;Kaluzhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KAM&quot;,&quot;state&quot;:&quot;Kamchatskiy kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KC&quot;,&quot;state&quot;:&quot;Karachaevo-Cherkesskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KEM&quot;,&quot;state&quot;:&quot;Kemerovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIR&quot;,&quot;state&quot;:&quot;Kirovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KOS&quot;,&quot;state&quot;:&quot;Kostromskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KDA&quot;,&quot;state&quot;:&quot;Krasnodarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIA&quot;,&quot;state&quot;:&quot;Krasnojarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGN&quot;,&quot;state&quot;:&quot;Kurganskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KRS&quot;,&quot;state&quot;:&quot;Kurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LEN&quot;,&quot;state&quot;:&quot;Leningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LIP&quot;,&quot;state&quot;:&quot;Lipeckaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MAG&quot;,&quot;state&quot;:&quot;Magadanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOS&quot;,&quot;state&quot;:&quot;Moskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOW&quot;,&quot;state&quot;:&quot;Moskva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MUR&quot;,&quot;state&quot;:&quot;Murmanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NEN&quot;,&quot;state&quot;:&quot;Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NIZ&quot;,&quot;state&quot;:&quot;Nizhegorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NGR&quot;,&quot;state&quot;:&quot;Novgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NVS&quot;,&quot;state&quot;:&quot;Novosibirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;OMS&quot;,&quot;state&quot;:&quot;Omskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORE&quot;,&quot;state&quot;:&quot;Orenburgskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORL&quot;,&quot;state&quot;:&quot;Orlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PNZ&quot;,&quot;state&quot;:&quot;Penzenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PER&quot;,&quot;state&quot;:&quot;Permskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PRI&quot;,&quot;state&quot;:&quot;Primorskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PSK&quot;,&quot;state&quot;:&quot;Pskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AD&quot;,&quot;state&quot;:&quot;Respublika Adygeja&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Respublika Altaj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Respublika Bashkortostan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Respublika Burjatija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;DA&quot;,&quot;state&quot;:&quot;Respublika Dagestan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KK&quot;,&quot;state&quot;:&quot;Respublika Hakasija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Respublika Ingushetija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KL&quot;,&quot;state&quot;:&quot;Respublika Kalmykija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Respublika Karelija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KO&quot;,&quot;state&quot;:&quot;Respublika Komi&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Respublika Marij Jel&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Respublika Mordovija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Respublika Saha (Jakutija)&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Respublika Severnaja Osetija-Alanija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Respublika Tatarstan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TY&quot;,&quot;state&quot;:&quot;Respublika Tyva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;RYA&quot;,&quot;state&quot;:&quot;Rjazanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ROS&quot;,&quot;state&quot;:&quot;Rostovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAK&quot;,&quot;state&quot;:&quot;Sahalinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAM&quot;,&quot;state&quot;:&quot;Samarskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Sankt-Peterburg&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saratovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SMO&quot;,&quot;state&quot;:&quot;Smolenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;STA&quot;,&quot;state&quot;:&quot;Stavropol'skij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SVE&quot;,&quot;state&quot;:&quot;Sverdlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TAM&quot;,&quot;state&quot;:&quot;Tambovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TYU&quot;,&quot;state&quot;:&quot;Tjumenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TOM&quot;,&quot;state&quot;:&quot;Tomskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TUL&quot;,&quot;state&quot;:&quot;Tul'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TVE&quot;,&quot;state&quot;:&quot;Tverskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udmurtskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ULY&quot;,&quot;state&quot;:&quot;Ul'janovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLA&quot;,&quot;state&quot;:&quot;Vladimirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VGG&quot;,&quot;state&quot;:&quot;Volgogradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLG&quot;,&quot;state&quot;:&quot;Vologodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VOR&quot;,&quot;state&quot;:&quot;Voronezhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ZAB&quot;,&quot;state&quot;:&quot;Zabaykal'skiy kraj&quot;}],&quot;US&quot;:[{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alabama&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AK&quot;,&quot;state&quot;:&quot;Alaska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AZ&quot;,&quot;state&quot;:&quot;Arizona&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arkansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;California&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Colorado&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Connecticut&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DE&quot;,&quot;state&quot;:&quot;Delaware&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DC&quot;,&quot;state&quot;:&quot;District of Columbia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Florida&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GA&quot;,&quot;state&quot;:&quot;Georgia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guam&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;HI&quot;,&quot;state&quot;:&quot;Hawaii&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ID&quot;,&quot;state&quot;:&quot;Idaho&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;Illinois&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Indiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IA&quot;,&quot;state&quot;:&quot;Iowa&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KS&quot;,&quot;state&quot;:&quot;Kansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KY&quot;,&quot;state&quot;:&quot;Kentucky&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;LA&quot;,&quot;state&quot;:&quot;Louisiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Maine&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MD&quot;,&quot;state&quot;:&quot;Maryland&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;Massachusetts&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Michigan&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Minnesota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Mississippi&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Missouri&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Montana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Nebraska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NV&quot;,&quot;state&quot;:&quot;Nevada&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;New Hampshire&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NJ&quot;,&quot;state&quot;:&quot;New Jersey&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NM&quot;,&quot;state&quot;:&quot;New Mexico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NY&quot;,&quot;state&quot;:&quot;New York&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NC&quot;,&quot;state&quot;:&quot;North Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ND&quot;,&quot;state&quot;:&quot;North Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MP&quot;,&quot;state&quot;:&quot;Northern Mariana Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OH&quot;,&quot;state&quot;:&quot;Ohio&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OK&quot;,&quot;state&quot;:&quot;Oklahoma&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oregon&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Pennsylvania&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Puerto Rico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rhode Island&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SC&quot;,&quot;state&quot;:&quot;South Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SD&quot;,&quot;state&quot;:&quot;South Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Tennessee&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TX&quot;,&quot;state&quot;:&quot;Texas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utah&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Vermont&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Virgin Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Washington&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WV&quot;,&quot;state&quot;:&quot;West Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WI&quot;,&quot;state&quot;:&quot;Wisconsin&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WY&quot;,&quot;state&quot;:&quot;Wyoming&quot;}]},

// [filosof]
        countries_with_codes: {&quot;RO&quot;:&quot;RO&quot;}
// [/filosof]
    });

    
    $.ceFormValidator('setZipcode', {
        US: {
            regexp: /^(\d{5})(-\d{4})?$/,
            format: '01342 (01342-5678)'
        },
        CA: {
            regexp: /^(\w{3} ?\w{3})$/,
            format: 'V1A OB1 (V1AOB1)'
        },
        RU: {
            regexp: /^(\d{6})?$/,
            format: '123456'
        }
    });
    

}(Tygh, Tygh.$));
//]]>

    




    
                
                
                


 
     Select



    

               
            ,  
        {user_name}({email})
        

       
    
    
    

                    
                
            
        
        
        Purchase Date
        
                
    
    

    
    
    



    

    .ui-timepicker-div .ui-widget-header { margin-bottom: 8px; }
    .ui-timepicker-div dl { text-align: left; }
    .ui-timepicker-div dl dt { float: left; clear:left; padding: 0 0 0 5px; }
    .ui-timepicker-div dl dd { margin: 0 10px 10px 40%; }
    .ui-timepicker-div td { font-size: 90%; }
    .ui-tpicker-grid-label { background: none; border: none; margin: 0; padding: 0; }
    .ui-timepicker-div .ui_tpicker_unit_hide{ display: none; }

    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input { background: none; color: inherit; border: none; outline: none; border-bottom: solid 1px #555; width: 95%; }
    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input:focus { border-bottom-color: #aaa; }

    .ui-timepicker-rtl{ direction: rtl; }
    .ui-timepicker-rtl dl { text-align: right; padding: 0 5px 0 0; }
    .ui-timepicker-rtl dl dt{ float: right; clear: right; }
    .ui-timepicker-rtl dl dd { margin: 0 40% 10px 10px; }

    /* Shortened version style */
    .ui-timepicker-div.ui-timepicker-oneLine { padding-right: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time,
    .ui-timepicker-div.ui-timepicker-oneLine dt { display: none; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time_label { display: block; padding-top: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine dl { text-align: right; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd > div { display:inline-block; margin:0; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_minute:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_second:before { content:':'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_millisec:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_microsec:before { content:'.'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide,
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide:before{ display: none; }




//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
        // Keep variable name 'calendar_config' and its scope (global) for correct cloning with settings
        // (see js/tygh/node_cloning.js)
        calendar_config = {
            changeMonth: true,
            duration: 'fast',
            changeYear: true,
            numberOfMonths: 1,
            selectOtherMonths: true,
            showOtherMonths: true,
                        maxDate:'+0D',            firstDay: 1,
            dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            yearRange: '2015:2023',
            dateFormat: 'dd/mm/yy'
        };
        if ($('#search-purchase-date_0').hasClass('cm-datetimepicker')) {
            $('#search-purchase-date_0').datetimepicker(
                calendar_config
            ).attr('readonly', 'readonly');
        } else {
            $('#search-purchase-date_0').datepicker(
                calendar_config
            ).attr('readonly', 'readonly');
        }
    });
}(Tygh, Tygh.$));
//]]>


        
    
    
            


 
    



        Reset
    

                        
                        
                            
                                Where to find the code?
                                
                            
                        
                    
                    
    
                    
                        or
                            


 
     Register New
    


                    
                                    
            
        
        
        Register New
        
            
                
    
    
    
    
        
            Enter Device ID (Codentify)
            
                









    //&lt;![CDATA[
    (function(_, $) {
        $('.device-code-select_component_register_0').groupinputs();
    }(Tygh, Tygh.$));
    //]]>

            
        
                    
                Retailer
                
                                        
                        
                        
                            
                        
                        
                            






    
//&lt;![CDATA[
(function(_, $) {

    /* Do not put this code to document.ready, because it should be
       initialized first
    */
    $.ceRebuildStates('init', {
        default_country: 'RO',
        states: {&quot;&quot;:[{&quot;country_code&quot;:&quot;&quot;,&quot;code&quot;:&quot;CONSTANTA&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;}],&quot;AU&quot;:[{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;ACT&quot;,&quot;state&quot;:&quot;Australian Capital Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NSW&quot;,&quot;state&quot;:&quot;New South Wales&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northern Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;QLD&quot;,&quot;state&quot;:&quot;Queensland&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;South Australia&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;TAS&quot;,&quot;state&quot;:&quot;Tasmania&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;VIC&quot;,&quot;state&quot;:&quot;Victoria&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Western Australia&quot;}],&quot;BG&quot;:[{&quot;country_code&quot;:&quot;BG&quot;,&quot;code&quot;:&quot;SF&quot;,&quot;state&quot;:&quot;Sofia&quot;}],&quot;CA&quot;:[{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Alberta&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;British Columbia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;MB&quot;,&quot;state&quot;:&quot;Manitoba&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;New Brunswick&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NL&quot;,&quot;state&quot;:&quot;Newfoundland and Labrador&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northwest Territories&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NS&quot;,&quot;state&quot;:&quot;Nova Scotia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nunavut&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;ON&quot;,&quot;state&quot;:&quot;Ontario&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Prince Edward Island&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;QC&quot;,&quot;state&quot;:&quot;Quebec&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;SK&quot;,&quot;state&quot;:&quot;Saskatchewan&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;YT&quot;,&quot;state&quot;:&quot;Yukon&quot;}],&quot;CH&quot;:[{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Ext\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AI&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Int\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Argovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;B\u00e2le-Campagne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;B\u00e2le-Ville&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BE&quot;,&quot;state&quot;:&quot;Berne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Fribourg&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gen\u00e8ve&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;Glaris&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grisons&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;JU&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucerne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Neuch\u00e2tel&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NW&quot;,&quot;state&quot;:&quot;Nidwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;OW&quot;,&quot;state&quot;:&quot;Obwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Saint-Gall&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SH&quot;,&quot;state&quot;:&quot;Schaffhouse&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SZ&quot;,&quot;state&quot;:&quot;Schwytz&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soleure&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TI&quot;,&quot;state&quot;:&quot;Tessin&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TG&quot;,&quot;state&quot;:&quot;Thurgovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;UR&quot;,&quot;state&quot;:&quot;Uri&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Valais&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VD&quot;,&quot;state&quot;:&quot;Vaud&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZG&quot;,&quot;state&quot;:&quot;Zoug&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zurich&quot;}],&quot;DE&quot;:[{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAW&quot;,&quot;state&quot;:&quot;Baden-W\u00fcrttemberg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAY&quot;,&quot;state&quot;:&quot;Bayern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BER&quot;,&quot;state&quot;:&quot;Berlin&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRG&quot;,&quot;state&quot;:&quot;Branderburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRE&quot;,&quot;state&quot;:&quot;Bremen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HAM&quot;,&quot;state&quot;:&quot;Hamburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HES&quot;,&quot;state&quot;:&quot;Hessen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;MEC&quot;,&quot;state&quot;:&quot;Mecklenburg-Vorpommern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NDS&quot;,&quot;state&quot;:&quot;Niedersachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NRW&quot;,&quot;state&quot;:&quot;Nordrhein-Westfalen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;RHE&quot;,&quot;state&quot;:&quot;Rheinland-Pfalz&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saarland&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAS&quot;,&quot;state&quot;:&quot;Sachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAC&quot;,&quot;state&quot;:&quot;Sachsen-Anhalt&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SCN&quot;,&quot;state&quot;:&quot;Schleswig-Holstein&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;THE&quot;,&quot;state&quot;:&quot;Th\u00fcringen&quot;}],&quot;ES&quot;:[{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;C&quot;,&quot;state&quot;:&quot;A Coru\u00f1a&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;\u00c1lava&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Albacete&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;A&quot;,&quot;state&quot;:&quot;Alicante&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Almer\u00eda&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;O&quot;,&quot;state&quot;:&quot;Asturias&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;\u00c1vila&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Badajoz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PM&quot;,&quot;state&quot;:&quot;Baleares&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;Barcelona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Burgos&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CC&quot;,&quot;state&quot;:&quot;C\u00e1ceres&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;C\u00e1diz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;S&quot;,&quot;state&quot;:&quot;Cantabria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Castell\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Ceuta&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Ciudad Real&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;C\u00f3rdoba&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Cuenca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GI&quot;,&quot;state&quot;:&quot;Girona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Granada&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guadalajara&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Guip\u00fazcoa&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;H&quot;,&quot;state&quot;:&quot;Huelva&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;HU&quot;,&quot;state&quot;:&quot;Huesca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;J&quot;,&quot;state&quot;:&quot;Ja\u00e9n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;La Rioja&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GC&quot;,&quot;state&quot;:&quot;Las Palmas&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Le\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;L&quot;,&quot;state&quot;:&quot;Lleida&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lugo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;M&quot;,&quot;state&quot;:&quot;Madrid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;M\u00e1laga&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ML&quot;,&quot;state&quot;:&quot;Melilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MU&quot;,&quot;state&quot;:&quot;Murcia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Navarra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Ourense&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;P&quot;,&quot;state&quot;:&quot;Palencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Pontevedra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salamanca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TF&quot;,&quot;state&quot;:&quot;Santa Cruz de Tenerife&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Segovia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Sevilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;T&quot;,&quot;state&quot;:&quot;Tarragona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teruel&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Toledo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;V&quot;,&quot;state&quot;:&quot;Valencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Valladolid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Vizcaya&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ZA&quot;,&quot;state&quot;:&quot;Zamora&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;Z&quot;,&quot;state&quot;:&quot;Zaragoza&quot;}],&quot;FR&quot;:[{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;01&quot;,&quot;state&quot;:&quot;Ain&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;02&quot;,&quot;state&quot;:&quot;Aisne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;03&quot;,&quot;state&quot;:&quot;Allier&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;04&quot;,&quot;state&quot;:&quot;Alpes-de-Haute-Provence&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;06&quot;,&quot;state&quot;:&quot;Alpes-Maritimes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;07&quot;,&quot;state&quot;:&quot;Ard\u00e8che&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;08&quot;,&quot;state&quot;:&quot;Ardennes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;09&quot;,&quot;state&quot;:&quot;Ari\u00e8ge&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;10&quot;,&quot;state&quot;:&quot;Aube&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;11&quot;,&quot;state&quot;:&quot;Aude&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;12&quot;,&quot;state&quot;:&quot;Aveyron&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;67&quot;,&quot;state&quot;:&quot;Bas-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;13&quot;,&quot;state&quot;:&quot;Bouches-du-Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;14&quot;,&quot;state&quot;:&quot;Calvados&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;15&quot;,&quot;state&quot;:&quot;Cantal&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;16&quot;,&quot;state&quot;:&quot;Charente&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;17&quot;,&quot;state&quot;:&quot;Charente-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;18&quot;,&quot;state&quot;:&quot;Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;19&quot;,&quot;state&quot;:&quot;Corr\u00e8ze&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2A&quot;,&quot;state&quot;:&quot;Corse-du-Sud&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;21&quot;,&quot;state&quot;:&quot;C\u00f4te-d'Or&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;22&quot;,&quot;state&quot;:&quot;C\u00f4tes-d'Armor&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;23&quot;,&quot;state&quot;:&quot;Creuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;79&quot;,&quot;state&quot;:&quot;Deux-S\u00e8vres&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;24&quot;,&quot;state&quot;:&quot;Dordogne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;25&quot;,&quot;state&quot;:&quot;Doubs&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;26&quot;,&quot;state&quot;:&quot;Dr\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;91&quot;,&quot;state&quot;:&quot;Essonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;27&quot;,&quot;state&quot;:&quot;Eure&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;28&quot;,&quot;state&quot;:&quot;Eure-et-Loir&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;29&quot;,&quot;state&quot;:&quot;Finist\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;30&quot;,&quot;state&quot;:&quot;Gard&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;32&quot;,&quot;state&quot;:&quot;Gers&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;33&quot;,&quot;state&quot;:&quot;Gironde&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;68&quot;,&quot;state&quot;:&quot;Haut-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2B&quot;,&quot;state&quot;:&quot;Haute-Corse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;31&quot;,&quot;state&quot;:&quot;Haute-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;43&quot;,&quot;state&quot;:&quot;Haute-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;52&quot;,&quot;state&quot;:&quot;Haute-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;70&quot;,&quot;state&quot;:&quot;Haute-Sa\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;74&quot;,&quot;state&quot;:&quot;Haute-Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;87&quot;,&quot;state&quot;:&quot;Haute-Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;05&quot;,&quot;state&quot;:&quot;Hautes-Alpes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;65&quot;,&quot;state&quot;:&quot;Hautes-Pyr\u00e9n\u00e9es&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;92&quot;,&quot;state&quot;:&quot;Hauts-de-Seine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;34&quot;,&quot;state&quot;:&quot;H\u00e9rault&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;35&quot;,&quot;state&quot;:&quot;Ille-et-Vilaine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;36&quot;,&quot;state&quot;:&quot;Indre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;37&quot;,&quot;state&quot;:&quot;Indre-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;38&quot;,&quot;state&quot;:&quot;Is\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;39&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;40&quot;,&quot;state&quot;:&quot;Landes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;41&quot;,&quot;state&quot;:&quot;Loir-et-Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;42&quot;,&quot;state&quot;:&quot;Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;44&quot;,&quot;state&quot;:&quot;Loire-Atlantique&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;45&quot;,&quot;state&quot;:&quot;Loiret&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;46&quot;,&quot;state&quot;:&quot;Lot&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;47&quot;,&quot;state&quot;:&quot;Lot-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;48&quot;,&quot;state&quot;:&quot;Loz\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;49&quot;,&quot;state&quot;:&quot;Maine-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;50&quot;,&quot;state&quot;:&quot;Manche&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;51&quot;,&quot;state&quot;:&quot;Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;53&quot;,&quot;state&quot;:&quot;Mayenne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;54&quot;,&quot;state&quot;:&quot;Meurthe-et-Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;55&quot;,&quot;state&quot;:&quot;Meuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;56&quot;,&quot;state&quot;:&quot;Morbihan&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;57&quot;,&quot;state&quot;:&quot;Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;58&quot;,&quot;state&quot;:&quot;Ni\u00e8vre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;59&quot;,&quot;state&quot;:&quot;Nord&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;60&quot;,&quot;state&quot;:&quot;Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;61&quot;,&quot;state&quot;:&quot;Orne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;75&quot;,&quot;state&quot;:&quot;Paris&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;62&quot;,&quot;state&quot;:&quot;Pas-de-Calais&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;63&quot;,&quot;state&quot;:&quot;Puy-de-D\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;64&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Atlantiques&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;66&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Orientales&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;69&quot;,&quot;state&quot;:&quot;Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;71&quot;,&quot;state&quot;:&quot;Sa\u00f4ne-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;72&quot;,&quot;state&quot;:&quot;Sarthe&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;73&quot;,&quot;state&quot;:&quot;Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;77&quot;,&quot;state&quot;:&quot;Seine-et-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;76&quot;,&quot;state&quot;:&quot;Seine-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;93&quot;,&quot;state&quot;:&quot;Seine-Saint-Denis&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;80&quot;,&quot;state&quot;:&quot;Somme&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;81&quot;,&quot;state&quot;:&quot;Tarn&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;82&quot;,&quot;state&quot;:&quot;Tarn-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;90&quot;,&quot;state&quot;:&quot;Territoire de Belfort&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;95&quot;,&quot;state&quot;:&quot;Val-d'Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;94&quot;,&quot;state&quot;:&quot;Val-de-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;83&quot;,&quot;state&quot;:&quot;Var&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;84&quot;,&quot;state&quot;:&quot;Vaucluse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;85&quot;,&quot;state&quot;:&quot;Vend\u00e9e&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;86&quot;,&quot;state&quot;:&quot;Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;88&quot;,&quot;state&quot;:&quot;Vosges&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;89&quot;,&quot;state&quot;:&quot;Yonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;78&quot;,&quot;state&quot;:&quot;Yvelines&quot;}],&quot;GB&quot;:[{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABN&quot;,&quot;state&quot;:&quot;Aberdeen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABNS&quot;,&quot;state&quot;:&quot;Aberdeenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANG&quot;,&quot;state&quot;:&quot;Anglesey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AGS&quot;,&quot;state&quot;:&quot;Angus&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARY&quot;,&quot;state&quot;:&quot;Argyll and Bute&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AVN&quot;,&quot;state&quot;:&quot;Avon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BAN&quot;,&quot;state&quot;:&quot;Banffshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEDS&quot;,&quot;state&quot;:&quot;Bedfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BERKS&quot;,&quot;state&quot;:&quot;Berkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEW&quot;,&quot;state&quot;:&quot;Berwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BLA&quot;,&quot;state&quot;:&quot;Blaenau Gwent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BRI&quot;,&quot;state&quot;:&quot;Bridgend&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BSTL&quot;,&quot;state&quot;:&quot;Bristol&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BUCKS&quot;,&quot;state&quot;:&quot;Buckinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAE&quot;,&quot;state&quot;:&quot;Caerphilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAI&quot;,&quot;state&quot;:&quot;Caithness&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAMBS&quot;,&quot;state&quot;:&quot;Cambridgeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDF&quot;,&quot;state&quot;:&quot;Cardiff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CARM&quot;,&quot;state&quot;:&quot;Carmarthenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDGN&quot;,&quot;state&quot;:&quot;Ceredigion&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CHES&quot;,&quot;state&quot;:&quot;Cheshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLACK&quot;,&quot;state&quot;:&quot;Clackmannanshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLV&quot;,&quot;state&quot;:&quot;Cleveland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CWD&quot;,&quot;state&quot;:&quot;Clwyd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CON&quot;,&quot;state&quot;:&quot;Conwy&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CORN&quot;,&quot;state&quot;:&quot;Cornwall&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANT&quot;,&quot;state&quot;:&quot;County Antrim&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARM&quot;,&quot;state&quot;:&quot;County Armagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOW&quot;,&quot;state&quot;:&quot;County Down&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FER&quot;,&quot;state&quot;:&quot;County Fermanagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDY&quot;,&quot;state&quot;:&quot;County Londonderry&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TYR&quot;,&quot;state&quot;:&quot;County Tyrone&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CMA&quot;,&quot;state&quot;:&quot;Cumbria&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DNBG&quot;,&quot;state&quot;:&quot;Denbighshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DERBY&quot;,&quot;state&quot;:&quot;Derbyshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DVN&quot;,&quot;state&quot;:&quot;Devon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOR&quot;,&quot;state&quot;:&quot;Dorset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DGL&quot;,&quot;state&quot;:&quot;Dumfries and Galloway&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFS&quot;,&quot;state&quot;:&quot;Dumfries-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUND&quot;,&quot;state&quot;:&quot;Dundee&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DHM&quot;,&quot;state&quot;:&quot;Durham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFD&quot;,&quot;state&quot;:&quot;Dyfed&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYE&quot;,&quot;state&quot;:&quot;East Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUNBE&quot;,&quot;state&quot;:&quot;East Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LOTE&quot;,&quot;state&quot;:&quot;East Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RENE&quot;,&quot;state&quot;:&quot;East Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ERYS&quot;,&quot;state&quot;:&quot;East Riding of Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXE&quot;,&quot;state&quot;:&quot;East Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;EDIN&quot;,&quot;state&quot;:&quot;Edinburgh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ESX&quot;,&quot;state&quot;:&quot;Essex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FALK&quot;,&quot;state&quot;:&quot;Falkirk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FFE&quot;,&quot;state&quot;:&quot;Fife&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FLINT&quot;,&quot;state&quot;:&quot;Flintshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLAS&quot;,&quot;state&quot;:&quot;Glasgow&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLOS&quot;,&quot;state&quot;:&quot;Gloucestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDN&quot;,&quot;state&quot;:&quot;Greater London&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MCH&quot;,&quot;state&quot;:&quot;Greater Manchester&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GDD&quot;,&quot;state&quot;:&quot;Gwynedd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HANTS&quot;,&quot;state&quot;:&quot;Hampshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HWR&quot;,&quot;state&quot;:&quot;Herefordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HERTS&quot;,&quot;state&quot;:&quot;Hertfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HLD&quot;,&quot;state&quot;:&quot;Highlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HUM&quot;,&quot;state&quot;:&quot;Humberside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IVER&quot;,&quot;state&quot;:&quot;Inverclyde&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;INV&quot;,&quot;state&quot;:&quot;Inverness-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOW&quot;,&quot;state&quot;:&quot;Isle of Wight&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOS&quot;,&quot;state&quot;:&quot;Isles of Scilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KNT&quot;,&quot;state&quot;:&quot;Kent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KCD&quot;,&quot;state&quot;:&quot;Kincardineshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANCS&quot;,&quot;state&quot;:&quot;Lancashire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LEICS&quot;,&quot;state&quot;:&quot;Leicestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LINCS&quot;,&quot;state&quot;:&quot;Lincolnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MER&quot;,&quot;state&quot;:&quot;Merionethshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MSY&quot;,&quot;state&quot;:&quot;Merseyside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MERT&quot;,&quot;state&quot;:&quot;Merthyr Tydfil&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MDX&quot;,&quot;state&quot;:&quot;Middlesex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MLOT&quot;,&quot;state&quot;:&quot;Midlothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MMOUTH&quot;,&quot;state&quot;:&quot;Monmouthshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MORAY&quot;,&quot;state&quot;:&quot;Moray&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NAI&quot;,&quot;state&quot;:&quot;Nairnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NPRTAL&quot;,&quot;state&quot;:&quot;Neath Port Talbot&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NEWPT&quot;,&quot;state&quot;:&quot;Newport&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOR&quot;,&quot;state&quot;:&quot;Norfolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYN&quot;,&quot;state&quot;:&quot;North Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANN&quot;,&quot;state&quot;:&quot;North Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSN&quot;,&quot;state&quot;:&quot;North Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NHM&quot;,&quot;state&quot;:&quot;Northamptonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NLD&quot;,&quot;state&quot;:&quot;Northumberland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOT&quot;,&quot;state&quot;:&quot;Nottinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ORK&quot;,&quot;state&quot;:&quot;Orkney Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;OFE&quot;,&quot;state&quot;:&quot;Oxfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEE&quot;,&quot;state&quot;:&quot;Peebles-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEM&quot;,&quot;state&quot;:&quot;Pembrokeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PERTH&quot;,&quot;state&quot;:&quot;Perth and Kinross&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PWS&quot;,&quot;state&quot;:&quot;Powys&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;REN&quot;,&quot;state&quot;:&quot;Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RHON&quot;,&quot;state&quot;:&quot;Rhondda Cynon Taff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ROX&quot;,&quot;state&quot;:&quot;Roxburghshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RUT&quot;,&quot;state&quot;:&quot;Rutland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BOR&quot;,&quot;state&quot;:&quot;Scottish Borders&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SEL&quot;,&quot;state&quot;:&quot;Selkirkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SHET&quot;,&quot;state&quot;:&quot;Shetland Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Shropshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SOM&quot;,&quot;state&quot;:&quot;Somerset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYS&quot;,&quot;state&quot;:&quot;South Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANS&quot;,&quot;state&quot;:&quot;South Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SYK&quot;,&quot;state&quot;:&quot;South Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFD&quot;,&quot;state&quot;:&quot;Staffordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STIR&quot;,&quot;state&quot;:&quot;Stirling&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STI&quot;,&quot;state&quot;:&quot;Stirlingshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFK&quot;,&quot;state&quot;:&quot;Suffolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SRY&quot;,&quot;state&quot;:&quot;Surrey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SUT&quot;,&quot;state&quot;:&quot;Sutherland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SWAN&quot;,&quot;state&quot;:&quot;Swansea&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TORF&quot;,&quot;state&quot;:&quot;Torfaen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TWR&quot;,&quot;state&quot;:&quot;Tyne and Wear&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;VGLAM&quot;,&quot;state&quot;:&quot;Vale of Glamorgan&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WARKS&quot;,&quot;state&quot;:&quot;Warwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WDUN&quot;,&quot;state&quot;:&quot;West Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLOT&quot;,&quot;state&quot;:&quot;West Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WMD&quot;,&quot;state&quot;:&quot;West Midlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXW&quot;,&quot;state&quot;:&quot;West Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSW&quot;,&quot;state&quot;:&quot;West Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIL&quot;,&quot;state&quot;:&quot;Western Isles&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIG&quot;,&quot;state&quot;:&quot;Wigtownshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLT&quot;,&quot;state&quot;:&quot;Wiltshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WORCS&quot;,&quot;state&quot;:&quot;Worcestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WRX&quot;,&quot;state&quot;:&quot;Wrexham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YKS&quot;,&quot;state&quot;:&quot;Yorkshire&quot;}],&quot;IT&quot;:[{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Agrigento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alessandria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AN&quot;,&quot;state&quot;:&quot;Ancona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AO&quot;,&quot;state&quot;:&quot;Aosta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arezzo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AP&quot;,&quot;state&quot;:&quot;Ascoli Piceno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AT&quot;,&quot;state&quot;:&quot;Asti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;Avellino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Bari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;Belluno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;Benevento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BG&quot;,&quot;state&quot;:&quot;Bergamo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Biella&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BO&quot;,&quot;state&quot;:&quot;Bologna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;Bolzano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;Brescia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;Brindisi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;Cagliari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;Caltanissetta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CB&quot;,&quot;state&quot;:&quot;Campobasso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CI&quot;,&quot;state&quot;:&quot;Carbonia-Iglesias&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Caserta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Catania&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CZ&quot;,&quot;state&quot;:&quot;Catanzaro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CH&quot;,&quot;state&quot;:&quot;Chieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Como&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Cosenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Cremona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Crotone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CN&quot;,&quot;state&quot;:&quot;Cuneo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;EN&quot;,&quot;state&quot;:&quot;Enna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FE&quot;,&quot;state&quot;:&quot;Ferrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FI&quot;,&quot;state&quot;:&quot;Firenze&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FG&quot;,&quot;state&quot;:&quot;Foggia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FC&quot;,&quot;state&quot;:&quot;Forli-Cesena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Frosinone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Genova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GO&quot;,&quot;state&quot;:&quot;Gorizia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grosseto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IM&quot;,&quot;state&quot;:&quot;Imperia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;Isernia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AQ&quot;,&quot;state&quot;:&quot;L'Aquila&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SP&quot;,&quot;state&quot;:&quot;La Spezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LT&quot;,&quot;state&quot;:&quot;Latina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Lecce&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LC&quot;,&quot;state&quot;:&quot;Lecco&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Livorno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;Lodi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucca&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MC&quot;,&quot;state&quot;:&quot;Macerata&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Mantova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Massa-Carrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Matera&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Medio Campidano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Messina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Milano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Modena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Napoli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NO&quot;,&quot;state&quot;:&quot;Novara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nuoro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OG&quot;,&quot;state&quot;:&quot;Ogliastra&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;Olbia-Tempio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oristano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PD&quot;,&quot;state&quot;:&quot;Padova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Palermo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Parma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PV&quot;,&quot;state&quot;:&quot;Pavia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PG&quot;,&quot;state&quot;:&quot;Perugia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PU&quot;,&quot;state&quot;:&quot;Pesaro e Urbino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Pescara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PC&quot;,&quot;state&quot;:&quot;Piacenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PI&quot;,&quot;state&quot;:&quot;Pisa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PT&quot;,&quot;state&quot;:&quot;Pistoia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PN&quot;,&quot;state&quot;:&quot;Pordenone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PZ&quot;,&quot;state&quot;:&quot;Potenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Prato&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RG&quot;,&quot;state&quot;:&quot;Ragusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RA&quot;,&quot;state&quot;:&quot;Ravenna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RC&quot;,&quot;state&quot;:&quot;Reggio Calabria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RE&quot;,&quot;state&quot;:&quot;Reggio Emilia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RN&quot;,&quot;state&quot;:&quot;Rimini&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RM&quot;,&quot;state&quot;:&quot;Roma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RO&quot;,&quot;state&quot;:&quot;Rovigo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salerno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Sassari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;Savona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SI&quot;,&quot;state&quot;:&quot;Siena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SR&quot;,&quot;state&quot;:&quot;Siracusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Sondrio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Taranto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teramo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;Terni&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Torino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TP&quot;,&quot;state&quot;:&quot;Trapani&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Trento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TV&quot;,&quot;state&quot;:&quot;Treviso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TS&quot;,&quot;state&quot;:&quot;Trieste&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udine&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Varese&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VE&quot;,&quot;state&quot;:&quot;Venezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VB&quot;,&quot;state&quot;:&quot;Verbano-Cusio-Ossola&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VC&quot;,&quot;state&quot;:&quot;Vercelli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VR&quot;,&quot;state&quot;:&quot;Verona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VV&quot;,&quot;state&quot;:&quot;Vibo Valentia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Vicenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Viterbo&quot;}],&quot;JP&quot;:[{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AICHI&quot;,&quot;state&quot;:&quot;AICHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AKITA&quot;,&quot;state&quot;:&quot;AKITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AOMORI&quot;,&quot;state&quot;:&quot;AOMORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;CHIBA&quot;,&quot;state&quot;:&quot;CHIBA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;EHIME&quot;,&quot;state&quot;:&quot;EHIME&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUI&quot;,&quot;state&quot;:&quot;FUKUI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUOKA&quot;,&quot;state&quot;:&quot;FUKUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUSHIMA&quot;,&quot;state&quot;:&quot;FUKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GIFU&quot;,&quot;state&quot;:&quot;GIFU&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GUMMA&quot;,&quot;state&quot;:&quot;GUMMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HIROSHIMA&quot;,&quot;state&quot;:&quot;HIROSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HOKKAIDO&quot;,&quot;state&quot;:&quot;HOKKAIDO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HYOGO&quot;,&quot;state&quot;:&quot;HYOGO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IBARAKI&quot;,&quot;state&quot;:&quot;IBARAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;ISHIKAWA&quot;,&quot;state&quot;:&quot;ISHIKAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IWATE&quot;,&quot;state&quot;:&quot;IWATE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGAWA&quot;,&quot;state&quot;:&quot;KAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGOSHIMA&quot;,&quot;state&quot;:&quot;KAGOSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KANAGAWA&quot;,&quot;state&quot;:&quot;KANAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KOCHI&quot;,&quot;state&quot;:&quot;KOCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KUMAMOTO&quot;,&quot;state&quot;:&quot;KUMAMOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KYOTO&quot;,&quot;state&quot;:&quot;KYOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIE&quot;,&quot;state&quot;:&quot;MIE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAGI&quot;,&quot;state&quot;:&quot;MIYAGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAZAKI&quot;,&quot;state&quot;:&quot;MIYAZAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGANO&quot;,&quot;state&quot;:&quot;NAGANO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGASAKI&quot;,&quot;state&quot;:&quot;NAGASAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NARA&quot;,&quot;state&quot;:&quot;NARA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NIIGATA&quot;,&quot;state&quot;:&quot;NIIGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OITA&quot;,&quot;state&quot;:&quot;OITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKAYAMA&quot;,&quot;state&quot;:&quot;OKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKINAWA&quot;,&quot;state&quot;:&quot;OKINAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OSAKA&quot;,&quot;state&quot;:&quot;OSAKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAGA&quot;,&quot;state&quot;:&quot;SAGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAITAMA&quot;,&quot;state&quot;:&quot;SAITAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIGA&quot;,&quot;state&quot;:&quot;SHIGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIMANE&quot;,&quot;state&quot;:&quot;SHIMANE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIZUOKA&quot;,&quot;state&quot;:&quot;SHIZUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOCHIGI&quot;,&quot;state&quot;:&quot;TOCHIGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKUSHIMA&quot;,&quot;state&quot;:&quot;TOKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKYO&quot;,&quot;state&quot;:&quot;TOKYO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOTTORI&quot;,&quot;state&quot;:&quot;TOTTORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOYAMA&quot;,&quot;state&quot;:&quot;TOYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;WAKAYAMA&quot;,&quot;state&quot;:&quot;WAKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGATA&quot;,&quot;state&quot;:&quot;YAMAGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGUCHI&quot;,&quot;state&quot;:&quot;YAMAGUCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMANASHI&quot;,&quot;state&quot;:&quot;YAMANASHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4e09\u91cd\u770c&quot;,&quot;state&quot;:&quot;\u4e09\u91cd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4eac\u90fd\u5e9c&quot;,&quot;state&quot;:&quot;\u4eac\u90fd\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4f50\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u4f50\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5175\u5eab\u770c&quot;,&quot;state&quot;:&quot;\u5175\u5eab\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5317\u6d77\u9053&quot;,&quot;state&quot;:&quot;\u5317\u6d77\u9053&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5343\u8449\u770c&quot;,&quot;state&quot;:&quot;\u5343\u8449\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u57fc\u7389\u770c&quot;,&quot;state&quot;:&quot;\u57fc\u7389\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u5206\u770c&quot;,&quot;state&quot;:&quot;\u5927\u5206\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u962a\u5e9c&quot;,&quot;state&quot;:&quot;\u5927\u962a\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5948\u826f\u770c&quot;,&quot;state&quot;:&quot;\u5948\u826f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bcc\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5bcc\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u53e3\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u53e3\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u5f62\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u5f62\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u68a8\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u68a8\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c90\u961c\u770c&quot;,&quot;state&quot;:&quot;\u5c90\u961c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca1\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5ca1\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca9\u624b\u770c&quot;,&quot;state&quot;:&quot;\u5ca9\u624b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5cf6\u6839\u770c&quot;,&quot;state&quot;:&quot;\u5cf6\u6839\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5e83\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5e83\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5fb3\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5fb3\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u5a9b\u770c&quot;,&quot;state&quot;:&quot;\u611b\u5a9b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u611b\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u65b0\u6f5f\u770c&quot;,&quot;state&quot;:&quot;\u65b0\u6f5f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6771\u4eac\u90fd&quot;,&quot;state&quot;:&quot;\u6771\u4eac\u90fd&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6803\u6728\u770c&quot;,&quot;state&quot;:&quot;\u6803\u6728\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6c96\u7e04\u770c&quot;,&quot;state&quot;:&quot;\u6c96\u7e04\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6ecb\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u6ecb\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u718a\u672c\u770c&quot;,&quot;state&quot;:&quot;\u718a\u672c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u77f3\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u77f3\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u4e95\u770c&quot;,&quot;state&quot;:&quot;\u798f\u4e95\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u79cb\u7530\u770c&quot;,&quot;state&quot;:&quot;\u79cb\u7530\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u7fa4\u99ac\u770c&quot;,&quot;state&quot;:&quot;\u7fa4\u99ac\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u8328\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u8328\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u9577\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u91ce\u770c&quot;,&quot;state&quot;:&quot;\u9577\u91ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9752\u68ee\u770c&quot;,&quot;state&quot;:&quot;\u9752\u68ee\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9759\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u9759\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9999\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u9999\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ad8\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u9ad8\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ce5\u53d6\u770c&quot;,&quot;state&quot;:&quot;\u9ce5\u53d6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;}],&quot;NL&quot;:[{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;DR&quot;,&quot;state&quot;:&quot;Drenthe&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Flevoland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Friesland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gelderland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Groningen&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Limburg&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;Noord Brabant&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;Noord Holland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;OV&quot;,&quot;state&quot;:&quot;Overijssel&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utrecht&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZE&quot;,&quot;state&quot;:&quot;Zeeland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zuid Holland&quot;}],&quot;RO&quot;:[{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;ALBA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;ARAD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;ARGES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;BACAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BH&quot;,&quot;state&quot;:&quot;BIHOR&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;BISTRITA-NASAUD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BT&quot;,&quot;state&quot;:&quot;BOTOSANI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;BRAILA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BV&quot;,&quot;state&quot;:&quot;BRASOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;BUCURESTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;BUZAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;CALARASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;CARAS-SEVERIN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CJ&quot;,&quot;state&quot;:&quot;CLUJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CV&quot;,&quot;state&quot;:&quot;COVASNA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DB&quot;,&quot;state&quot;:&quot;DAMBOVITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DJ&quot;,&quot;state&quot;:&quot;DOLJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;GALATI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;GIURGIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GJ&quot;,&quot;state&quot;:&quot;GORJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HR&quot;,&quot;state&quot;:&quot;HARGHITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HD&quot;,&quot;state&quot;:&quot;HUNEDOARA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;IALOMITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;IASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IF&quot;,&quot;state&quot;:&quot;ILFOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MM&quot;,&quot;state&quot;:&quot;MARAMURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MH&quot;,&quot;state&quot;:&quot;MEHEDINTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;MURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;NEAMT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;OLT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;PH&quot;,&quot;state&quot;:&quot;PRAHOVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SJ&quot;,&quot;state&quot;:&quot;SALAJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SM&quot;,&quot;state&quot;:&quot;SATU MARE&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SB&quot;,&quot;state&quot;:&quot;SIBIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;SUCEAVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;TELEORMAN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TM&quot;,&quot;state&quot;:&quot;TIMIS&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TL&quot;,&quot;state&quot;:&quot;TULCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VL&quot;,&quot;state&quot;:&quot;VALCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;VASLUI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VN&quot;,&quot;state&quot;:&quot;VRANCEA&quot;}],&quot;RU&quot;:[{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ALT&quot;,&quot;state&quot;:&quot;Altajskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AMU&quot;,&quot;state&quot;:&quot;Amurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ARK&quot;,&quot;state&quot;:&quot;Arhangel'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AST&quot;,&quot;state&quot;:&quot;Astrahanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BEL&quot;,&quot;state&quot;:&quot;Belgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BRY&quot;,&quot;state&quot;:&quot;Brjanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Chechenskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHE&quot;,&quot;state&quot;:&quot;Cheljabinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHU&quot;,&quot;state&quot;:&quot;Chukotskij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Chuvashskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YEV&quot;,&quot;state&quot;:&quot;Evrejskaja avtonomnaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHA&quot;,&quot;state&quot;:&quot;Habarovskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHM&quot;,&quot;state&quot;:&quot;Hanty-Mansijskij avtonomnyj okrug - Jugra&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IRK&quot;,&quot;state&quot;:&quot;Irkutskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IVA&quot;,&quot;state&quot;:&quot;Ivanovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAN&quot;,&quot;state&quot;:&quot;Jamalo-Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAR&quot;,&quot;state&quot;:&quot;Jaroslavskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KB&quot;,&quot;state&quot;:&quot;Kabardino-Balkarskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGD&quot;,&quot;state&quot;:&quot;Kaliningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KLU&quot;,&quot;state&quot;:&quot;Kaluzhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KAM&quot;,&quot;state&quot;:&quot;Kamchatskiy kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KC&quot;,&quot;state&quot;:&quot;Karachaevo-Cherkesskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KEM&quot;,&quot;state&quot;:&quot;Kemerovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIR&quot;,&quot;state&quot;:&quot;Kirovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KOS&quot;,&quot;state&quot;:&quot;Kostromskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KDA&quot;,&quot;state&quot;:&quot;Krasnodarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIA&quot;,&quot;state&quot;:&quot;Krasnojarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGN&quot;,&quot;state&quot;:&quot;Kurganskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KRS&quot;,&quot;state&quot;:&quot;Kurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LEN&quot;,&quot;state&quot;:&quot;Leningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LIP&quot;,&quot;state&quot;:&quot;Lipeckaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MAG&quot;,&quot;state&quot;:&quot;Magadanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOS&quot;,&quot;state&quot;:&quot;Moskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOW&quot;,&quot;state&quot;:&quot;Moskva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MUR&quot;,&quot;state&quot;:&quot;Murmanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NEN&quot;,&quot;state&quot;:&quot;Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NIZ&quot;,&quot;state&quot;:&quot;Nizhegorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NGR&quot;,&quot;state&quot;:&quot;Novgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NVS&quot;,&quot;state&quot;:&quot;Novosibirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;OMS&quot;,&quot;state&quot;:&quot;Omskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORE&quot;,&quot;state&quot;:&quot;Orenburgskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORL&quot;,&quot;state&quot;:&quot;Orlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PNZ&quot;,&quot;state&quot;:&quot;Penzenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PER&quot;,&quot;state&quot;:&quot;Permskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PRI&quot;,&quot;state&quot;:&quot;Primorskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PSK&quot;,&quot;state&quot;:&quot;Pskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AD&quot;,&quot;state&quot;:&quot;Respublika Adygeja&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Respublika Altaj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Respublika Bashkortostan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Respublika Burjatija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;DA&quot;,&quot;state&quot;:&quot;Respublika Dagestan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KK&quot;,&quot;state&quot;:&quot;Respublika Hakasija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Respublika Ingushetija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KL&quot;,&quot;state&quot;:&quot;Respublika Kalmykija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Respublika Karelija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KO&quot;,&quot;state&quot;:&quot;Respublika Komi&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Respublika Marij Jel&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Respublika Mordovija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Respublika Saha (Jakutija)&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Respublika Severnaja Osetija-Alanija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Respublika Tatarstan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TY&quot;,&quot;state&quot;:&quot;Respublika Tyva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;RYA&quot;,&quot;state&quot;:&quot;Rjazanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ROS&quot;,&quot;state&quot;:&quot;Rostovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAK&quot;,&quot;state&quot;:&quot;Sahalinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAM&quot;,&quot;state&quot;:&quot;Samarskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Sankt-Peterburg&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saratovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SMO&quot;,&quot;state&quot;:&quot;Smolenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;STA&quot;,&quot;state&quot;:&quot;Stavropol'skij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SVE&quot;,&quot;state&quot;:&quot;Sverdlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TAM&quot;,&quot;state&quot;:&quot;Tambovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TYU&quot;,&quot;state&quot;:&quot;Tjumenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TOM&quot;,&quot;state&quot;:&quot;Tomskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TUL&quot;,&quot;state&quot;:&quot;Tul'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TVE&quot;,&quot;state&quot;:&quot;Tverskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udmurtskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ULY&quot;,&quot;state&quot;:&quot;Ul'janovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLA&quot;,&quot;state&quot;:&quot;Vladimirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VGG&quot;,&quot;state&quot;:&quot;Volgogradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLG&quot;,&quot;state&quot;:&quot;Vologodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VOR&quot;,&quot;state&quot;:&quot;Voronezhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ZAB&quot;,&quot;state&quot;:&quot;Zabaykal'skiy kraj&quot;}],&quot;US&quot;:[{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alabama&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AK&quot;,&quot;state&quot;:&quot;Alaska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AZ&quot;,&quot;state&quot;:&quot;Arizona&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arkansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;California&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Colorado&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Connecticut&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DE&quot;,&quot;state&quot;:&quot;Delaware&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DC&quot;,&quot;state&quot;:&quot;District of Columbia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Florida&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GA&quot;,&quot;state&quot;:&quot;Georgia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guam&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;HI&quot;,&quot;state&quot;:&quot;Hawaii&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ID&quot;,&quot;state&quot;:&quot;Idaho&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;Illinois&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Indiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IA&quot;,&quot;state&quot;:&quot;Iowa&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KS&quot;,&quot;state&quot;:&quot;Kansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KY&quot;,&quot;state&quot;:&quot;Kentucky&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;LA&quot;,&quot;state&quot;:&quot;Louisiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Maine&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MD&quot;,&quot;state&quot;:&quot;Maryland&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;Massachusetts&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Michigan&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Minnesota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Mississippi&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Missouri&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Montana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Nebraska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NV&quot;,&quot;state&quot;:&quot;Nevada&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;New Hampshire&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NJ&quot;,&quot;state&quot;:&quot;New Jersey&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NM&quot;,&quot;state&quot;:&quot;New Mexico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NY&quot;,&quot;state&quot;:&quot;New York&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NC&quot;,&quot;state&quot;:&quot;North Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ND&quot;,&quot;state&quot;:&quot;North Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MP&quot;,&quot;state&quot;:&quot;Northern Mariana Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OH&quot;,&quot;state&quot;:&quot;Ohio&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OK&quot;,&quot;state&quot;:&quot;Oklahoma&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oregon&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Pennsylvania&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Puerto Rico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rhode Island&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SC&quot;,&quot;state&quot;:&quot;South Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SD&quot;,&quot;state&quot;:&quot;South Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Tennessee&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TX&quot;,&quot;state&quot;:&quot;Texas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utah&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Vermont&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Virgin Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Washington&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WV&quot;,&quot;state&quot;:&quot;West Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WI&quot;,&quot;state&quot;:&quot;Wisconsin&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WY&quot;,&quot;state&quot;:&quot;Wyoming&quot;}]},

// [filosof]
        countries_with_codes: {&quot;RO&quot;:&quot;RO&quot;}
// [/filosof]
    });

    
    $.ceFormValidator('setZipcode', {
        US: {
            regexp: /^(\d{5})(-\d{4})?$/,
            format: '01342 (01342-5678)'
        },
        CA: {
            regexp: /^(\w{3} ?\w{3})$/,
            format: 'V1A OB1 (V1AOB1)'
        },
        RU: {
            regexp: /^(\d{6})?$/,
            format: '123456'
        }
    });
    

}(Tygh, Tygh.$));
//]]>

    




    
                
                
                


 
     Select



    

               
            ,  
        {user_name}({email})
        

       
    
    
    

                        
                    
                
            
                
            Purchase Date
            
                    
    
    

    
    
    



    

    .ui-timepicker-div .ui-widget-header { margin-bottom: 8px; }
    .ui-timepicker-div dl { text-align: left; }
    .ui-timepicker-div dl dt { float: left; clear:left; padding: 0 0 0 5px; }
    .ui-timepicker-div dl dd { margin: 0 10px 10px 40%; }
    .ui-timepicker-div td { font-size: 90%; }
    .ui-tpicker-grid-label { background: none; border: none; margin: 0; padding: 0; }
    .ui-timepicker-div .ui_tpicker_unit_hide{ display: none; }

    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input { background: none; color: inherit; border: none; outline: none; border-bottom: solid 1px #555; width: 95%; }
    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input:focus { border-bottom-color: #aaa; }

    .ui-timepicker-rtl{ direction: rtl; }
    .ui-timepicker-rtl dl { text-align: right; padding: 0 5px 0 0; }
    .ui-timepicker-rtl dl dt{ float: right; clear: right; }
    .ui-timepicker-rtl dl dd { margin: 0 40% 10px 10px; }

    /* Shortened version style */
    .ui-timepicker-div.ui-timepicker-oneLine { padding-right: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time,
    .ui-timepicker-div.ui-timepicker-oneLine dt { display: none; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time_label { display: block; padding-top: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine dl { text-align: right; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd > div { display:inline-block; margin:0; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_minute:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_second:before { content:':'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_millisec:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_microsec:before { content:'.'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide,
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide:before{ display: none; }




//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
        // Keep variable name 'calendar_config' and its scope (global) for correct cloning with settings
        // (see js/tygh/node_cloning.js)
        calendar_config = {
            changeMonth: true,
            duration: 'fast',
            changeYear: true,
            numberOfMonths: 1,
            selectOtherMonths: true,
            showOtherMonths: true,
                        maxDate:'+0D',            firstDay: 1,
            dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            yearRange: '2015:2023',
            dateFormat: 'dd/mm/yy'
        };
        if ($('#select_component_register_purchase_date_0').hasClass('cm-datetimepicker')) {
            $('#select_component_register_purchase_date_0').datetimepicker(
                calendar_config
            ).attr('readonly', 'readonly');
        } else {
            $('#select_component_register_purchase_date_0').datepicker(
                calendar_config
            ).attr('readonly', 'readonly');
        }
    });
}(Tygh, Tygh.$));
//]]>


            
        

            

    
        Promotion
        
            
                
                    Promotional Code
                
                
                    

                    
                    Valid code and display bonuses

                    
                    
                    
                
            
            or
            
                Select Promotion Name
                
                        


 
     Select Promotion



                
            

            
	            
	                
	                    Campaign Name
	                
	                
				
				 
				
					
	                    Code status
	                
					
				
                
                    Bonuses
                
                
            

            Validate Promotion
        
    
    
	    
	        Payment Informations
	        
	            
	                Sale price (Discount included)
	            
	            
			
			
            	
	                Product bonuses
	            
	            
	        
	    
	



    
            


 
    



        Reset
    


            
            
                
                    Where to find the code?
                    
                
            
        
        
            or
                


 
     Search devices
    


        
    

                                                                
    Find issued device
    
                                                                
                                    
        
        Find issued device
            

            
        



//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
                    });
}(Tygh, Tygh.$));
//]]>

    

    
                    
            



//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
                    });
}(Tygh, Tygh.$));
//]]>

            
            
            
                    
    

                


    Follow-up
    Do you want to add a follow-up?
    
                        
            
                Yes
                No
            
        
        
        	
	        
	        	
	        		Due date
	        	
	            
	                	                    	                	                    
    
    

    
    
    



    

    .ui-timepicker-div .ui-widget-header { margin-bottom: 8px; }
    .ui-timepicker-div dl { text-align: left; }
    .ui-timepicker-div dl dt { float: left; clear:left; padding: 0 0 0 5px; }
    .ui-timepicker-div dl dd { margin: 0 10px 10px 40%; }
    .ui-timepicker-div td { font-size: 90%; }
    .ui-tpicker-grid-label { background: none; border: none; margin: 0; padding: 0; }
    .ui-timepicker-div .ui_tpicker_unit_hide{ display: none; }

    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input { background: none; color: inherit; border: none; outline: none; border-bottom: solid 1px #555; width: 95%; }
    .ui-timepicker-div .ui_tpicker_time .ui_tpicker_time_input:focus { border-bottom-color: #aaa; }

    .ui-timepicker-rtl{ direction: rtl; }
    .ui-timepicker-rtl dl { text-align: right; padding: 0 5px 0 0; }
    .ui-timepicker-rtl dl dt{ float: right; clear: right; }
    .ui-timepicker-rtl dl dd { margin: 0 40% 10px 10px; }

    /* Shortened version style */
    .ui-timepicker-div.ui-timepicker-oneLine { padding-right: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time,
    .ui-timepicker-div.ui-timepicker-oneLine dt { display: none; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_time_label { display: block; padding-top: 2px; }
    .ui-timepicker-div.ui-timepicker-oneLine dl { text-align: right; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd > div { display:inline-block; margin:0; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_minute:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_second:before { content:':'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_millisec:before,
    .ui-timepicker-div.ui-timepicker-oneLine dl dd.ui_tpicker_microsec:before { content:'.'; display:inline-block; }
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide,
    .ui-timepicker-div.ui-timepicker-oneLine .ui_tpicker_unit_hide:before{ display: none; }




//&lt;![CDATA[
(function(_, $) {
    $(document).ready(function() {
        // Keep variable name 'calendar_config' and its scope (global) for correct cloning with settings
        // (see js/tygh/node_cloning.js)
        calendar_config = {
            changeMonth: true,
            duration: 'fast',
            changeYear: true,
            numberOfMonths: 1,
            selectOtherMonths: true,
            showOtherMonths: true,
                                    firstDay: 1,
            dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            yearRange: '2015:2023',
            dateFormat: 'dd/mm/yy'
        };
        if ($('#elm_date_avail_holder_0').hasClass('cm-datetimepicker')) {
            $('#elm_date_avail_holder_0').datetimepicker(
                calendar_config
            );
        } else {
            $('#elm_date_avail_holder_0').datepicker(
                calendar_config
            );
        }
    });
}(Tygh, Tygh.$));
//]]>


	            
	            
	                
	                    
	                        	                        	                            00
	                        	                            01
	                        	                            02
	                        	                            03
	                        	                            04
	                        	                            05
	                        	                            06
	                        	                            07
	                        	                            08
	                        	                            09
	                        	                            10
	                        	                            11
	                        	                            12
	                        	                            13
	                        	                            14
	                        	                            15
	                        	                            16
	                        	                            17
	                        	                            18
	                        	                            19
	                        	                            20
	                        	                            21
	                        	                            22
	                        	                            23
	                        	                     : 
	                    
	                        	                        	                            00
	                        	                            01
	                        	                            02
	                        	                            03
	                        	                            04
	                        	                            05
	                        	                            06
	                        	                            07
	                        	                            08
	                        	                            09
	                        	                            10
	                        	                            11
	                        	                            12
	                        	                            13
	                        	                            14
	                        	                            15
	                        	                            16
	                        	                            17
	                        	                            18
	                        	                            19
	                        	                            20
	                        	                            21
	                        	                            22
	                        	                            23
	                        	                            24
	                        	                            25
	                        	                            26
	                        	                            27
	                        	                            28
	                        	                            29
	                        	                            30
	                        	                            31
	                        	                            32
	                        	                            33
	                        	                            34
	                        	                            35
	                        	                            36
	                        	                            37
	                        	                            38
	                        	                            39
	                        	                            40
	                        	                            41
	                        	                            42
	                        	                            43
	                        	                            44
	                        	                            45
	                        	                            46
	                        	                            47
	                        	                            48
	                        	                            49
	                        	                            50
	                        	                            51
	                        	                            52
	                        	                            53
	                        	                            54
	                        	                            55
	                        	                            56
	                        	                            57
	                        	                            58
	                        	                            59
	                        	                    
	                
	            
	        
	        
        		
        			Assigned to
        		
        		
        			
        				Select
        				        					
        						Adelina Chiru
        					
        				        					
        						adrien callcenter
        					
        				        					
        						Alena Osochenko
        					
        				        					
        						Alexandra Apostu
        					
        				        					
        						Alexandru Tone
        					
        				        					
        						Alexandru Jianu
        					
        				        					
        						Alexey Kolosha
        					
        				        					
        						Alina Balan
        					
        				        					
        						Ana-Maria Stan
        					
        				        					
        						Anastasia Test
        					
        				        					
        						Andreea Popescu
        					
        				        					
        						Arseniy Sinev
        					
        				        					
        						Aucra Callcenter
        					
        				        					
        						Automated Testing
        					
        				        					
        						Barca Nicolas
        					
        				        					
        						Bianca Pavelescu
        					
        				        					
        						Call Center
        					
        				        					
        						Call Center
        					
        				        					
        						Call Center
        					
        				        					
        						Call Center
        					
        				        					
        						Call Center
        					
        				        					
        						Call Center Supervisor
        					
        				        					
        						Call Center Test
        					
        				        					
        						callcenter user1
        					
        				        					
        						Call_01 Agent_01
        					
        				        					
        						Call_02 Agent_02
        					
        				        					
        						Call_04 Agent_04
        					
        				        					
        						Call_05 Agent_05
        					
        				        					
        						Call_06 Agent_06
        					
        				        					
        						Call_07 Agent_07
        					
        				        					
        						Call_08 Agent_08
        					
        				        					
        						Call_09 Agent_09
        					
        				        					
        						Call_11 Agent_11
        					
        				        					
        						Call_12 Agent_12
        					
        				        					
        						Call_13 Agent_13
        					
        				        					
        						Call_14 Agent_14
        					
        				        					
        						Call_15 Agent_15
        					
        				        					
        						Call_16 Agent_16
        					
        				        					
        						Call_17 Agent_17
        					
        				        					
        						Call_18 Agent_18
        					
        				        					
        						Call_19 Agent_19
        					
        				        					
        						Call_20 Agent_20
        					
        				        					
        						Call_21 Agent_21
        					
        				        					
        						Call_22 Agent_22
        					
        				        					
        						Call_22 Agent_22
        					
        				        					
        						Call_24 Agent_24
        					
        				        					
        						Call_25 Agent_25
        					
        				        					
        						Call_26 Agent_26
        					
        				        					
        						Call_27 Agent_27
        					
        				        					
        						Call_28 Agent_28
        					
        				        					
        						Call_29 Agent_29
        					
        				        					
        						Call_30 Agent_30
        					
        				        					
        						Call_31 Agent_31
        					
        				        					
        						Call_32 Agent_32
        					
        				        					
        						Calota Mihai
        					
        				        					
        						Catalina` Pop
        					
        				        					
        						Christina Chrysomallidou
        					
        				        					
        						Ciprian Gabor
        					
        				        					
        						Ciprian gabor
        					
        				        					
        						Cosmin Marin
        					
        				        					
        						Cosmin Marin
        					
        				        					
        						Cosmin Stan
        					
        				        					
        						Cosmin Marin
        					
        				        					
        						Cristian Zloteanu
        					
        				        					
        						Dan Anastasiu
        					
        				        					
        						Delia Tudor
        					
        				        					
        						Devin Pratama
        					
        				        					
        						Dragos Serban
        					
        				        					
        						Dragos Serban
        					
        				        					
        						Dragos Serban
        					
        				        					
        						Fabrizio Scamuffa
        					
        				        					
        						Florin Sandor
        					
        				        					
        						Iahim Atolac
        					
        				        					
        						Inspector Inspector
        					
        				        					
        						Ioana Miroiu
        					
        				        					
        						Ionut Anechitei
        					
        				        					
        						Ionut Avram
        					
        				        					
        						Iqoach Support
        					
        				        					
        						Irina Zaharescu
        					
        				        					
        						Ivan Suntesic
        					
        				        					
        						Jim Li
        					
        				        					
        						Konstantin Mikheev
        					
        				        					
        						Konstantin Lisin
        					
        				        					
        						Leonid Chuhin
        					
        				        					
        						Livia Call Center
        					
        				        					
        						Livia Neca
        					
        				        					
        						Luis Cruz
        					
        				        					
        						Madalina Ignat
        					
        				        					
        						Maksim Victorov
        					
        				        					
        						Mihai calota
        					
        				        					
        						Mircea Grecescu
        					
        				        					
        						Mircea Teju
        					
        				        					
        						Oana Galbenu
        					
        				        					
        						Octavian Grigore
        					
        				        					
        						Oleg Bidzan
        					
        				        					
        						Pedro Ramos
        					
        				        					
        						Pedro Ramos
        					
        				        					
        						rab admin
        					
        				        					
        						Raluca Lazar
        					
        				        					
        						Ramil Gilaev
        					
        				        					
        						Ria Pearson
        					
        				        					
        						Robert Reiter
        					
        				        					
        						Robert Newman
        					
        				        					
        						Ruxandra Pahontu
        					
        				        					
        						SEA SEA
        					
        				        					
        						Sergei Kuzmin
        					
        				        					
        						Stefan Panaite
        					
        				        					
        						test comparativ
        					
        				        					
        						Test Test
        					
        				        					
        						Test CC
        					
        				        					
        						Test Pass
        					
        				        					
        						Ursu Cristian
        					
        				        					
        						Vlad Voinea
        					
        				        			
        		
        	
	        
	            Comment
	            
	                
	            
	        
	        
	        	Add Task
	        	Clone task
	        	    


 
     Remove task
    


	        
	    
        
                


 
    




			        
        
                


 
    



                


 
    



        
    

    
    //&lt;![CDATA[
    (function(_, $) {
                    $.ceEvent('on', 'ce.formajaxpost_case_follow_up_0', function(data) {
                if (data.follow_up) {
                    if (data.proceed_trade_in) {
                        $.ceAjax('request', fn_url('case_management.pick_trade_in_product'), {
                            method: 'post',
                            result_ids: 'pick_trade_in_product',
                            callback: function (data) {
                                $('#pick_trade_in_product').show();
                                $.scrollToElm($('#pick_trade_in_product'));
                            }
                        });
                    } else if (data.edit_trade_in_order) {
                        $.ceAjax('request', fn_url('case_management.edit_trade_in_order'), {
                            method: 'get',
                            result_ids: 'edit_trade_in_order_content',
                            callback: function (data) {
                                $('#edit_trade_in_order').show();
                                $.scrollToElm($('#edit_trade_in_order'));
                            }
                        });
                    } else if (data.care_plus_switch) {
                        $.ceAjax('request', fn_url('case_management.replacement_procedure'), {
                            method: 'post',
                            result_ids: 'sd_block_replace_device',
                            callback: function (data) {
                                $('#sd_block_replace_device').show();
                                $.scrollToElm($('#sd_block_replace_device'));
                            }
                        });
                    } else {
                        $('#other_issue_0').show();
                        $.scrollToElm($('#other_issue_0'));
                    }
                    $('#onep-follow_up_off__0__buttons').hide();
                    $('#onep-follow_up_on__0__buttons').hide();
                    $('.onep-update-issue_0').hide();
                    $('.onep-issue_0 input').prop('disabled', 'disabled');
                    $('.onep-issue_0 textarea').prop('disabled', 'disabled');
                    $('.onep-issue_0 select').prop('disabled', 'disabled');
                    $('.onep-issue_0 a.dropdown-toggle').removeAttr('data-toggle');
                    $('#content_home_delivery_0 .buttons-container').hide();
                    $('#nav_follow_0 input').prop('disabled', 'disabled');
                    $('#nav_follow_0 textarea').prop('disabled', 'disabled');
                    $('#nav_follow_0 select').prop('disabled', 'disabled');
                    $('.followup-task-multiple-buttons-_0').hide();

                    $(&quot;.sentiment_popup&quot;).find('span, a.set').addClass('hidden');

                    $.fn.sd_cmop_update_menu();
                }
            });

            $('#nav_follow_0 .followup-task-radio-input').on('change', function(){
                if ($(this).val() == 'Y') {
                    $('#nav_follow_0 .followup-task').show();
                    $('#onep-follow_up_off__0__buttons').hide();
                    $('#onep-follow_up_on__0__buttons').show();
                } else {
                    $('#nav_follow_0 .followup-task').hide();
                    $('#onep-follow_up_on__0__buttons').hide();
                    $('#onep-follow_up_off__0__buttons').show();
                }
            });

            $(document).on('click', '.onep-add-task', function() {
				var task_limit = $(this).attr('data-limit-follow-up-tasks');

				if ($('.followup-task-box_0').length &lt; task_limit) {
					Tygh.$('#box_' + $(this).attr('id')).cloneNode(1);
				}
			});

            $(document).on('click', '.onep-clone-task', function() {
				var task_limit = $(this).attr('data-limit-follow-up-tasks');

				if ($('.followup-task-box_0').length &lt; task_limit) {
					Tygh.$('#box_' + $(this).attr('id')).cloneNode(1, true);
				}
			});
            }(Tygh, Tygh.$));
    //]]>
    


        

    
    

    
        
            
                ATTENTION: Please provide justification.
            
            
                This replacement is not covered by PMI's standard replacement policy and will be considered a GOODWILL (exceptional replacement)
                
                    
                    Justification  *
                    
                
                
                    Issuer:
                    
                        --
                    
                    
                
                
                    
                    Confirm exception
                
            
            
                
                        


 
    



                        


 
    



                
            
        
    



    (function(_, $) {
        $(document).ready(function() {
            var _accept       = $(&quot;#justification_accept_0&quot;),
                _confirm      = $(&quot;#justification_confirm_0&quot;),
                _cancel       = $(&quot;#justification_cancel_0&quot;),
                _descr        = $(&quot;#justification_descr_0&quot;),
                _block_issuer = $('#justification_issuer_block_0'),
                _issuer_id    = $('#justification_issuer_id_0'),
                _issuer_data  = $('#justification_issuer_data_0'),
                _popup        = $(&quot;#nav_justification_popup_0&quot;),
                _notice       = '&lt;span id=&quot;justification_descr_error_message&quot; class=&quot;help-inline&quot;>';
                _notice      += '&lt;p class=&quot;form-input-hint&quot;>The &lt;b>Justification&lt;/b> field must contains at least ≥ 3 characters&lt;/p>&lt;/span>';

            if (typeof _block_issuer !== &quot;undefined&quot;) {
                _block_issuer.hide();
            }
            if (typeof _issuer_id !== &quot;undefined&quot; &amp;&amp; typeof _issuer_data !== &quot;undefined&quot;) {
                _issuer_id.change(function() {
                    _issuer_data.val($(this).find(&quot;option:selected&quot;).text());
                });
            }

            function fn_form_ajax_popup_justification_change(data) {
                if (typeof data.backend_users_data !== &quot;undefined&quot;
                    &amp;&amp; typeof _issuer_id !== &quot;undefined&quot;
                    &amp;&amp; typeof _block_issuer !== &quot;undefined&quot;
                ) {
                    _block_issuer.show();
                    $.each(data.backend_users_data, function(key, value) {
                        $.each(value, function(name, surname) {
                            _issuer_id.append(&quot;&lt;option value=&quot;+key+&quot;>&quot;+name+' '+surname+&quot;&lt;/option>&quot;);
                        });
                    });
                }
                if (data.create_issue &amp;&amp; data.justification_popup) {
                    $(&quot;#onep-update-issue_0__buttons&quot;).children().hide();
                    _popup.show();
                    $.scrollToElm(_popup);
                }
            }

            $.ceEvent(&quot;on&quot;, &quot;ce.formajaxpost_create_issue_0&quot;, function(data) {
                fn_form_ajax_popup_justification_change(data);
            });
            $.ceEvent(&quot;on&quot;, &quot;ce.formajaxpost_skip_diagnosticcreate_issue_0&quot;, function(data) {
                fn_form_ajax_popup_justification_change(data);
            });

            _accept.click(function() {
                if (_accept.is(&quot;:checked&quot;)) {
                    _confirm.removeAttr(&quot;disabled&quot;);
                } else {
                    _confirm.attr(&quot;disabled&quot;,&quot;disabled&quot;);
                }
            });
            _cancel.click(function() {
                _popup.hide();
                if ($(&quot;input[name='issue_data[need_replace]']&quot;).is(&quot;:checked&quot;)) {
                    $(&quot;input[name='issue_data[need_replace]']&quot;).prop(&quot;checked&quot;, false);
                }
                if ($(&quot;input[name='issue_data[replacement_at_store]']&quot;).is(&quot;:checked&quot;)) {
                    $(&quot;input[name='issue_data[replacement_at_store]']&quot;).prop(&quot;checked&quot;, false);
                }
                if ($(&quot;input[name='issue_data[need_to_pickup_at_pos]']&quot;).is(&quot;:checked&quot;)) {
                    $(&quot;input[name='issue_data[need_to_pickup_at_pos]']&quot;).prop(&quot;checked&quot;, false);
                }

                if ($('#onep-update-issue_0__buttons').is(&quot;:visible&quot;)) {
                    $('#onep-update-issue_0__buttons').hide();
                }
                if ($(&quot;#skip_diagnosticonep-update-issue_0__buttons&quot;).is(&quot;:visible&quot;)) {
                    $(&quot;#skip_diagnosticonep-update-issue_0__buttons&quot;).children().hide();
                }

                $(&quot;#onep-update-issue_0__buttons&quot;).hide();
                $(&quot;#onep-issue_0__buttons&quot;).show();
            });
            _confirm.click(function() {
                if (_descr.val().trim().length &lt; 3) {
                    if (!_descr.hasClass(&quot;failed-field&quot;)) {
                        _descr.parent().append(_notice);
                        _descr.addClass(&quot;failed-field&quot;);
                    }
                    event.preventDefault();
                }
            });

            $.ceEvent(&quot;on&quot;, &quot;ce.formajaxpost_care_plus_justification_0&quot;, function(data) {
                if (data.follow_up) {
                    _popup.hide();
                    $(&quot;#nav_follow_0&quot;).show();
                    $.fn.sd_cmop_update_menu();
                    $.scrollToElm($(&quot;#nav_follow_0&quot;));
                }
                if (data.pickup_at_pos_email) {
                    _popup.hide();
                    $(&quot;#nav_pickup_at_pos_email_0&quot;).show();
                    $.fn.sd_cmop_update_menu();
                    $.scrollToElm($(&quot;#nav_pickup_at_pos_email_0&quot;));
                }
            });
        });
    }(Tygh, Tygh.$));


    
    
    
    



                            
            
            
    

    
    
        Kit for Kit
        the full kit needs to be returned, a second issue has been automatically created for the order functionning device, you can still edit the issue or delete if the functionning device shouldn't be returned
        
            
                
                    


 
    



                                            
        
    
    
        //&lt;![CDATA[
        (function(_, $) {
            $.ceEvent('on', 'ce.formajaxpost_kit_for_kit', function(data) {
                var block_replace = $('#sd_block_replace_device');
                if ((typeof data.create_second_issue !== &quot;undefined&quot; &amp;&amp; data.create_second_issue)
                    || (typeof data.delete_second_issue !== &quot;undefined&quot; &amp;&amp; data.delete_second_issue)
                    &amp;&amp; block_replace.length
                ) {
                    $.ceAjax('request', fn_url('case_management.replacement_procedure'), {
                        method: 'post',
                        result_ids: 'sd_block_replace_device',
                        callback: function (data) {
                            block_replace.show();
                            $.scrollToElm(block_replace);
                        }
                    });
                }
                if ((typeof data.active !== &quot;undefined&quot; &amp;&amp; data.active)
                    &amp;&amp; $(&quot;form[name*='create_issue']&quot;).find('input:checkbox').parent().parent().length
                ) {
                    $(&quot;form[name*='create_issue']&quot;).find('input:checkbox').parent().parent().hide();
                }
                $(&quot;form[name=kit_for_kit] :input&quot;).prop(&quot;disabled&quot;, true);
                $.scrollToElm($('input[name=&quot;dispatch[case_management.replacement_procedure.create_second_issue]&quot;]'));
            });
            $.ceEvent('on', 'ce.formajaxpost_pick_product', function(data) {
                var block_kit_for_kit = $('#kit_for_kit');
                if (typeof data.kit_for_kit !== &quot;undefined&quot; &amp;&amp; data.kit_for_kit
                 &amp;&amp; block_kit_for_kit.length
                ) {
                    block_kit_for_kit.show();
                    $.scrollToElm(block_kit_for_kit);
                    $.fn.sd_cmop_update_menu();
                }
            });
            $.ceEvent('on', 'ce.formpre_pick_product', function(frm, elm) {
                var replacement_product = $(frm).find('select[name*=&quot;replacement_product&quot;]');
                if (replacement_product.length) {
                    var product_description = replacement_product.find(&quot;:selected&quot;).text();
                    if (typeof product_description !== &quot;undefined&quot; &amp;&amp; product_description) {
                        var product_code = product_description.trim().split(&quot; &quot;).shift();
                        if (typeof product_code !== &quot;undefined&quot; &amp;&amp; product_code) {
                            $(frm).append('&lt;input type=&quot;hidden&quot; name=&quot;product_code&quot; value=&quot;'+product_code+'&quot; />');
                        }
                    }
                }
            });
        }(Tygh, Tygh.$));
        //]]>
    




    
            
    
    
    
    
        
    
        Case status:
        
            
                Opened
                Closed
            
        
    

        


 
    





    //&lt;![CDATA[
    (function(_, $) {
        $('#change_status_button').click(function() {
            $('#case_status').after('&lt;input type=&quot;hidden&quot; name=&quot;case_status&quot; value=&quot;'+$('#case_status option:selected').attr(&quot;value&quot;)+'&quot; />');
            $('#case_status').replaceWith($('#case_status option:selected').text());
            $('#change_status_button').hide();
        });

        $.ceEvent('on', 'ce.formajaxpost_change_status', function(data) {
            $('#change_status_button').hide();
            $('#nav_other_case').show();
            $.scrollToElm($('#nav_other_case'));
            $('#sd_case_management_replace_tabs li').removeClass('cm-js');
            $.fn.sd_cmop_update_menu();
        });
    }(Tygh, Tygh.$));
    //]]>

        
    
        
                


 
     Go to search screen
    


                


 
     Go to dashboard
    


        
    


            

    
    





    var ajax_callback_data = menu_content;




                
            

            
                Contact us|© 2021 iQOS  
            
            


        
        
    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main_column&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='main_column']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[1]/following::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]</value>
   </webElementXpaths>
</WebElementEntity>
