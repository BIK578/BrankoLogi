<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_E-MAIL                                 _23f3bf</name>
   <tag></tag>
   <elementGuidId>aa86275b-2504-473b-a08d-cfc0ba4bfc14</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.column.col-5.col-md-12.ggt-01</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='step-01']/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>column col-5 col-md-12 ggt-01</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                




    
                                    
                    E-MAIL *
                                            
                    
                                            
                                                        
                        
	
        //&lt;![CDATA[
            Tygh.tr(&quot;email_providers_ajax.waiting_text&quot;, &quot;În așteptarea ca serverul să valideze mesajele e-mail, așteptați&quot;);
            Tygh.tr(&quot;email_providers_ajax.blacklisted_email_error&quot;, &quot;Nu îți poți crea un cont cu această adresă de e-mail. Te rugăm să introduci alta.&quot;);
            Tygh.tr(&quot;email_providers_ajax.url&quot;, &quot;https://preprod.iqos.ro/index.php?dispatch=email_providers_ajax.validate_email&quot;);
        //]]>
	
    


			
	    

                                            
                    PAROLA TA *
                    
                                            
                        



    $(document).ready(function () {
        $('#show-hide-btn-3').on('click', function () {
            var password = $('#password1');
            if (password.attr('type') === 'password') {
                password.attr('type', 'text');
                $(this).html('&lt;div class=\&quot;hide-password\&quot;>\r\n&lt;img src=\&quot;https://d3hvodq7wnhe8p.cloudfront.net/images/email_templates/password/hide_(1)-svg.svg\&quot;/ style=\&quot;width: 27px; height: 21px;\&quot;> \r\n&lt;\/div>\r\n');
            } else {
                password.attr('type', 'password');
                $(this).html('&lt;div class=\&quot;show-password\&quot;>\r\n&lt;img src=\&quot;https://d3hvodq7wnhe8p.cloudfront.net/images/email_templates/password/eye-svg.svg\&quot;/ style=\&quot;width: 27px; height: 21px;\&quot;>\r\n&lt;\/div>');
            }
            password.focus();
        });
    });



    $(document).ready(function () {
        $('#password1').focus(function() {
            $('#pass_info').show();
        }).blur(function() {
            $('#pass_info').hide();
        });
    });


                                                                                            
                                Parola dumneavoastra trebuie sa contina minim 8 caractere.
            Deasemenea trebuie sa includa minim 2 din urmatoarele caracteristici:
            
                o litera mare
                o litera mica
                un numar
                un caracter special (e.g. % $ € *)
            
        
                            
                                                            

                
                    REINTRODUCERE PAROLĂ *
                    
                                            
                        



    $(document).ready(function () {
        $('#show-hide-btn-4').on('click', function () {
            var password = $('#password2');
            if (password.attr('type') === 'password') {
                password.attr('type', 'text');
                $(this).html('&lt;div class=\&quot;hide-password\&quot;>\r\n&lt;img src=\&quot;https://d3hvodq7wnhe8p.cloudfront.net/images/email_templates/password/hide_(1)-svg.svg\&quot;/ style=\&quot;width: 27px; height: 21px;\&quot;> \r\n&lt;\/div>\r\n');
            } else {
                password.attr('type', 'password');
                $(this).html('&lt;div class=\&quot;show-password\&quot;>\r\n&lt;img src=\&quot;https://d3hvodq7wnhe8p.cloudfront.net/images/email_templates/password/eye-svg.svg\&quot;/ style=\&quot;width: 27px; height: 21px;\&quot;>\r\n&lt;\/div>');
            }
            password.focus();
        });
    });



    $(document).ready(function () {
        $('#password1').focus(function() {
            $('#pass_info').show();
        }).blur(function() {
            $('#pass_info').hide();
        });
    });


                                                                
                                    
                        
    


    



                            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;step-01&quot;)/div[@class=&quot;step-inner&quot;]/div[@class=&quot;columns col-gapless&quot;]/div[@class=&quot;column col-5 col-md-12 ggt-01&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='step-01']/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Terms &amp; Conditions'])[1]/following::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EMAIL ȘI PAROLĂ'])[1]/following::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
