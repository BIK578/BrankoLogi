<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_--                                  _3ae841</name>
   <tag></tag>
   <elementGuidId>649856f7-bb81-4cbb-ad0d-9641d079cf3d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='inquiry_response_type_0']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#inquiry_response_type_0</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>issue_data[response_type_id]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>inquiry_response_type_0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                            --
                                                                                    QE - Error Anonymous QURE result
                                                                                    AQ - Success Anonymous QURE result
                                                                                    FRA - Fraud attempt
                                                                                    TR - Trade In offer
                                                                                    VB - Verbal
                                                                                    CH - Live Chat
                                                                                    EM - Email
                                                                                    FK - Facebook
                                                                                    TW - Twitter
                                                                                    SM - SMS
                                                                                    NR - No Response
                                                                                    IP - In Person
                                                                                    CR - Call Center to handle
                                                                                    RA - Replacement done via Contact Service Center - Agent
                                                                                    RF - Replacement done via Flagship Store
                                                                                    RS - Replacement Service Points
                                                                                    RW - Replacement Denied (warranty expired)
                                                                                    RO - Replacement Denied (out of stock)
                                                                                    RI - Replacement not possible
                                                                                    BF - Callback - Follow up
                                                                                    BV - Callback - Voicemail
                                                                                    BO - Callback - OOO Hours
                                                                                    BA - Callback - Abandoners
                                                                                                            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;inquiry_response_type_0&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='inquiry_response_type_0']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='inquiry_issue_0']/div/form/table/tbody/tr/td[2]/div[2]/div/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Response Type'])[1]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Type'])[1]/following::select[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CC Priority'])[1]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sprinklr ID'])[1]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/select</value>
   </webElementXpaths>
</WebElementEntity>
