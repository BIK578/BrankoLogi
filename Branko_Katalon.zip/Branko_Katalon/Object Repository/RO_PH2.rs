<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>RO_PH2</name>
   <tag></tag>
   <elementGuidId>3d27f81d-27f1-4c46-af9a-82158549ace2</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
