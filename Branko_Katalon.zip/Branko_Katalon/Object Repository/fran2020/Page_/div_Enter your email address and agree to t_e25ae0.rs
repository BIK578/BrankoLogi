<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Enter your email address and agree to t_e25ae0</name>
   <tag></tag>
   <elementGuidId>96df5701-0616-4afd-81e7-d8c30126bb84</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='step-01']/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.columns</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>columns</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            Enter your email address and agree to the Terms &amp; Conditions to begin the process of setting up your IQOS account.
                                                            




    
                                    
                    
                        
                        
                            
                            
                                E-mail
                            
                            
                        
                    
                
                        
	
        //&lt;![CDATA[
            Tygh.tr(&quot;email_providers_ajax.waiting_text&quot;, &quot;În așteptarea ca serverul să valideze mesajele e-mail, așteptați&quot;);
            Tygh.tr(&quot;email_providers_ajax.blacklisted_email_error&quot;, &quot;Nu îți poți crea un cont cu această adresă de e-mail. Te rugăm să introduci alta.&quot;);
            Tygh.tr(&quot;email_providers_ajax.url&quot;, &quot;https://preprod.iqos.ro/index.php?dispatch=email_providers_ajax.validate_email&quot;);
        //]]>
	
    


			
	    

                                            
                    
                        
                        
                            
                            
                                Parola ta
                            
                            
                        
                    
                                                                        
                                
                                    
            
                ℗ An upper case letter
                ℗ A lower case letter
                ℗ A number
                ℗ A non-alphabetic character (e.g. % $ € *)
            
        
        
                                
                            

                            
                                $(document).ready(function () {
                                    $('#password1').focus(function() {
                                        $('#pass_info').addClass('show');
                                    }).blur(function() {
                                        $('#pass_info').removeClass('show');
                                    });
                                });
                            
                                                            

                
                    
                        
                        
                            
                            
                                Reintroducere parolă
                            
                            
                        
                    
                    Trebuie să conțină între 8 și 20 de caractere, dintre care cel puțin o cifră.
                
                        
    


    



                                                                                    

                        
                            Enter your email address and agree to the Terms &amp; Conditions to begin the process of setting up your IQOS account.
                                                                                                                                                                




                
        
                                                                            
                                            
                            
                            
                            
                            * Am citit și înțeles  Notificarea de protecție a datelor cu caracter personal. 
                        
                                    
                
                        
                                
            
                            
                    
                    
                    
                    
                    Nu vreau să ratez ofertele (reduceri, ediții limitate, noutăți despre produse ș.a.) Philip Morris Trading S.R.L. și sunt de acord să primesc prin email sau SMS informații comerciale despre IQOS, HEETS sau alte produse/servicii conexe oferite de Philip Morris Trading S.R.L. sau de partenerii săi.
                
            
            
            
Please note, by unticking the marketing opt-in, you will lose your care plus membership and all related advantages.
        
    
            
        
    




                                                                                    
                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;step-01&quot;)/div[@class=&quot;step-inner&quot;]/div[1]/div[@class=&quot;columns&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='step-01']/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EMAIL ȘI PAROLĂ'])[1]/following::div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ÎNREGISTREAZĂ-TE'])[1]/following::div[9]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
