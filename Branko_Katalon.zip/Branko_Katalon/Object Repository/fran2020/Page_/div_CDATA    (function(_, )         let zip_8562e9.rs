<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_CDATA    (function(_, )         let zip_8562e9</name>
   <tag></tag>
   <elementGuidId>024fbe62-8e00-4ae9-b490-a85acd221bdf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='ÎNREGISTREAZĂ-TE'])[1]/following::div[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.span12.page-cols-wrapper.page-registration-rev</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>span12 page-cols-wrapper page-registration-rev</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
    //&lt;![CDATA[
    (function(_, $) {
        let zipCodeInitializer = function () {
            
            $.ceRebuildStates('init', {
                default_country: 'RO',
                states: {&quot;&quot;:[{&quot;country_code&quot;:&quot;&quot;,&quot;code&quot;:&quot;CONSTANTA&quot;,&quot;state&quot;:null}],&quot;AU&quot;:[{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;ACT&quot;,&quot;state&quot;:&quot;Australian Capital Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NSW&quot;,&quot;state&quot;:&quot;New South Wales&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northern Territory&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;QLD&quot;,&quot;state&quot;:&quot;Queensland&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;South Australia&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;TAS&quot;,&quot;state&quot;:&quot;Tasmania&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;VIC&quot;,&quot;state&quot;:&quot;Victoria&quot;},{&quot;country_code&quot;:&quot;AU&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Western Australia&quot;}],&quot;BG&quot;:[{&quot;country_code&quot;:&quot;BG&quot;,&quot;code&quot;:&quot;SF&quot;,&quot;state&quot;:&quot;Sofia&quot;}],&quot;CA&quot;:[{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Alberta&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;British Columbia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;MB&quot;,&quot;state&quot;:&quot;Manitoba&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;New Brunswick&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NL&quot;,&quot;state&quot;:&quot;Newfoundland and Labrador&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;Northwest Territories&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NS&quot;,&quot;state&quot;:&quot;Nova Scotia&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nunavut&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;ON&quot;,&quot;state&quot;:&quot;Ontario&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Prince Edward Island&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;QC&quot;,&quot;state&quot;:&quot;Quebec&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;SK&quot;,&quot;state&quot;:&quot;Saskatchewan&quot;},{&quot;country_code&quot;:&quot;CA&quot;,&quot;code&quot;:&quot;YT&quot;,&quot;state&quot;:&quot;Yukon&quot;}],&quot;CH&quot;:[{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Ext\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AI&quot;,&quot;state&quot;:&quot;Appenzell Rhodes-Int\u00e9rieures&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Argovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;B\u00e2le-Campagne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;B\u00e2le-Ville&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;BE&quot;,&quot;state&quot;:&quot;Berne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Fribourg&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gen\u00e8ve&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;Glaris&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grisons&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;JU&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucerne&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Neuch\u00e2tel&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;NW&quot;,&quot;state&quot;:&quot;Nidwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;OW&quot;,&quot;state&quot;:&quot;Obwald&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Saint-Gall&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SH&quot;,&quot;state&quot;:&quot;Schaffhouse&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SZ&quot;,&quot;state&quot;:&quot;Schwytz&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soleure&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TI&quot;,&quot;state&quot;:&quot;Tessin&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;TG&quot;,&quot;state&quot;:&quot;Thurgovie&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;UR&quot;,&quot;state&quot;:&quot;Uri&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Valais&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;VD&quot;,&quot;state&quot;:&quot;Vaud&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZG&quot;,&quot;state&quot;:&quot;Zoug&quot;},{&quot;country_code&quot;:&quot;CH&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zurich&quot;}],&quot;DE&quot;:[{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAW&quot;,&quot;state&quot;:&quot;Baden-W\u00fcrttemberg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BAY&quot;,&quot;state&quot;:&quot;Bayern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BER&quot;,&quot;state&quot;:&quot;Berlin&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRG&quot;,&quot;state&quot;:&quot;Branderburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;BRE&quot;,&quot;state&quot;:&quot;Bremen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HAM&quot;,&quot;state&quot;:&quot;Hamburg&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;HES&quot;,&quot;state&quot;:&quot;Hessen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;MEC&quot;,&quot;state&quot;:&quot;Mecklenburg-Vorpommern&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NDS&quot;,&quot;state&quot;:&quot;Niedersachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;NRW&quot;,&quot;state&quot;:&quot;Nordrhein-Westfalen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;RHE&quot;,&quot;state&quot;:&quot;Rheinland-Pfalz&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saarland&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAS&quot;,&quot;state&quot;:&quot;Sachsen&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SAC&quot;,&quot;state&quot;:&quot;Sachsen-Anhalt&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;SCN&quot;,&quot;state&quot;:&quot;Schleswig-Holstein&quot;},{&quot;country_code&quot;:&quot;DE&quot;,&quot;code&quot;:&quot;THE&quot;,&quot;state&quot;:&quot;Th\u00fcringen&quot;}],&quot;ES&quot;:[{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;C&quot;,&quot;state&quot;:&quot;A Coru\u00f1a&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;\u00c1lava&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;Albacete&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;A&quot;,&quot;state&quot;:&quot;Alicante&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Almer\u00eda&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;O&quot;,&quot;state&quot;:&quot;Asturias&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;\u00c1vila&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Badajoz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PM&quot;,&quot;state&quot;:&quot;Baleares&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;Barcelona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Burgos&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CC&quot;,&quot;state&quot;:&quot;C\u00e1ceres&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;C\u00e1diz&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;S&quot;,&quot;state&quot;:&quot;Cantabria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Castell\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Ceuta&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Ciudad Real&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;C\u00f3rdoba&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Cuenca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GI&quot;,&quot;state&quot;:&quot;Girona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Granada&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guadalajara&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Guip\u00fazcoa&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;H&quot;,&quot;state&quot;:&quot;Huelva&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;HU&quot;,&quot;state&quot;:&quot;Huesca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;J&quot;,&quot;state&quot;:&quot;Ja\u00e9n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;La Rioja&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;GC&quot;,&quot;state&quot;:&quot;Las Palmas&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Le\u00f3n&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;L&quot;,&quot;state&quot;:&quot;Lleida&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lugo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;M&quot;,&quot;state&quot;:&quot;Madrid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;M\u00e1laga&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ML&quot;,&quot;state&quot;:&quot;Melilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;MU&quot;,&quot;state&quot;:&quot;Murcia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Navarra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Ourense&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;P&quot;,&quot;state&quot;:&quot;Palencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Pontevedra&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salamanca&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TF&quot;,&quot;state&quot;:&quot;Santa Cruz de Tenerife&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SG&quot;,&quot;state&quot;:&quot;Segovia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Sevilla&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Soria&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;T&quot;,&quot;state&quot;:&quot;Tarragona&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teruel&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Toledo&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;V&quot;,&quot;state&quot;:&quot;Valencia&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Valladolid&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Vizcaya&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;ZA&quot;,&quot;state&quot;:&quot;Zamora&quot;},{&quot;country_code&quot;:&quot;ES&quot;,&quot;code&quot;:&quot;Z&quot;,&quot;state&quot;:&quot;Zaragoza&quot;}],&quot;FR&quot;:[{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;01&quot;,&quot;state&quot;:&quot;Ain&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;02&quot;,&quot;state&quot;:&quot;Aisne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;03&quot;,&quot;state&quot;:&quot;Allier&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;04&quot;,&quot;state&quot;:&quot;Alpes-de-Haute-Provence&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;06&quot;,&quot;state&quot;:&quot;Alpes-Maritimes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;07&quot;,&quot;state&quot;:&quot;Ard\u00e8che&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;08&quot;,&quot;state&quot;:&quot;Ardennes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;09&quot;,&quot;state&quot;:&quot;Ari\u00e8ge&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;10&quot;,&quot;state&quot;:&quot;Aube&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;11&quot;,&quot;state&quot;:&quot;Aude&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;12&quot;,&quot;state&quot;:&quot;Aveyron&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;67&quot;,&quot;state&quot;:&quot;Bas-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;13&quot;,&quot;state&quot;:&quot;Bouches-du-Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;14&quot;,&quot;state&quot;:&quot;Calvados&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;15&quot;,&quot;state&quot;:&quot;Cantal&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;16&quot;,&quot;state&quot;:&quot;Charente&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;17&quot;,&quot;state&quot;:&quot;Charente-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;18&quot;,&quot;state&quot;:&quot;Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;19&quot;,&quot;state&quot;:&quot;Corr\u00e8ze&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2A&quot;,&quot;state&quot;:&quot;Corse-du-Sud&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;21&quot;,&quot;state&quot;:&quot;C\u00f4te-d'Or&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;22&quot;,&quot;state&quot;:&quot;C\u00f4tes-d'Armor&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;23&quot;,&quot;state&quot;:&quot;Creuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;79&quot;,&quot;state&quot;:&quot;Deux-S\u00e8vres&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;24&quot;,&quot;state&quot;:&quot;Dordogne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;25&quot;,&quot;state&quot;:&quot;Doubs&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;26&quot;,&quot;state&quot;:&quot;Dr\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;91&quot;,&quot;state&quot;:&quot;Essonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;27&quot;,&quot;state&quot;:&quot;Eure&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;28&quot;,&quot;state&quot;:&quot;Eure-et-Loir&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;29&quot;,&quot;state&quot;:&quot;Finist\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;30&quot;,&quot;state&quot;:&quot;Gard&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;32&quot;,&quot;state&quot;:&quot;Gers&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;33&quot;,&quot;state&quot;:&quot;Gironde&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;68&quot;,&quot;state&quot;:&quot;Haut-Rhin&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;2B&quot;,&quot;state&quot;:&quot;Haute-Corse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;31&quot;,&quot;state&quot;:&quot;Haute-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;43&quot;,&quot;state&quot;:&quot;Haute-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;52&quot;,&quot;state&quot;:&quot;Haute-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;70&quot;,&quot;state&quot;:&quot;Haute-Sa\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;74&quot;,&quot;state&quot;:&quot;Haute-Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;87&quot;,&quot;state&quot;:&quot;Haute-Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;05&quot;,&quot;state&quot;:&quot;Hautes-Alpes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;65&quot;,&quot;state&quot;:&quot;Hautes-Pyr\u00e9n\u00e9es&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;92&quot;,&quot;state&quot;:&quot;Hauts-de-Seine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;34&quot;,&quot;state&quot;:&quot;H\u00e9rault&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;35&quot;,&quot;state&quot;:&quot;Ille-et-Vilaine&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;36&quot;,&quot;state&quot;:&quot;Indre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;37&quot;,&quot;state&quot;:&quot;Indre-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;38&quot;,&quot;state&quot;:&quot;Is\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;39&quot;,&quot;state&quot;:&quot;Jura&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;40&quot;,&quot;state&quot;:&quot;Landes&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;41&quot;,&quot;state&quot;:&quot;Loir-et-Cher&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;42&quot;,&quot;state&quot;:&quot;Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;44&quot;,&quot;state&quot;:&quot;Loire-Atlantique&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;45&quot;,&quot;state&quot;:&quot;Loiret&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;46&quot;,&quot;state&quot;:&quot;Lot&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;47&quot;,&quot;state&quot;:&quot;Lot-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;48&quot;,&quot;state&quot;:&quot;Loz\u00e8re&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;49&quot;,&quot;state&quot;:&quot;Maine-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;50&quot;,&quot;state&quot;:&quot;Manche&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;51&quot;,&quot;state&quot;:&quot;Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;53&quot;,&quot;state&quot;:&quot;Mayenne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;54&quot;,&quot;state&quot;:&quot;Meurthe-et-Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;55&quot;,&quot;state&quot;:&quot;Meuse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;56&quot;,&quot;state&quot;:&quot;Morbihan&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;57&quot;,&quot;state&quot;:&quot;Moselle&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;58&quot;,&quot;state&quot;:&quot;Ni\u00e8vre&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;59&quot;,&quot;state&quot;:&quot;Nord&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;60&quot;,&quot;state&quot;:&quot;Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;61&quot;,&quot;state&quot;:&quot;Orne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;75&quot;,&quot;state&quot;:&quot;Paris&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;62&quot;,&quot;state&quot;:&quot;Pas-de-Calais&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;63&quot;,&quot;state&quot;:&quot;Puy-de-D\u00f4me&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;64&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Atlantiques&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;66&quot;,&quot;state&quot;:&quot;Pyr\u00e9n\u00e9es-Orientales&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;69&quot;,&quot;state&quot;:&quot;Rh\u00f4ne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;71&quot;,&quot;state&quot;:&quot;Sa\u00f4ne-et-Loire&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;72&quot;,&quot;state&quot;:&quot;Sarthe&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;73&quot;,&quot;state&quot;:&quot;Savoie&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;77&quot;,&quot;state&quot;:&quot;Seine-et-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;76&quot;,&quot;state&quot;:&quot;Seine-Maritime&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;93&quot;,&quot;state&quot;:&quot;Seine-Saint-Denis&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;80&quot;,&quot;state&quot;:&quot;Somme&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;81&quot;,&quot;state&quot;:&quot;Tarn&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;82&quot;,&quot;state&quot;:&quot;Tarn-et-Garonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;90&quot;,&quot;state&quot;:&quot;Territoire de Belfort&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;95&quot;,&quot;state&quot;:&quot;Val-d'Oise&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;94&quot;,&quot;state&quot;:&quot;Val-de-Marne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;83&quot;,&quot;state&quot;:&quot;Var&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;84&quot;,&quot;state&quot;:&quot;Vaucluse&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;85&quot;,&quot;state&quot;:&quot;Vend\u00e9e&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;86&quot;,&quot;state&quot;:&quot;Vienne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;88&quot;,&quot;state&quot;:&quot;Vosges&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;89&quot;,&quot;state&quot;:&quot;Yonne&quot;},{&quot;country_code&quot;:&quot;FR&quot;,&quot;code&quot;:&quot;78&quot;,&quot;state&quot;:&quot;Yvelines&quot;}],&quot;GB&quot;:[{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABN&quot;,&quot;state&quot;:&quot;Aberdeen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ABNS&quot;,&quot;state&quot;:&quot;Aberdeenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANG&quot;,&quot;state&quot;:&quot;Anglesey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AGS&quot;,&quot;state&quot;:&quot;Angus&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARY&quot;,&quot;state&quot;:&quot;Argyll and Bute&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;AVN&quot;,&quot;state&quot;:&quot;Avon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BAN&quot;,&quot;state&quot;:&quot;Banffshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEDS&quot;,&quot;state&quot;:&quot;Bedfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BERKS&quot;,&quot;state&quot;:&quot;Berkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BEW&quot;,&quot;state&quot;:&quot;Berwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BLA&quot;,&quot;state&quot;:&quot;Blaenau Gwent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BRI&quot;,&quot;state&quot;:&quot;Bridgend&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BSTL&quot;,&quot;state&quot;:&quot;Bristol&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BUCKS&quot;,&quot;state&quot;:&quot;Buckinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAE&quot;,&quot;state&quot;:&quot;Caerphilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAI&quot;,&quot;state&quot;:&quot;Caithness&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CAMBS&quot;,&quot;state&quot;:&quot;Cambridgeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDF&quot;,&quot;state&quot;:&quot;Cardiff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CARM&quot;,&quot;state&quot;:&quot;Carmarthenshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CDGN&quot;,&quot;state&quot;:&quot;Ceredigion&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CHES&quot;,&quot;state&quot;:&quot;Cheshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLACK&quot;,&quot;state&quot;:&quot;Clackmannanshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CLV&quot;,&quot;state&quot;:&quot;Cleveland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CWD&quot;,&quot;state&quot;:&quot;Clwyd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CON&quot;,&quot;state&quot;:&quot;Conwy&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CORN&quot;,&quot;state&quot;:&quot;Cornwall&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ANT&quot;,&quot;state&quot;:&quot;County Antrim&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARM&quot;,&quot;state&quot;:&quot;County Armagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOW&quot;,&quot;state&quot;:&quot;County Down&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FER&quot;,&quot;state&quot;:&quot;County Fermanagh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDY&quot;,&quot;state&quot;:&quot;County Londonderry&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TYR&quot;,&quot;state&quot;:&quot;County Tyrone&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;CMA&quot;,&quot;state&quot;:&quot;Cumbria&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DNBG&quot;,&quot;state&quot;:&quot;Denbighshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DERBY&quot;,&quot;state&quot;:&quot;Derbyshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DVN&quot;,&quot;state&quot;:&quot;Devon&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DOR&quot;,&quot;state&quot;:&quot;Dorset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DGL&quot;,&quot;state&quot;:&quot;Dumfries and Galloway&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFS&quot;,&quot;state&quot;:&quot;Dumfries-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUND&quot;,&quot;state&quot;:&quot;Dundee&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DHM&quot;,&quot;state&quot;:&quot;Durham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DFD&quot;,&quot;state&quot;:&quot;Dyfed&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYE&quot;,&quot;state&quot;:&quot;East Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;DUNBE&quot;,&quot;state&quot;:&quot;East Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LOTE&quot;,&quot;state&quot;:&quot;East Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RENE&quot;,&quot;state&quot;:&quot;East Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ERYS&quot;,&quot;state&quot;:&quot;East Riding of Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXE&quot;,&quot;state&quot;:&quot;East Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;EDIN&quot;,&quot;state&quot;:&quot;Edinburgh&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ESX&quot;,&quot;state&quot;:&quot;Essex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FALK&quot;,&quot;state&quot;:&quot;Falkirk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FFE&quot;,&quot;state&quot;:&quot;Fife&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;FLINT&quot;,&quot;state&quot;:&quot;Flintshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLAS&quot;,&quot;state&quot;:&quot;Glasgow&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GLOS&quot;,&quot;state&quot;:&quot;Gloucestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LDN&quot;,&quot;state&quot;:&quot;Greater London&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MCH&quot;,&quot;state&quot;:&quot;Greater Manchester&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;GDD&quot;,&quot;state&quot;:&quot;Gwynedd&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HANTS&quot;,&quot;state&quot;:&quot;Hampshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HWR&quot;,&quot;state&quot;:&quot;Herefordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HERTS&quot;,&quot;state&quot;:&quot;Hertfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HLD&quot;,&quot;state&quot;:&quot;Highlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;HUM&quot;,&quot;state&quot;:&quot;Humberside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IVER&quot;,&quot;state&quot;:&quot;Inverclyde&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;INV&quot;,&quot;state&quot;:&quot;Inverness-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOW&quot;,&quot;state&quot;:&quot;Isle of Wight&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;IOS&quot;,&quot;state&quot;:&quot;Isles of Scilly&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KNT&quot;,&quot;state&quot;:&quot;Kent&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;KCD&quot;,&quot;state&quot;:&quot;Kincardineshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANCS&quot;,&quot;state&quot;:&quot;Lancashire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LEICS&quot;,&quot;state&quot;:&quot;Leicestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LINCS&quot;,&quot;state&quot;:&quot;Lincolnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MER&quot;,&quot;state&quot;:&quot;Merionethshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MSY&quot;,&quot;state&quot;:&quot;Merseyside&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MERT&quot;,&quot;state&quot;:&quot;Merthyr Tydfil&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MDX&quot;,&quot;state&quot;:&quot;Middlesex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MLOT&quot;,&quot;state&quot;:&quot;Midlothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MMOUTH&quot;,&quot;state&quot;:&quot;Monmouthshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;MORAY&quot;,&quot;state&quot;:&quot;Moray&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NAI&quot;,&quot;state&quot;:&quot;Nairnshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NPRTAL&quot;,&quot;state&quot;:&quot;Neath Port Talbot&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NEWPT&quot;,&quot;state&quot;:&quot;Newport&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOR&quot;,&quot;state&quot;:&quot;Norfolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYN&quot;,&quot;state&quot;:&quot;North Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANN&quot;,&quot;state&quot;:&quot;North Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSN&quot;,&quot;state&quot;:&quot;North Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NHM&quot;,&quot;state&quot;:&quot;Northamptonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NLD&quot;,&quot;state&quot;:&quot;Northumberland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;NOT&quot;,&quot;state&quot;:&quot;Nottinghamshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ORK&quot;,&quot;state&quot;:&quot;Orkney Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;OFE&quot;,&quot;state&quot;:&quot;Oxfordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEE&quot;,&quot;state&quot;:&quot;Peebles-shire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PEM&quot;,&quot;state&quot;:&quot;Pembrokeshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PERTH&quot;,&quot;state&quot;:&quot;Perth and Kinross&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;PWS&quot;,&quot;state&quot;:&quot;Powys&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;REN&quot;,&quot;state&quot;:&quot;Renfrewshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RHON&quot;,&quot;state&quot;:&quot;Rhondda Cynon Taff&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ROX&quot;,&quot;state&quot;:&quot;Roxburghshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;RUT&quot;,&quot;state&quot;:&quot;Rutland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;BOR&quot;,&quot;state&quot;:&quot;Scottish Borders&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SEL&quot;,&quot;state&quot;:&quot;Selkirkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SHET&quot;,&quot;state&quot;:&quot;Shetland Islands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Shropshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SOM&quot;,&quot;state&quot;:&quot;Somerset&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;ARYS&quot;,&quot;state&quot;:&quot;South Ayrshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;LANS&quot;,&quot;state&quot;:&quot;South Lanarkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SYK&quot;,&quot;state&quot;:&quot;South Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFD&quot;,&quot;state&quot;:&quot;Staffordshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STIR&quot;,&quot;state&quot;:&quot;Stirling&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;STI&quot;,&quot;state&quot;:&quot;Stirlingshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SFK&quot;,&quot;state&quot;:&quot;Suffolk&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SRY&quot;,&quot;state&quot;:&quot;Surrey&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SUT&quot;,&quot;state&quot;:&quot;Sutherland&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SWAN&quot;,&quot;state&quot;:&quot;Swansea&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TORF&quot;,&quot;state&quot;:&quot;Torfaen&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;TWR&quot;,&quot;state&quot;:&quot;Tyne and Wear&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;VGLAM&quot;,&quot;state&quot;:&quot;Vale of Glamorgan&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WARKS&quot;,&quot;state&quot;:&quot;Warwickshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WDUN&quot;,&quot;state&quot;:&quot;West Dunbartonshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLOT&quot;,&quot;state&quot;:&quot;West Lothian&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WMD&quot;,&quot;state&quot;:&quot;West Midlands&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;SXW&quot;,&quot;state&quot;:&quot;West Sussex&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YSW&quot;,&quot;state&quot;:&quot;West Yorkshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIL&quot;,&quot;state&quot;:&quot;Western Isles&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WIG&quot;,&quot;state&quot;:&quot;Wigtownshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WLT&quot;,&quot;state&quot;:&quot;Wiltshire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WORCS&quot;,&quot;state&quot;:&quot;Worcestershire&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;WRX&quot;,&quot;state&quot;:&quot;Wrexham&quot;},{&quot;country_code&quot;:&quot;GB&quot;,&quot;code&quot;:&quot;YKS&quot;,&quot;state&quot;:&quot;Yorkshire&quot;}],&quot;IT&quot;:[{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;Agrigento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alessandria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AN&quot;,&quot;state&quot;:&quot;Ancona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AO&quot;,&quot;state&quot;:&quot;Aosta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arezzo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AP&quot;,&quot;state&quot;:&quot;Ascoli Piceno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AT&quot;,&quot;state&quot;:&quot;Asti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AV&quot;,&quot;state&quot;:&quot;Avellino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Bari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BL&quot;,&quot;state&quot;:&quot;Belluno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;Benevento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BG&quot;,&quot;state&quot;:&quot;Bergamo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BI&quot;,&quot;state&quot;:&quot;Biella&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BO&quot;,&quot;state&quot;:&quot;Bologna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;Bolzano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BS&quot;,&quot;state&quot;:&quot;Brescia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;Brindisi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;Cagliari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;Caltanissetta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CB&quot;,&quot;state&quot;:&quot;Campobasso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CI&quot;,&quot;state&quot;:&quot;Carbonia-Iglesias&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Caserta&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Catania&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CZ&quot;,&quot;state&quot;:&quot;Catanzaro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CH&quot;,&quot;state&quot;:&quot;Chieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Como&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;Cosenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CR&quot;,&quot;state&quot;:&quot;Cremona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Crotone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;CN&quot;,&quot;state&quot;:&quot;Cuneo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;EN&quot;,&quot;state&quot;:&quot;Enna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FE&quot;,&quot;state&quot;:&quot;Ferrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FI&quot;,&quot;state&quot;:&quot;Firenze&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FG&quot;,&quot;state&quot;:&quot;Foggia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FC&quot;,&quot;state&quot;:&quot;Forli-Cesena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Frosinone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Genova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GO&quot;,&quot;state&quot;:&quot;Gorizia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Grosseto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IM&quot;,&quot;state&quot;:&quot;Imperia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;Isernia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;AQ&quot;,&quot;state&quot;:&quot;L'Aquila&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SP&quot;,&quot;state&quot;:&quot;La Spezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LT&quot;,&quot;state&quot;:&quot;Latina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LE&quot;,&quot;state&quot;:&quot;Lecce&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LC&quot;,&quot;state&quot;:&quot;Lecco&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Livorno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LO&quot;,&quot;state&quot;:&quot;Lodi&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;LU&quot;,&quot;state&quot;:&quot;Lucca&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MC&quot;,&quot;state&quot;:&quot;Macerata&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Mantova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Massa-Carrara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Matera&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;Medio Campidano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Messina&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Milano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Modena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NA&quot;,&quot;state&quot;:&quot;Napoli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NO&quot;,&quot;state&quot;:&quot;Novara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;NU&quot;,&quot;state&quot;:&quot;Nuoro&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OG&quot;,&quot;state&quot;:&quot;Ogliastra&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;Olbia-Tempio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oristano&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PD&quot;,&quot;state&quot;:&quot;Padova&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Palermo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Parma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PV&quot;,&quot;state&quot;:&quot;Pavia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PG&quot;,&quot;state&quot;:&quot;Perugia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PU&quot;,&quot;state&quot;:&quot;Pesaro e Urbino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PE&quot;,&quot;state&quot;:&quot;Pescara&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PC&quot;,&quot;state&quot;:&quot;Piacenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PI&quot;,&quot;state&quot;:&quot;Pisa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PT&quot;,&quot;state&quot;:&quot;Pistoia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PN&quot;,&quot;state&quot;:&quot;Pordenone&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PZ&quot;,&quot;state&quot;:&quot;Potenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;PO&quot;,&quot;state&quot;:&quot;Prato&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RG&quot;,&quot;state&quot;:&quot;Ragusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RA&quot;,&quot;state&quot;:&quot;Ravenna&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RC&quot;,&quot;state&quot;:&quot;Reggio Calabria&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RE&quot;,&quot;state&quot;:&quot;Reggio Emilia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rieti&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RN&quot;,&quot;state&quot;:&quot;Rimini&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RM&quot;,&quot;state&quot;:&quot;Roma&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;RO&quot;,&quot;state&quot;:&quot;Rovigo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Salerno&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SS&quot;,&quot;state&quot;:&quot;Sassari&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;Savona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SI&quot;,&quot;state&quot;:&quot;Siena&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SR&quot;,&quot;state&quot;:&quot;Siracusa&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;SO&quot;,&quot;state&quot;:&quot;Sondrio&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Taranto&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TE&quot;,&quot;state&quot;:&quot;Teramo&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;Terni&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TO&quot;,&quot;state&quot;:&quot;Torino&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TP&quot;,&quot;state&quot;:&quot;Trapani&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Trento&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TV&quot;,&quot;state&quot;:&quot;Treviso&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;TS&quot;,&quot;state&quot;:&quot;Trieste&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udine&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Varese&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VE&quot;,&quot;state&quot;:&quot;Venezia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VB&quot;,&quot;state&quot;:&quot;Verbano-Cusio-Ossola&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VC&quot;,&quot;state&quot;:&quot;Vercelli&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VR&quot;,&quot;state&quot;:&quot;Verona&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VV&quot;,&quot;state&quot;:&quot;Vibo Valentia&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Vicenza&quot;},{&quot;country_code&quot;:&quot;IT&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Viterbo&quot;}],&quot;JP&quot;:[{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AICHI&quot;,&quot;state&quot;:&quot;AICHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AKITA&quot;,&quot;state&quot;:&quot;AKITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;AOMORI&quot;,&quot;state&quot;:&quot;AOMORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;CHIBA&quot;,&quot;state&quot;:&quot;CHIBA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;EHIME&quot;,&quot;state&quot;:&quot;EHIME&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUI&quot;,&quot;state&quot;:&quot;FUKUI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUOKA&quot;,&quot;state&quot;:&quot;FUKUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;FUKUSHIMA&quot;,&quot;state&quot;:&quot;FUKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GIFU&quot;,&quot;state&quot;:&quot;GIFU&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;GUMMA&quot;,&quot;state&quot;:&quot;GUMMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HIROSHIMA&quot;,&quot;state&quot;:&quot;HIROSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HOKKAIDO&quot;,&quot;state&quot;:&quot;HOKKAIDO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;HYOGO&quot;,&quot;state&quot;:&quot;HYOGO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IBARAKI&quot;,&quot;state&quot;:&quot;IBARAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;ISHIKAWA&quot;,&quot;state&quot;:&quot;ISHIKAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;IWATE&quot;,&quot;state&quot;:&quot;IWATE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGAWA&quot;,&quot;state&quot;:&quot;KAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KAGOSHIMA&quot;,&quot;state&quot;:&quot;KAGOSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KANAGAWA&quot;,&quot;state&quot;:&quot;KANAGAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KOCHI&quot;,&quot;state&quot;:&quot;KOCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KUMAMOTO&quot;,&quot;state&quot;:&quot;KUMAMOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;KYOTO&quot;,&quot;state&quot;:&quot;KYOTO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIE&quot;,&quot;state&quot;:&quot;MIE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAGI&quot;,&quot;state&quot;:&quot;MIYAGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;MIYAZAKI&quot;,&quot;state&quot;:&quot;MIYAZAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGANO&quot;,&quot;state&quot;:&quot;NAGANO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NAGASAKI&quot;,&quot;state&quot;:&quot;NAGASAKI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NARA&quot;,&quot;state&quot;:&quot;NARA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;NIIGATA&quot;,&quot;state&quot;:&quot;NIIGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OITA&quot;,&quot;state&quot;:&quot;OITA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKAYAMA&quot;,&quot;state&quot;:&quot;OKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OKINAWA&quot;,&quot;state&quot;:&quot;OKINAWA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;OSAKA&quot;,&quot;state&quot;:&quot;OSAKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAGA&quot;,&quot;state&quot;:&quot;SAGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SAITAMA&quot;,&quot;state&quot;:&quot;SAITAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIGA&quot;,&quot;state&quot;:&quot;SHIGA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIMANE&quot;,&quot;state&quot;:&quot;SHIMANE&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;SHIZUOKA&quot;,&quot;state&quot;:&quot;SHIZUOKA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOCHIGI&quot;,&quot;state&quot;:&quot;TOCHIGI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKUSHIMA&quot;,&quot;state&quot;:&quot;TOKUSHIMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOKYO&quot;,&quot;state&quot;:&quot;TOKYO&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOTTORI&quot;,&quot;state&quot;:&quot;TOTTORI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;TOYAMA&quot;,&quot;state&quot;:&quot;TOYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;WAKAYAMA&quot;,&quot;state&quot;:&quot;WAKAYAMA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGATA&quot;,&quot;state&quot;:&quot;YAMAGATA&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMAGUCHI&quot;,&quot;state&quot;:&quot;YAMAGUCHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;YAMANASHI&quot;,&quot;state&quot;:&quot;YAMANASHI&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4e09\u91cd\u770c&quot;,&quot;state&quot;:&quot;\u4e09\u91cd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4eac\u90fd\u5e9c&quot;,&quot;state&quot;:&quot;\u4eac\u90fd\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u4f50\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u4f50\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5175\u5eab\u770c&quot;,&quot;state&quot;:&quot;\u5175\u5eab\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5317\u6d77\u9053&quot;,&quot;state&quot;:&quot;\u5317\u6d77\u9053&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5343\u8449\u770c&quot;,&quot;state&quot;:&quot;\u5343\u8449\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u548c\u6b4c\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u57fc\u7389\u770c&quot;,&quot;state&quot;:&quot;\u57fc\u7389\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u5206\u770c&quot;,&quot;state&quot;:&quot;\u5927\u5206\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5927\u962a\u5e9c&quot;,&quot;state&quot;:&quot;\u5927\u962a\u5e9c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5948\u826f\u770c&quot;,&quot;state&quot;:&quot;\u5948\u826f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bae\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u5bae\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5bcc\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5bcc\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u53e3\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u53e3\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u5f62\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u5f62\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c71\u68a8\u770c&quot;,&quot;state&quot;:&quot;\u5c71\u68a8\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5c90\u961c\u770c&quot;,&quot;state&quot;:&quot;\u5c90\u961c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca1\u5c71\u770c&quot;,&quot;state&quot;:&quot;\u5ca1\u5c71\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5ca9\u624b\u770c&quot;,&quot;state&quot;:&quot;\u5ca9\u624b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5cf6\u6839\u770c&quot;,&quot;state&quot;:&quot;\u5cf6\u6839\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5e83\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5e83\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u5fb3\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u5fb3\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u5a9b\u770c&quot;,&quot;state&quot;:&quot;\u611b\u5a9b\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u611b\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u611b\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u65b0\u6f5f\u770c&quot;,&quot;state&quot;:&quot;\u65b0\u6f5f\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6771\u4eac\u90fd&quot;,&quot;state&quot;:&quot;\u6771\u4eac\u90fd&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6803\u6728\u770c&quot;,&quot;state&quot;:&quot;\u6803\u6728\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6c96\u7e04\u770c&quot;,&quot;state&quot;:&quot;\u6c96\u7e04\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u6ecb\u8cc0\u770c&quot;,&quot;state&quot;:&quot;\u6ecb\u8cc0\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u718a\u672c\u770c&quot;,&quot;state&quot;:&quot;\u718a\u672c\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u77f3\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u77f3\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u795e\u5948\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u4e95\u770c&quot;,&quot;state&quot;:&quot;\u798f\u4e95\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u798f\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u798f\u5cf6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u79cb\u7530\u770c&quot;,&quot;state&quot;:&quot;\u79cb\u7530\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u7fa4\u99ac\u770c&quot;,&quot;state&quot;:&quot;\u7fa4\u99ac\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u8328\u57ce\u770c&quot;,&quot;state&quot;:&quot;\u8328\u57ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u5d0e\u770c&quot;,&quot;state&quot;:&quot;\u9577\u5d0e\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9577\u91ce\u770c&quot;,&quot;state&quot;:&quot;\u9577\u91ce\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9752\u68ee\u770c&quot;,&quot;state&quot;:&quot;\u9752\u68ee\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9759\u5ca1\u770c&quot;,&quot;state&quot;:&quot;\u9759\u5ca1\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9999\u5ddd\u770c&quot;,&quot;state&quot;:&quot;\u9999\u5ddd\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ad8\u77e5\u770c&quot;,&quot;state&quot;:&quot;\u9ad8\u77e5\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9ce5\u53d6\u770c&quot;,&quot;state&quot;:&quot;\u9ce5\u53d6\u770c&quot;},{&quot;country_code&quot;:&quot;JP&quot;,&quot;code&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;,&quot;state&quot;:&quot;\u9e7f\u5150\u5cf6\u770c&quot;}],&quot;NL&quot;:[{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;DR&quot;,&quot;state&quot;:&quot;Drenthe&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Flevoland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;FR&quot;,&quot;state&quot;:&quot;Friesland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GE&quot;,&quot;state&quot;:&quot;Gelderland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;Groningen&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;LI&quot;,&quot;state&quot;:&quot;Limburg&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NB&quot;,&quot;state&quot;:&quot;Noord Brabant&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;Noord Holland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;OV&quot;,&quot;state&quot;:&quot;Overijssel&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utrecht&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZE&quot;,&quot;state&quot;:&quot;Zeeland&quot;},{&quot;country_code&quot;:&quot;NL&quot;,&quot;code&quot;:&quot;ZH&quot;,&quot;state&quot;:&quot;Zuid Holland&quot;}],&quot;RO&quot;:[{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AB&quot;,&quot;state&quot;:&quot;ALBA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;ARAD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;AG&quot;,&quot;state&quot;:&quot;ARGES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BC&quot;,&quot;state&quot;:&quot;BACAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BH&quot;,&quot;state&quot;:&quot;BIHOR&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BN&quot;,&quot;state&quot;:&quot;BISTRITA-NASAUD&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BT&quot;,&quot;state&quot;:&quot;BOTOSANI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BR&quot;,&quot;state&quot;:&quot;BRAILA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BV&quot;,&quot;state&quot;:&quot;BRASOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;B&quot;,&quot;state&quot;:&quot;BUCURESTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;BZ&quot;,&quot;state&quot;:&quot;BUZAU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CL&quot;,&quot;state&quot;:&quot;CALARASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CS&quot;,&quot;state&quot;:&quot;CARAS-SEVERIN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CJ&quot;,&quot;state&quot;:&quot;CLUJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;CONSTANTA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;CV&quot;,&quot;state&quot;:&quot;COVASNA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DB&quot;,&quot;state&quot;:&quot;DAMBOVITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;DJ&quot;,&quot;state&quot;:&quot;DOLJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GL&quot;,&quot;state&quot;:&quot;GALATI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GR&quot;,&quot;state&quot;:&quot;GIURGIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;GJ&quot;,&quot;state&quot;:&quot;GORJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HR&quot;,&quot;state&quot;:&quot;HARGHITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;HD&quot;,&quot;state&quot;:&quot;HUNEDOARA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;IALOMITA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IS&quot;,&quot;state&quot;:&quot;IASI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;IF&quot;,&quot;state&quot;:&quot;ILFOV&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MM&quot;,&quot;state&quot;:&quot;MARAMURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MH&quot;,&quot;state&quot;:&quot;MEHEDINTI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;MURES&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;NT&quot;,&quot;state&quot;:&quot;NEAMT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;OT&quot;,&quot;state&quot;:&quot;OLT&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;PH&quot;,&quot;state&quot;:&quot;PRAHOVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SJ&quot;,&quot;state&quot;:&quot;SALAJ&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SM&quot;,&quot;state&quot;:&quot;SATU MARE&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SB&quot;,&quot;state&quot;:&quot;SIBIU&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;SV&quot;,&quot;state&quot;:&quot;SUCEAVA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TR&quot;,&quot;state&quot;:&quot;TELEORMAN&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TM&quot;,&quot;state&quot;:&quot;TIMIS&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;TL&quot;,&quot;state&quot;:&quot;TULCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VL&quot;,&quot;state&quot;:&quot;VALCEA&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VS&quot;,&quot;state&quot;:&quot;VASLUI&quot;},{&quot;country_code&quot;:&quot;RO&quot;,&quot;code&quot;:&quot;VN&quot;,&quot;state&quot;:&quot;VRANCEA&quot;}],&quot;RU&quot;:[{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ALT&quot;,&quot;state&quot;:&quot;Altajskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AMU&quot;,&quot;state&quot;:&quot;Amurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ARK&quot;,&quot;state&quot;:&quot;Arhangel'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AST&quot;,&quot;state&quot;:&quot;Astrahanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BEL&quot;,&quot;state&quot;:&quot;Belgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BRY&quot;,&quot;state&quot;:&quot;Brjanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CE&quot;,&quot;state&quot;:&quot;Chechenskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHE&quot;,&quot;state&quot;:&quot;Cheljabinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CHU&quot;,&quot;state&quot;:&quot;Chukotskij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;CU&quot;,&quot;state&quot;:&quot;Chuvashskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YEV&quot;,&quot;state&quot;:&quot;Evrejskaja avtonomnaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHA&quot;,&quot;state&quot;:&quot;Habarovskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KHM&quot;,&quot;state&quot;:&quot;Hanty-Mansijskij avtonomnyj okrug - Jugra&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IRK&quot;,&quot;state&quot;:&quot;Irkutskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IVA&quot;,&quot;state&quot;:&quot;Ivanovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAN&quot;,&quot;state&quot;:&quot;Jamalo-Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;YAR&quot;,&quot;state&quot;:&quot;Jaroslavskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KB&quot;,&quot;state&quot;:&quot;Kabardino-Balkarskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGD&quot;,&quot;state&quot;:&quot;Kaliningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KLU&quot;,&quot;state&quot;:&quot;Kaluzhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KAM&quot;,&quot;state&quot;:&quot;Kamchatskiy kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KC&quot;,&quot;state&quot;:&quot;Karachaevo-Cherkesskaja respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KEM&quot;,&quot;state&quot;:&quot;Kemerovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIR&quot;,&quot;state&quot;:&quot;Kirovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KOS&quot;,&quot;state&quot;:&quot;Kostromskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KDA&quot;,&quot;state&quot;:&quot;Krasnodarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KIA&quot;,&quot;state&quot;:&quot;Krasnojarskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KGN&quot;,&quot;state&quot;:&quot;Kurganskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KRS&quot;,&quot;state&quot;:&quot;Kurskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LEN&quot;,&quot;state&quot;:&quot;Leningradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;LIP&quot;,&quot;state&quot;:&quot;Lipeckaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MAG&quot;,&quot;state&quot;:&quot;Magadanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOS&quot;,&quot;state&quot;:&quot;Moskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MOW&quot;,&quot;state&quot;:&quot;Moskva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MUR&quot;,&quot;state&quot;:&quot;Murmanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NEN&quot;,&quot;state&quot;:&quot;Neneckij avtonomnyj okrug&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NIZ&quot;,&quot;state&quot;:&quot;Nizhegorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NGR&quot;,&quot;state&quot;:&quot;Novgorodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;NVS&quot;,&quot;state&quot;:&quot;Novosibirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;OMS&quot;,&quot;state&quot;:&quot;Omskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORE&quot;,&quot;state&quot;:&quot;Orenburgskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ORL&quot;,&quot;state&quot;:&quot;Orlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PNZ&quot;,&quot;state&quot;:&quot;Penzenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PER&quot;,&quot;state&quot;:&quot;Permskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PRI&quot;,&quot;state&quot;:&quot;Primorskij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;PSK&quot;,&quot;state&quot;:&quot;Pskovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AD&quot;,&quot;state&quot;:&quot;Respublika Adygeja&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Respublika Altaj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BA&quot;,&quot;state&quot;:&quot;Respublika Bashkortostan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;BU&quot;,&quot;state&quot;:&quot;Respublika Burjatija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;DA&quot;,&quot;state&quot;:&quot;Respublika Dagestan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KK&quot;,&quot;state&quot;:&quot;Respublika Hakasija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Respublika Ingushetija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KL&quot;,&quot;state&quot;:&quot;Respublika Kalmykija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KR&quot;,&quot;state&quot;:&quot;Respublika Karelija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;KO&quot;,&quot;state&quot;:&quot;Respublika Komi&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Respublika Marij Jel&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Respublika Mordovija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SA&quot;,&quot;state&quot;:&quot;Respublika Saha (Jakutija)&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SE&quot;,&quot;state&quot;:&quot;Respublika Severnaja Osetija-Alanija&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TA&quot;,&quot;state&quot;:&quot;Respublika Tatarstan&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TY&quot;,&quot;state&quot;:&quot;Respublika Tyva&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;RYA&quot;,&quot;state&quot;:&quot;Rjazanskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ROS&quot;,&quot;state&quot;:&quot;Rostovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAK&quot;,&quot;state&quot;:&quot;Sahalinskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAM&quot;,&quot;state&quot;:&quot;Samarskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SPE&quot;,&quot;state&quot;:&quot;Sankt-Peterburg&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SAR&quot;,&quot;state&quot;:&quot;Saratovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SMO&quot;,&quot;state&quot;:&quot;Smolenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;STA&quot;,&quot;state&quot;:&quot;Stavropol'skij kraj&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;SVE&quot;,&quot;state&quot;:&quot;Sverdlovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TAM&quot;,&quot;state&quot;:&quot;Tambovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TYU&quot;,&quot;state&quot;:&quot;Tjumenskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TOM&quot;,&quot;state&quot;:&quot;Tomskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TUL&quot;,&quot;state&quot;:&quot;Tul'skaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;TVE&quot;,&quot;state&quot;:&quot;Tverskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;UD&quot;,&quot;state&quot;:&quot;Udmurtskaja Respublika&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ULY&quot;,&quot;state&quot;:&quot;Ul'janovskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLA&quot;,&quot;state&quot;:&quot;Vladimirskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VGG&quot;,&quot;state&quot;:&quot;Volgogradskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VLG&quot;,&quot;state&quot;:&quot;Vologodskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;VOR&quot;,&quot;state&quot;:&quot;Voronezhskaja oblast'&quot;},{&quot;country_code&quot;:&quot;RU&quot;,&quot;code&quot;:&quot;ZAB&quot;,&quot;state&quot;:&quot;Zabaykal'skiy kraj&quot;}],&quot;US&quot;:[{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AL&quot;,&quot;state&quot;:&quot;Alabama&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AK&quot;,&quot;state&quot;:&quot;Alaska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AZ&quot;,&quot;state&quot;:&quot;Arizona&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;AR&quot;,&quot;state&quot;:&quot;Arkansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CA&quot;,&quot;state&quot;:&quot;California&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CO&quot;,&quot;state&quot;:&quot;Colorado&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;CT&quot;,&quot;state&quot;:&quot;Connecticut&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DE&quot;,&quot;state&quot;:&quot;Delaware&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;DC&quot;,&quot;state&quot;:&quot;District of Columbia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;FL&quot;,&quot;state&quot;:&quot;Florida&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GA&quot;,&quot;state&quot;:&quot;Georgia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;GU&quot;,&quot;state&quot;:&quot;Guam&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;HI&quot;,&quot;state&quot;:&quot;Hawaii&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ID&quot;,&quot;state&quot;:&quot;Idaho&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IL&quot;,&quot;state&quot;:&quot;Illinois&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IN&quot;,&quot;state&quot;:&quot;Indiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;IA&quot;,&quot;state&quot;:&quot;Iowa&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KS&quot;,&quot;state&quot;:&quot;Kansas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;KY&quot;,&quot;state&quot;:&quot;Kentucky&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;LA&quot;,&quot;state&quot;:&quot;Louisiana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ME&quot;,&quot;state&quot;:&quot;Maine&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MD&quot;,&quot;state&quot;:&quot;Maryland&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MA&quot;,&quot;state&quot;:&quot;Massachusetts&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MI&quot;,&quot;state&quot;:&quot;Michigan&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MN&quot;,&quot;state&quot;:&quot;Minnesota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MS&quot;,&quot;state&quot;:&quot;Mississippi&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MO&quot;,&quot;state&quot;:&quot;Missouri&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MT&quot;,&quot;state&quot;:&quot;Montana&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NE&quot;,&quot;state&quot;:&quot;Nebraska&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NV&quot;,&quot;state&quot;:&quot;Nevada&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NH&quot;,&quot;state&quot;:&quot;New Hampshire&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NJ&quot;,&quot;state&quot;:&quot;New Jersey&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NM&quot;,&quot;state&quot;:&quot;New Mexico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NY&quot;,&quot;state&quot;:&quot;New York&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;NC&quot;,&quot;state&quot;:&quot;North Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;ND&quot;,&quot;state&quot;:&quot;North Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;MP&quot;,&quot;state&quot;:&quot;Northern Mariana Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OH&quot;,&quot;state&quot;:&quot;Ohio&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OK&quot;,&quot;state&quot;:&quot;Oklahoma&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;OR&quot;,&quot;state&quot;:&quot;Oregon&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PA&quot;,&quot;state&quot;:&quot;Pennsylvania&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;PR&quot;,&quot;state&quot;:&quot;Puerto Rico&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;RI&quot;,&quot;state&quot;:&quot;Rhode Island&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SC&quot;,&quot;state&quot;:&quot;South Carolina&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;SD&quot;,&quot;state&quot;:&quot;South Dakota&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TN&quot;,&quot;state&quot;:&quot;Tennessee&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;TX&quot;,&quot;state&quot;:&quot;Texas&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;UT&quot;,&quot;state&quot;:&quot;Utah&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VT&quot;,&quot;state&quot;:&quot;Vermont&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VI&quot;,&quot;state&quot;:&quot;Virgin Islands&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;VA&quot;,&quot;state&quot;:&quot;Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WA&quot;,&quot;state&quot;:&quot;Washington&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WV&quot;,&quot;state&quot;:&quot;West Virginia&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WI&quot;,&quot;state&quot;:&quot;Wisconsin&quot;},{&quot;country_code&quot;:&quot;US&quot;,&quot;code&quot;:&quot;WY&quot;,&quot;state&quot;:&quot;Wyoming&quot;}]},
                countries_with_codes: {&quot;RO&quot;:&quot;RO&quot;}            });

                            $.ceFormValidator('setZipcode', {
                    
                    US: {
                        regexp: /^(\d{5})(-\d{4})?$/,
                        format: '01342 (01342-5678)'
                    },
                    CA: {
                        regexp: /^[A-Z]{1}\d{1}[A-Z]{1} *\d{1}[A-Z]{1}\d{1}$/i,
                        format: 'V1A OB1 / V1AOB1'
                    },
                    RU: {
                        regexp: /^(\d{6})?$/,
                        format: '123456'
                    },
                    
                    default: {
                        regexp: /^[0-9a-zA-Z]+$/i,
                        format: 'Alpha numeric'
                    }
                });
                    }

                    zipCodeInitializer();
            }(Tygh, Tygh.$));
    //]]>





    
                    
    
                
            
        
        
        1 - START
    
            
            
            2 - DATELE TALE
        
                    
            
            3 - VALIDARE EMAIL
        
        
        
                
            
                        
            
            
            
            

                        
            
            
            
            
            
            
            
                                                    
                                
                        EMAIL ȘI PAROLĂ

                        
                                                                
                        
                            Enter your email address and agree to the Terms &amp; Conditions to begin the process of setting up your IQOS account.
                                                            




    
                                    
                    
                        
                        
                            
                            
                                E-mail
                            
                            
                        
                    
                
                        
	
        //&lt;![CDATA[
            Tygh.tr(&quot;email_providers_ajax.waiting_text&quot;, &quot;În așteptarea ca serverul să valideze mesajele e-mail, așteptați&quot;);
            Tygh.tr(&quot;email_providers_ajax.blacklisted_email_error&quot;, &quot;Nu îți poți crea un cont cu această adresă de e-mail. Te rugăm să introduci alta.&quot;);
            Tygh.tr(&quot;email_providers_ajax.url&quot;, &quot;https://preprod.iqos.ro/index.php?dispatch=email_providers_ajax.validate_email&quot;);
        //]]>
	
    


			
	    

                                            
                    
                        
                        
                            
                            
                                Parola ta
                            
                            
                        
                    
                                                                        
                                
                                    
            
                ℗ An upper case letter
                ℗ A lower case letter
                ℗ A number
                ℗ A non-alphabetic character (e.g. % $ € *)
            
        
        
                                
                            

                            
                                $(document).ready(function () {
                                    $('#password1').focus(function() {
                                        $('#pass_info').addClass('show');
                                    }).blur(function() {
                                        $('#pass_info').removeClass('show');
                                    });
                                });
                            
                                                            

                
                    
                        
                        
                            
                            
                                Reintroducere parolă
                            
                            
                        
                    
                    Trebuie să conțină între 8 și 20 de caractere, dintre care cel puțin o cifră.
                
                        
    


    



                                                                                    

                        
                            Enter your email address and agree to the Terms &amp; Conditions to begin the process of setting up your IQOS account.
                                                                                                                                                                




                
        
                                                                            
                                            
                            
                            
                            
                            * Am citit și înțeles  Notificarea de protecție a datelor cu caracter personal. 
                        
                                    
                
                        
                                
            
                            
                    
                    
                    
                    
                    Nu vreau să ratez ofertele (reduceri, ediții limitate, noutăți despre produse ș.a.) Philip Morris Trading S.R.L. și sunt de acord să primesc prin email sau SMS informații comerciale despre IQOS, HEETS sau alte produse/servicii conexe oferite de Philip Morris Trading S.R.L. sau de partenerii săi.
                
            
            
            
Please note, by unticking the marketing opt-in, you will lose your care plus membership and all related advantages.
        
    
            
        
    




                                                                                    
                    
                                

                

            
                            
                                
                                    Continuare
                                
                                                            
                        
                    

                    
                        DATELE TALE
                        
                            
                                
                                                    
                
                
                
                
                
                
                                


    

        



                                        
    
    
        
    
        
    
    
                                                                
    
        
      

        
                            
                    
                     Dl.
                
                            
                    
                     Dna.
                
                    

                                





                                            
    
    
        
    
        
    
    
                                                                
    
                                                                                        
      
        
        

        
                
                    
                    
                        
                        
                            Prenume *
                        
                        
                    
                
                    


        

                                





                                            
    
    
        
    
        
    
    
                                                                
    
                                                                                        
      
        
        

        
                
                    
                    
                        
                        
                            Nume *
                        
                        
                    
                
                    


        

                                





                                            
    
    
        
    
        
    
    
                                                                
    
        
      

        
    
    
        
        
            Data nașterii *
        
        
    



                                





    








    /* Prefix phone number */
    .shipping-phone.-focus.input-container:before,
    .shipping-phone.-filled.input-container:before {
        content: &quot;07&quot;;
        height: 40px;
        position: absolute;
        display: block;
        line-height: 41px;
        padding-left: 12px;
    }
    .shipping-phone.-focus.-expanded.input-container:before,
    .shipping-phone.-filled.-expanded.input-container:before {
        height: 56px;
        line-height: 57px;
    }
    .shipping-phone.-focus.input-container input,
    .shipping-phone.-filled.input-container input {
        padding-left: 38px;
    }
    .user-info .s_phone:before, .user-info .b_phone:before {
        content: &quot;07&quot;;
    }







                
                

                                                                                                                                                                                
                    


    

        



                                        
    
    
                                                                    
    
        
    
    
                                                                
    
                                                                    
      

                
        

                        
                
                    
                                                                            ALBA
                                                    ARAD
                                                    ARGES
                                                    BACAU
                                                    BIHOR
                                                    BISTRITA-NASAUD
                                                    BOTOSANI
                                                    BRAILA
                                                    BRASOV
                                                    BUCURESTI
                                                    BUZAU
                                                    CALARASI
                                                    CARAS-SEVERIN
                                                    CLUJ
                                                    CONSTANTA
                                                    COVASNA
                                                    DAMBOVITA
                                                    DOLJ
                                                    GALATI
                                                    GIURGIU
                                                    GORJ
                                                    HARGHITA
                                                    HUNEDOARA
                                                    IALOMITA
                                                    IASI
                                                    ILFOV
                                                    MARAMURES
                                                    MEHEDINTI
                                                    MURES
                                                    NEAMT
                                                    OLT
                                                    PRAHOVA
                                                    SALAJ
                                                    SATU MARE
                                                    SIBIU
                                                    SUCEAVA
                                                    TELEORMAN
                                                    TIMIS
                                                    TULCEA
                                                    VALCEA
                                                    VASLUI
                                                    VRANCEA
                                                            
                
                    
                    
                        Judet *
                    
                    
                
            
        
                                





                                            
    
    
                                                
    
        
    
    
                                                                
    
                                                                                        
      
        
                    
            
            
            
            
                Localitate *
            
            
        
        
    
                                





                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
      
        
        

        
                
                    
                    
                        
                        
                            Sector 
                        
                        
                    
                
                    


        

                                





                                            
    
    
                                                                    
    
        
    
    
                                                                
    
        
    
                    
                
                
                        
                        
                            Număr de telefon *
                        
                        
                    
            
        
                                





                                            
    
    
                                                
    
        
    
    
                                                                
    
        
      

        
                    
                 
                        
                            
                                                    Afghanistan
                                                    Aland Islands
                                                    Albania
                                                    Algeria
                                                    American Samoa
                                                    Andorra
                                                    Angola
                                                    Anguilla
                                                    Antarctica
                                                    Antigua and Barbuda
                                                    Argentina
                                                    Armenia
                                                    Aruba
                                                    Asia-Pacific
                                                    Australia
                                                    Austria
                                                    Azerbaijan
                                                    Bahamas
                                                    Bahrain
                                                    Bangladesh
                                                    Barbados
                                                    Belarus
                                                    Belgium
                                                    Belize
                                                    Benin
                                                    Bermuda
                                                    Bhutan
                                                    Bolivia
                                                    Bosnia and Herzegowina
                                                    Botswana
                                                    Bouvet Island
                                                    Brazil
                                                    British Indian Ocean Territory
                                                    British Virgin Islands
                                                    Brunei Darussalam
                                                    Bulgaria
                                                    Burkina Faso
                                                    Burundi
                                                    Cambodia
                                                    Cameroon
                                                    Canada
                                                    Cape Verde
                                                    Cayman Islands
                                                    Central African Republic
                                                    Chad
                                                    Chile
                                                    China
                                                    Christmas Island
                                                    Cocos (Keeling) Islands
                                                    Colombia
                                                    Comoros
                                                    Congo
                                                    Cook Islands
                                                    Costa Rica
                                                    Cote D'ivoire
                                                    Croatia
                                                    Cuba
                                                    Curaçao
                                                    Cyprus
                                                    Czech Republic
                                                    Denmark
                                                    Djibouti
                                                    Dominica
                                                    Dominican Republic
                                                    East Timor
                                                    Ecuador
                                                    Egypt
                                                    El Salvador
                                                    Equatorial Guinea
                                                    Eritrea
                                                    Estonia
                                                    Ethiopia
                                                    Europe
                                                    Falkland Islands (Malvinas)
                                                    Faroe Islands
                                                    Fiji
                                                    Finland
                                                    France
                                                    France, Metropolitan
                                                    French Guiana
                                                    French Polynesia
                                                    French Southern Territories
                                                    Gabon
                                                    Gambia
                                                    Georgia
                                                    Germany
                                                    Ghana
                                                    Gibraltar
                                                    Greece
                                                    Greenland
                                                    Grenada
                                                    Guadeloupe
                                                    Guam
                                                    Guatemala
                                                    Guernsey
                                                    Guinea
                                                    Guinea-Bissau
                                                    Guyana
                                                    Haiti
                                                    Heard and McDonald Islands
                                                    Honduras
                                                    Hong Kong
                                                    Hungary
                                                    Iceland
                                                    India
                                                    Indonesia
                                                    Iraq
                                                    Ireland
                                                    Islamic Republic of Iran
                                                    Isle of Man
                                                    Israel
                                                    Italy
                                                    Jamaica
                                                    Japan
                                                    Jersey
                                                    Jordan
                                                    Kazakhstan
                                                    Kenya
                                                    Kiribati
                                                    Korea
                                                    Korea, Republic of
                                                    Kuwait
                                                    Kyrgyzstan
                                                    Laos
                                                    Latvia
                                                    Lebanon
                                                    Lesotho
                                                    Liberia
                                                    Libyan Arab Jamahiriya
                                                    Liechtenstein
                                                    Lithuania
                                                    Luxembourg
                                                    Macau
                                                    Macedonia
                                                    Madagascar
                                                    Malawi
                                                    Malaysia
                                                    Maldives
                                                    Mali
                                                    Malta
                                                    Marshall Islands
                                                    Martinique
                                                    Mauritania
                                                    Mauritius
                                                    Mayotte
                                                    Mexico
                                                    Micronesia
                                                    Moldova, Republic of
                                                    Monaco
                                                    Mongolia
                                                    Montenegro
                                                    Montserrat
                                                    Morocco
                                                    Mozambique
                                                    Myanmar
                                                    Namibia
                                                    Nauru
                                                    Nepal
                                                    Netherlands
                                                    New Caledonia
                                                    New Zealand
                                                    Nicaragua
                                                    Niger
                                                    Nigeria
                                                    Niue
                                                    Norfolk Island
                                                    Northern Mariana Islands
                                                    Norway
                                                    Oman
                                                    Pakistan
                                                    Palau
                                                    Palestine Authority
                                                    Panama
                                                    Papua New Guinea
                                                    Paraguay
                                                    Peru
                                                    Philippines
                                                    Pitcairn
                                                    Poland
                                                    Portugal
                                                    Puerto Rico
                                                    Qatar
                                                    Republic of Serbia
                                                    Reunion
                                                    Romania
                                                    Russian Federation
                                                    Rwanda
                                                    Saint Lucia
                                                    Samoa
                                                    San Marino
                                                    Sao Tome and Principe
                                                    Saudi Arabia
                                                    Senegal
                                                    Serbia
                                                    Seychelles
                                                    Sierra Leone
                                                    Singapore
                                                    Sint Maarten
                                                    Slovakia
                                                    Slovenia
                                                    Solomon Islands
                                                    Somalia
                                                    South Africa
                                                    Spain
                                                    Sri Lanka
                                                    St. Helena
                                                    St. Kitts and Nevis
                                                    St. Pierre and Miquelon
                                                    St. Vincent and the Grenadines
                                                    Sudan
                                                    Suriname
                                                    Svalbard and Jan Mayen Islands
                                                    Swaziland
                                                    Sweden
                                                    Switzerland
                                                    Syrian Arab Republic
                                                    Taiwan
                                                    Tajikistan
                                                    Tanzania, United Republic of
                                                    Thailand
                                                    Togo
                                                    Tokelau
                                                    Tonga
                                                    Trinidad and Tobago
                                                    Tunisia
                                                    Turkey
                                                    Turkmenistan
                                                    Turks and Caicos Islands
                                                    Tuvalu
                                                    Uganda
                                                    Ukraine
                                                    United Arab Emirates
                                                    United Kingdom (Great Britain)
                                                    United States
                                                    United States Virgin Islands
                                                    Uruguay
                                                    Uzbekistan
                                                    Vanuatu
                                                    Vatican City State
                                                    Venezuela
                                                    Viet Nam
                                                    Wallis And Futuna Islands
                                                    Western Sahara
                                                    Yemen
                                                    Zaire
                                                    Zambia
                                                    Zimbabwe
                                                

                    
                    
                        
                        
                            Country 
                        
                        
                    
            
        
                                





    








    /* Prefix phone number */
    .shipping-phone.-focus.input-container:before,
    .shipping-phone.-filled.input-container:before {
        content: &quot;07&quot;;
        height: 40px;
        position: absolute;
        display: block;
        line-height: 41px;
        padding-left: 12px;
    }
    .shipping-phone.-focus.-expanded.input-container:before,
    .shipping-phone.-filled.-expanded.input-container:before {
        height: 56px;
        line-height: 57px;
    }
    .shipping-phone.-focus.input-container input,
    .shipping-phone.-filled.input-container input {
        padding-left: 38px;
    }
    .user-info .s_phone:before, .user-info .b_phone:before {
        content: &quot;07&quot;;
    }






                
                
                

            
                                                    



                
                                                
                
            
                                
                            
                            This will complete the registration process to access the full site and start enjoying your smoke-free future.
                            
                                
                                                                                                                                                                                                                                                                                                        
                                        Confirmă
                                    
                                                                    
                            
    După finalizarea înregistrării și confirmarea adresei de email, vei putea beneficia de oferta specială pentru IQOS Starter Kit.

                        
                        
                        
                            $(function () {
                                $(&quot;.form-group[class*=' o-'], .form-group[class^='o-']&quot;).each(function() {
                                    $(this).find(&quot;input&quot;).attr('tabindex', $(this).attr(&quot;class&quot;).match(/\bo-\d{1,2}\b/g)[0].match(/\d{1,2}/g)[0]);
                                })
                            })
                        
                        
                    
                    

                

        
    









    
        _datalayer_onboarding('Start', 'Account', 'email, password, confirm-password, terms, marketing opt-in');
    


    &lt;p style=&quot;border: 2px solid #ccc; color: orange; margin: 20px 0; padding: 20px; font-size: 22px; background: #f9f9f9;&quot;>&lt;strong>Atenţie:&lt;/strong> Fie ai JavaScript dezactivat sau browser-ul tău nu suportă JavaScript. Pentru o funcţionare corectă, acest website necesită JavaScript activat.&lt;/p>




    
                                                            


//&lt;![CDATA[
(function(_, $) {
    $(_.doc).ready(function() {
        $.ceEvent('on', 'ce.formpost_profile_form', function() {
            $(&quot;body&quot;).append('&lt;div class=&quot;ui-widget-overlay ui-front&quot; style=&quot;z-index: 1100;&quot;>&lt;/div>');
            $.toggleStatusBox('show');
        });
    });
}(Tygh, Tygh.$));
//]]>




    







        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;profiles-add cap_cookies cap_flexbox cap_flexwrap age-gate-hidden not_IE&quot;]/body[@class=&quot;cscart-dispatch-profiles-add cscart-lang-ro      revamp-cart  revamp-checkout  revamp-registration  revamp-add-to-cart-notifications  revamp-notifications  revamp-age-gate    isDesktop&quot;]/main[@class=&quot;tygh-content main comment&quot;]/div[@class=&quot;container-fluid  layout-wrapper&quot;]/div[@class=&quot;row-fluid&quot;]/div[@class=&quot;span12 page-cols-wrapper page-registration-rev&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ÎNREGISTREAZĂ-TE'])[1]/following::div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CREEAZĂ UN CONT'])[1]/following::div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
