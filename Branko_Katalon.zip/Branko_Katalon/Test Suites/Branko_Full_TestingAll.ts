<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>ajmo</description>
   <name>Branko_Full_TestingAll</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>be2baade-c325-4b48-8e2e-c5a9b3579ac5</testSuiteGuid>
</TestSuiteEntity>
